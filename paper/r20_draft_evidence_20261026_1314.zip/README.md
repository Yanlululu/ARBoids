# r20 初稿证据包

证据快照：2026-10-26T13:16:08+08:00。固定节点：ARBOIDS-M2-R20-20261020-043146。

本包完整整理截至快照时已完成、可用于撰稿的证据。全方法五次独立训练仍在进行，因此“本包已整理完成”与“全部计划实验完成”分别记录。先看本文，再使用 tables 和 figures；精确方法见 methods/方法与实验设置.md；核心代码入口见 code/README.md。

## 当前可以写到哪一步

现有材料足以写出包含方法、实验设置、主结果、消融、机制诊断、适用范围、高保真仿真和讨论的完整初稿。五种子全方法主表留待补齐；最终摘要和结论应随该表更新。

当前最明确的机制证据来自 M1：固定模型在 400 个新任务上，联合选择相对独立选择提高 6.50 个百分点，95% 区间为 [1.75, 11.25]，救回 63 次、损害 37 次。M2 在开发集及无 M1 的固定模型对照中有正收益；在强 M1 前驱上的新任务增量为 -2.50 个百分点，95% 区间 [-5.75, 0.75]，救回 18 次、损害 28 次。区间包含零，不等于已经证明总体负效应，也不能据此宣称稳定正增益。

适合当前证据的写法是说明两项方法设计、报告各自的实际贡献与条件差异。以“两项机制在独立任务上均稳定增益”为中心结论的最终稿，现有结果尚不能支持。

## 已完成证据

| 内容 | 完成情况 | 对应材料 |
|---|---|---|
| 开发结果与外部基线 | 固定 r20 六配置；25/25 次外部基线训练，保留逐种子结果 | ablation、baselines_*、episodes |
| 预先冻结的新任务 | 400 个共同任务；7 个固定配置、26 个外部基线模型全部完成 | independent_* |
| 独立重新训练的分支 | 16/35 个端点评测完整；0/5 条完整流水线结束 | 下表及 provenance/status.json |
| 机制诊断 | 80 个新状态，每状态 8 个共同未来；4080 次候选延续测量 | mechanism_*、M1_same_state_objective |
| 适用范围 | 45 个有效配置，共 5100 回合；另 15 个跨艇数配置明确不支持 | scope_* |
| VRX/Gazebo | 6 方法 × 100 共同场景，600 次有效闭环仿真 | vrx_*、data/vrx_* |
| 救回与损害轨迹 | 5 个对照，每个正反例各一项，共 19 条独立轨迹 | trajectory_examples、data/trajectory_* |

表名省略 tables/ 路径和 .csv 后缀。

## 可直接引用的固定节点数字

| 配置 | 含义 | 开发集（856 回合） | 新任务（400 回合） |
|---|---|---:|---:|
| F00 | 均不启用 | 11.33% | 12.00% |
| F10 | 仅 M1 | 86.21% | 86.00% |
| F01 | 仅 M2 | 28.50% | 23.25% |
| F11 | M1+M2 | 94.04% | 83.50% |
| ordinary_no_M1 | 无 M1 的普通回报对照 | 18.11% | 19.00% |
| ordinary_with_M1 | 有 M1 的普通回报对照 | 85.75% | 86.00% |
| M1_independent | M1 独立选择 | 见独立选择对照 | 79.50% |

开发集由 source-development 256 回合和三个各 200 回合的开发套件构成，所有 856 回合都属于开发证据。r20 的 F11 为 805/856（94.04%）。另一六艇源策略开发版本的 830/856（97.0%）不属于本节点。

新任务上，五种子原始 ARBoids 为 64.35% ± 15.67%（种子间样本标准差）。固定 r20 的 83.50% 是单个选择后模型的结果，应与其模型角色一并陈述，不能填入五次独立全方法的均值栏。置信区间与标准差在各列明确区分。

VRX/Gazebo 中 F10、F11、ARBoids 分别成功 98/100、96/100、90/100；F11 有 63 个控制步超过 0.2 秒期限，计数单位是控制步。高保真结果属于仿真验证。

## 独立重复快照

每个已填单元格来自 completed=true、400/400 完整评价；其余不进入结果统计。保留所有已完成分支，不按表现筛选种子。

| 种子 | F00 | F10 | F01 | 普通回报无 M1 | M1 独立选择 | F11 | 普通回报有 M1 |
|---|---:|---:|---:|---:|---:|---:|---:|
| 42 | 48/400 | 344/400 | 72/400 | 118/400 | 318/400 | 待完成 | 待完成 |
| 43 | 50/400 | 320/400 | 69/400 | 69/400 | 293/400 | 待完成 | 待完成 |
| 44 | 48/400 | 290/400 | 65/400 | 94/400 | 257/400 | 待完成 | 待完成 |
| 45 | 60/400 | 待完成 | 待完成 | 待完成 | 待完成 | 待完成 | 待完成 |
| 46 | 待完成 | 待完成 | 待完成 | 待完成 | 待完成 | 待完成 | 待完成 |

independent_summary.csv 中 category=independent-pipeline 且 complete=False 的均值、标准差和区间是中途汇总；最终五种子结论使用 complete=True 的完整集合。固定模型、外部基线和独立流水线通过 category 区分。

## 表与图怎么用

| 用途 | CSV 表 | 配套 PDF |
|---|---|---|
| 开发方法比较 | baselines_summary、baselines_by_seed、ablation | baseline_five_seeds、r20_ablation |
| 新任务配置与贡献 | independent_summary、independent_by_seed、independent_paired_effects | unseen_fixed_r20_controls、unseen_paired_mechanism_effects |
| 训练与计算预算 | baseline_training_curves、independent_training_budget、independent_training_objectives | completed_baseline_training_curves |
| M1 同状态解释 | M1_same_state_objective | independent_mechanism_measurements、trajectory_M1_joint_vs_independent |
| M2 排序与干预收益 | mechanism_summary、mechanism_states、mechanism_plans、mechanism_outcomes | independent_mechanism_measurements、independent_value_prediction_vs_measurement |
| 条件范围与学习对手 | scope_summary、scope_paired_effects | prospective_operating_range、common_learned_opponent |
| 正例与反例 | trajectory_examples | trajectory_*、M2_rescue_and_harm_clearance |
| 高保真与时延 | vrx_summary、vrx_paired_effects、vrx_trials | vrx_paired_success_and_latency；场景图 vrx_scene.png |

图中区间含义见图题和对应表的 interval_method；PDF 为排版用矢量图。

## 数据与来源

- CSV 使用 UTF-8 编码，可用 Excel、Python 或 R 读取。百分比与百分点按列名区分。
- 开发逐回合记录为 tables/episodes.csv；新任务为 independent_episodes.csv；范围和 VRX 为 scope_episodes.csv、vrx_trials.csv。
- data/trajectory_examples.npz 的键是“模型-任务/字段”；data/vrx_trajectories.npz 的键是“试验标识/原数组名”，用 numpy.load(..., allow_pickle=False) 读取。选择规则和轨迹说明在对应 JSON 中。
- data/mechanism_states.jsonl 保留 80 个状态的上下文、候选和实测结局；data/vrx_results.jsonl 保留 600 份原始结果及世界映射；共享世界文件按内容去重。
- code/train 来自独立清单冻结的源码；code/vrx 为高保真执行代码；原作者依赖及许可位于 code/third_party/arboids_release。
- provenance 保存节点身份、来源哈希、完成状态和复现记录。恢复的训练计算通过三成员参数完全一致检查；完整历史工程的原始源码字节快照没有恢复。
- manifest.json 和 SHA256SUMS 对包内文件逐项校验。本包用于写作与证据复核；模型权重保留在原实验档案。
