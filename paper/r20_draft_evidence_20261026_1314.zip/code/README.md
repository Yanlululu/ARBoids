# 核心代码入口

本目录整理写作与复核需要的完整源文件；六个机制运行模块逐字匹配独立实验清单中的冻结版本。保留完整函数依赖，未为缩短代码重写算法。不同实验开关以 methods/r20_deployment.json 为准，文件中存在的其他研究分支不代表 r20 启用了这些功能。

## 先看这些入口

| 功能 | 文件 | 函数或类 | 起始行 |
|---|---|---|---:|
| M1 联合候选选择 | train/conditional_fusion_value.py | refine_actuator_interactions | 4682 |
| M2 共享任务势网络 | train/local_intervention_value.py | JointTaskPotential | 76 |
| M2 价值拟合 | train/local_intervention_value.py | fit_joint_potential | 1336 |
| M2 局部配对校正 | train/local_intervention_value.py | reconcile_root | 662 |
| M2 在线决策 | train/local_intervention_value.py | LocalDifferenceDecision | 827 |
| 普通回报决策定义 | train/local_intervention_value.py | PlainJointReturnDecision | 754 |
| 完整配对干预采样 | train/local_intervention_value.py | recollect_local_design | 2385 |
| 事实轨迹采集 | train/local_intervention_value.py | collect_factual_trajectories | 2286 |
| 真实仿真步与执行 | train/develop_source_fusion.py | joint_task_step | 3496 |
| 独立训练流水线 | train/r20_independent_evidence.py | repeat | 622 |
| 独立种子评价 | train/r20_independent_evidence.py | seed_test | 647 |
| 固定节点新任务评价 | train/r20_independent_evidence.py | fixed_test | 257 |
| 原始基线评价 | train/r20_independent_evidence.py | baseline_test | 691 |

## 训练、评价与统计

- train/r20_independent_evidence.py：冻结运行时装载、固定节点验证、训练计算复现、每个种子独立采样与拟合、端点评价。repeat 是完整流水线，seed-test 是已训练模型评价；本包没有自动启动这些入口。
- train/r20_diagnostic_evidence.py：新状态机制测量、适用范围和救回/损害轨迹相关调度。
- train/r20_baseline_comparison.py：外部基线的训练与比较入口。baseline_versions 保留已经用于实验的不同精确源版本；对应关系见 provenance/code_identity.json 和原始来源记录。
- baseline_runtime：从冻结 baseline-runtime.pth 抽出的原始基线评价代码，区别于后来修改的调度文件。
- train/export_r20_paper_evidence.py：原证据汇总、成对效应与图表生成。analysis/statistics.py 单独提供本包使用的交叉重采样、成对统计与 Holm 校正，便于从 CSV 复核。
- vrx：真实 Gazebo/ROS 闭环执行、同步起点、试验批次和结果采集。
- third_party/arboids_release：原作者动力学、源策略与 VRX 依赖，保留 LICENSE 与来源记录。

## 版本与运行所需输入

../provenance/code_identity.json 区分冻结机制源码、归档 VRX 源码、历史基线源码与当前调度快照。并行根采样调度函数的哈希已与已通过的重放记录核对。训练计算重放精确匹配不代表完整历史工程的原始字节快照已经恢复。

这些代码用于阅读、方法复核和在原实验目录中重现调用；原有入口保留原路径约定。完整训练/仿真还需原实验的模型权重、清单与训练数据，以及相应 PyTorch/SciPy、ROS/Gazebo 环境。写作表格和逐任务统计可直接使用本包 tables 与 data。运行环境或权重不属于本次精简写作证据包。
