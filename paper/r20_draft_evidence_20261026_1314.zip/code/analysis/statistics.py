import math
import numpy as np

def crossed_interval(values, strata=None, draws=10000):
    """Resample training seeds and common task columns, preserving task strata."""
    values = np.asarray(values, dtype=np.float64)
    if values.ndim == 1:
        values = values[None, :]
    if values.ndim != 2 or not np.isfinite(values).all() or not values.size:
        raise ValueError('Bootstrap input must be a finite seed-by-task matrix.')
    strata = np.zeros(values.shape[1], dtype=int) if strata is None else np.asarray(strata)
    if len(strata) != values.shape[1]:
        raise ValueError('Bootstrap strata do not match the task columns.')
    groups = [np.flatnonzero(strata == label) for label in np.unique(strata)]
    generator = np.random.default_rng(20261026)
    samples = []
    for start in range(0, draws, 256):
        count = min(256, draws-start)
        seeds = generator.integers(values.shape[0], size=(count, values.shape[0]))
        tasks = np.concatenate([group[generator.integers(len(group), size=(count, len(group)))]
                                for group in groups], axis=1)
        samples.extend(values[seeds[:, :, None], tasks[:, None, :]].mean(axis=(1, 2)))
    return [float(x) for x in np.quantile(samples, [.025, .975])]

def paired_statistics(a, b, strata, repeated=False):
    left, right = np.asarray(a, dtype=float), np.asarray(b, dtype=float)
    if left.shape != right.shape:
        raise ValueError('Paired comparisons require the same seed and task axes.')
    if left.ndim == 1:
        left, right = left[None, :], right[None, :]
    difference = left-right
    rescues = ((left == 1) & (right == 0)).sum(axis=1)
    harms = ((left == 0) & (right == 1)).sum(axis=1)
    ci = crossed_interval(difference, strata)
    result = dict(gain_percentage_points=100*float(difference.mean()),
        ci95_low_percentage_points=100*ci[0], ci95_high_percentage_points=100*ci[1],
        training_repetitions=left.shape[0] if repeated else 0, paired_tasks=left.shape[1],
        rescued_by_seed=rescues.tolist(), harmed_by_seed=harms.tolist(),
        seed_gains_percentage_points=(100*difference.mean(axis=1)).tolist(),
        interval_method='crossed bootstrap of seeds and stratified common tasks' if repeated
                        else 'stratified paired-task bootstrap conditional on the frozen models')
    if repeated:
        means = difference.mean(axis=1)
        signs = np.asarray([[1 if mask & (1 << i) else -1 for i in range(len(means))]
                            for mask in range(2**len(means))])
        result['seed_sign_flip_p_two_sided'] = float(
            (np.abs((signs*means).mean(axis=1)) >= abs(means.mean())-1e-14).mean())
        result['hypothesis_test_unit'] = 'independent training seed; paired frozen task population'
    else:
        discordant = int(rescues[0]+harms[0]); smaller = int(min(rescues[0], harms[0]))
        result['mcnemar_exact_p_two_sided'] = min(1., 2*sum(math.comb(discordant, i)
            for i in range(smaller+1))/2**discordant) if discordant else 1.
        result['hypothesis_test_unit'] = 'paired task; conditional on one frozen model per method'
    return result

def holm_adjust(rows, key):
    eligible = sorted((row for row in rows if key in row), key=lambda row: row[key])
    previous = 0.
    for rank, row in enumerate(eligible):
        previous = max(previous, min(1., (len(eligible)-rank)*row[key]))
        row[key+'_holm'] = previous
        row['multiplicity_family_size'] = len(eligible)
