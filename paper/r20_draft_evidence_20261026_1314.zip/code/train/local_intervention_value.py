"""Joint task potentials learned from outcomes and single-vessel contrasts.

All labels come from terminal continuations of a frozen predecessor.  The
potential is a function of a complete intervention, not a sum of local gains.
Local consequences constrain a factual-anchored joint potential. The learned
single-vessel contrasts are antisymmetric; reconstruction makes the final
complete-plan value comparisons cycle consistent.
"""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
from contextlib import nullcontext
from itertools import combinations, product
import copy
import hashlib
import os
import time

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F


@torch.no_grad()
def response_basis(context, controls):
    """Public constant-command motion descriptors for all ten boat choices.

    These are input features, not task labels or a collision-cost controller.
    The value estimator learns how their consequences depend on the actual
    intervention delay and duration from paired terminal observations.
    """
    b, n = controls.shape[:2]
    rows = context[:, :8*n].reshape(b, n, 8)
    coefficients = context.new_tensor([[-1., -1.]]+[[a, z] for a in (0., .5, 1.) for z in (0., .5, 1.)])
    source, rule, factual = controls.split(2, -1)
    command = coefficients[None, None]*source[:, :, None]+(1-coefficients[None, None])*rule[:, :, None]
    command[:, :, 0] = factual
    force = 750.*command+250.
    heading = torch.atan2(rows[..., 5], rows[..., 4])
    state = torch.cat((30.*rows[..., :2], heading[..., None], 3.*rows[..., 2:4], rows[..., 6:7]), -1)
    state = state[:, :, None].expand(-1, -1, 10, -1).clone()
    snapshots = []
    for step in range(80):
        x, y, yaw, vx, vy, angular = state.unbind(-1)
        x = x+.05*vx; y = y+.05*vy; yaw = yaw+.05*angular
        cosine, sine = yaw.cos(), yaw.sin()
        u = cosine*vx+sine*vy; v = -sine*vx+cosine*vy
        du = (400.*angular*v-(100.+150.*u.abs())*u+force.sum(-1))/380.
        dv = (-380.*angular*u-(100.+150.*v.abs())*v)/400.
        dr = (-20.*u*v-(980.+950.*angular.abs())*angular+1.25*(force[..., 0]-force[..., 1]))/1430.
        u = u+.05*du; v = v+.05*dv
        state = torch.stack((x, y, yaw, cosine*u-sine*v, sine*u+cosine*v, angular+.05*dr), -1)
        if step in (19, 39, 79):
            snapshots.append(state)
    path = torch.stack(snapshots, -2)
    target = 5.*context[:, -3:-1]
    time = context.new_tensor((1., 2., 4.))
    position = path[..., :2]-target[:, None, None, None]*time[None, None, None, :, None]
    body = torch.stack((path[..., 2].cos(), path[..., 2].sin()), -1)
    absolute = torch.cat((position/30., path[..., 3:5]/5., body, path[..., 5:6]/2.), -1)
    relative = torch.cat(((path[..., :2]-path[:, :, :1, :, :2])/5.,
        (path[..., 3:5]-path[:, :, :1, :, 3:5])/3., body-body[:, :, :1],
        (path[..., 5:6]-path[:, :, :1, :, 5:6])/2.), -1)
    return torch.cat((absolute, relative), -1).flatten(-2), path


def response_pair_geometry(left, right):
    displacement = left[..., :2]-right[..., :2]
    velocity = left[..., 3:5]-right[..., 3:5]
    separation = displacement.square().sum(-1).clamp_min(1e-8).sqrt()
    approach = (displacement*velocity).sum(-1)/separation
    return torch.cat((displacement/30., velocity/5., separation[..., None]/10.,
                      approach[..., None]/5.), -1).flatten(-2)


class JointTaskPotential(nn.Module):
    def __init__(self, width=64, peer_conditioned=True, output_width=1, context_conditioned=False,
                 local_contrast_head=False, motion_basis=False, residual_potential=False):
        super().__init__()
        self.width = width
        self.peer_conditioned = peer_conditioned
        self.context_conditioned = context_conditioned
        self.motion_basis = motion_basis
        self.residual_potential = residual_potential
        if residual_potential and (output_width != 1 or local_contrast_head):
            raise ValueError('The centered representation defines one shared scalar task potential.')
        self.node = nn.Sequential(nn.Linear(29+5*context_conditioned+42*motion_basis, width), nn.SiLU(), nn.Linear(width, width), nn.SiLU())
        self.message = nn.Sequential(nn.Linear(2*width+10+18*motion_basis, width), nn.SiLU(), nn.Linear(width, width), nn.SiLU())
        self.update = nn.Sequential(nn.Linear(3*width, width), nn.SiLU())
        self.head = nn.Sequential(nn.Linear(3*width+8, width), nn.SiLU(), nn.Linear(width, output_width))
        self.effect_head = (nn.Sequential(nn.Linear(2*(3*width+8), width), nn.SiLU(),
            nn.Linear(width, 1)) if residual_potential else None)
        self.contrast = (nn.Sequential(nn.Linear(3*width+8, width), nn.SiLU(),
            nn.Linear(width, 6*width)) if local_contrast_head else None)
        self.contrast_categorical = local_contrast_head == 'categorical'
        self.contrast_agreement = (nn.Sequential(nn.Linear(3*width+8, width), nn.SiLU(),
            nn.Linear(width, 2)) if self.contrast_categorical else None)
        self.register_buffer('coefficients', torch.tensor([[-1., -1.]] +
            [[a, b] for a in (0., .5, 1.) for b in (0., .5, 1.)]))

    def encode(self, context, controls, programs, timing, responses=None):
        n = programs.shape[-1]
        rows = context[:, :8*n].reshape(-1, n, 8)
        source, rule, factual = controls.split(2, -1)
        active = programs > 0
        coefficients = self.coefficients[programs]
        command = torch.where(active[..., None], coefficients*source+(1-coefficients)*rule, factual)
        features = torch.cat((rows, controls, F.one_hot(programs, 10).to(rows.dtype),
                              command, command-factual, active[..., None].to(rows.dtype)), -1)
        if self.context_conditioned:
            features = torch.cat((features, context[:, None, -5:].expand(-1, n, -1)), -1)
        if self.motion_basis:
            if responses is None:
                responses = response_basis(context, controls)
            batch = torch.arange(len(context), device=context.device)[:, None]
            boats = torch.arange(n, device=context.device)[None]
            selected_response = responses[0][batch, boats, programs]
            features = torch.cat((features, selected_response), -1)
        own = self.node(features)
        if self.peer_conditioned:
            peer = own
        else:
            reference = torch.cat((rows, controls, F.one_hot(torch.zeros_like(programs), 10).to(rows.dtype),
                                   factual, torch.zeros_like(factual), torch.zeros_like(active[..., None], dtype=rows.dtype)), -1)
            if self.context_conditioned:
                reference = torch.cat((reference, context[:, None, -5:].expand(-1, n, -1)), -1)
            if self.motion_basis:
                reference = torch.cat((reference, responses[0][:, :, 0]), -1)
            peer = self.node(reference)
        difference = rows[:, :, None]-rows[:, None]
        distance = difference[..., :2].square().sum(-1).clamp_min(1e-8).sqrt()
        closing = (difference[..., :2]*difference[..., 2:4]).sum(-1)/distance
        geometry = torch.cat((difference, distance[..., None], closing[..., None]), -1)
        if self.motion_basis:
            own_path = responses[1][batch, boats, programs]
            peer_path = own_path if self.peer_conditioned else responses[1][:, :, 0]
            geometry = torch.cat((geometry, response_pair_geometry(own_path[:, :, None], peer_path[:, None])), -1)
        message = self.message(torch.cat((own[:, :, None].expand(-1, -1, n, -1),
                                         peer[:, None].expand(-1, n, -1, -1), geometry), -1))
        mask = ~torch.eye(n, dtype=torch.bool, device=rows.device)[None, :, :, None]
        encoded = self.update(torch.cat((own, (message*mask).sum(2)/max(n-1, 1),
                                        message.masked_fill(~mask, -1e4).amax(2)), -1))
        changed = (encoded*active[..., None]).sum(1)/active.sum(1, keepdim=True).clamp_min(1)
        # A factual continuation has no intervention duration or delay.
        clock = timing.to(rows.dtype).log1p()/6.*active.any(-1, keepdim=True)
        global_state = torch.cat((context[:, -5:], clock, rows.new_full((len(rows), 1), n/6.)), -1)
        representation = torch.cat((encoded.mean(1), encoded.amax(1), changed, global_state), -1)
        return encoded, representation

    def forward(self, context, controls, programs, timing, responses=None):
        representation = self.encode(context, controls, programs, timing, responses)[1]
        if not self.residual_potential:
            return self.head(representation).squeeze(-1)
        reference = self.encode(context, controls, torch.zeros_like(programs), torch.zeros_like(timing), responses)[1]
        # A complete plan is evaluated relative to its own factual state.
        # The effect vanishes continuously with its physical duration, so a
        # one-tick choice does not inherit a full persistent-maneuver effect.
        effect = self.effect_head(torch.cat((reference, representation-reference), -1)).squeeze(-1)
        exposure = -torch.expm1(-.2*timing[:, 1].to(context.dtype))*(programs > 0).any(-1)
        return self.head(reference).squeeze(-1)+exposure*effect

    def contrast_from_encodings(self, first, second, changed_boat, global_state, return_distribution=False):
        """Predict the two factual-stratum consequences of one boat change.

        Symmetric context selects a signed linear form. Swapping the complete
        endpoint plans therefore reverses the prediction exactly, including
        the effects of the changed boat on its unchanged teammates.
        """
        index = torch.arange(len(first), device=first.device)
        left = torch.cat((first[index, changed_boat], first.mean(1), first.amax(1)), -1)
        right = torch.cat((second[index, changed_boat], second.mean(1), second.amax(1)), -1)
        symmetric = torch.cat(((left+right)*.5, global_state), -1)
        coefficients = self.contrast(symmetric)
        coefficients = coefficients.reshape(-1, 2, 3*self.width)
        signed = (coefficients*(right-left)[:, None]).sum(-1)/(3*self.width)**.5
        if self.contrast_categorical:
            logits = torch.stack((-signed, self.contrast_agreement(symmetric), signed), -1)
            probabilities = logits.softmax(-1)
            delta = probabilities[..., 2]-probabilities[..., 0]
            return (delta, logits) if return_distribution else delta
        return signed.tanh()

    def local_contrasts(self, context, controls, programs, timing, return_distribution=False, responses=None):
        """The batch contains adjacent endpoint pairs with common futures."""
        encoded, representation = self.encode(context, controls, programs, timing, responses)
        pair = programs.reshape(-1, 2, programs.shape[-1])
        changed = pair[:, 0] != pair[:, 1]
        if not bool((changed.sum(-1) == 1).all()):
            raise ValueError('A local comparison must change exactly one vessel.')
        clocks = timing.reshape(-1, 2, 2).amax(1).to(context.dtype).log1p()/6.
        global_state = torch.cat((context[::2, -5:], clocks,
            context.new_full((len(pair), 1), programs.shape[-1]/6.)), -1)
        delta = self.contrast_from_encodings(encoded[::2], encoded[1::2],
            changed.to(torch.long).argmax(-1), global_state, return_distribution)
        return delta, self.head(representation)

    def catalog_contrasts(self, context, encoded, pairs, boats, inverse, clock):
        """Factor the same local comparison across its intervention windows.

        The final coefficient projection is contracted with the signed plan
        features before expanding over windows. This is the same bilinear
        contrast as contrast_from_encodings, without repeating that large
        matrix multiplication for every delay and duration.
        """
        first = encoded[:, pairs[:, 0]]; second = encoded[:, pairs[:, 1]]
        index = torch.arange(len(pairs), device=encoded.device)
        left = torch.cat((first[:, index, boats], first.mean(2), first.amax(2)), -1)
        right = torch.cat((second[:, index, boats], second.mean(2), second.amax(2)), -1)
        global_state = torch.cat((context[:, None, -5:].expand(-1, len(pairs), -1),
            context.new_zeros((len(context), len(pairs), 2)),
            context.new_full((len(context), len(pairs), 1), encoded.shape[2]/6.)), -1)
        symmetric = torch.cat(((left+right)*.5, global_state), -1)
        difference = right-left
        projection = torch.einsum('buf,sfh->bush', difference,
            self.contrast[2].weight.reshape(2, 3*self.width, self.width))
        offset = torch.einsum('buf,sf->bus', difference, self.contrast[2].bias.reshape(2, 3*self.width))
        hidden = self.contrast[1](self.contrast[0](symmetric)[:, inverse]+
            F.linear(clock, self.contrast[0].weight[:, -3:-1])[None])
        signed = ((projection[:, inverse]*hidden[:, :, None]).sum(-1)+offset[:, inverse])/(3*self.width)**.5
        if self.contrast_categorical:
            agreement_hidden = self.contrast_agreement[1](self.contrast_agreement[0](symmetric)[:, inverse]+
                F.linear(clock, self.contrast_agreement[0].weight[:, -3:-1])[None])
            probabilities = torch.stack((-signed, self.contrast_agreement[2](agreement_hidden), signed), -1).softmax(-1)
            return probabilities[..., 2]-probabilities[..., 0]
        return signed.tanh()

    def forward_catalog(self, context, controls, programs, timing, return_encodings=False, responses=None):
        """Exactly reuse node and pair features across complete joint plans."""
        b, n = controls.shape[:2]; width = self.width
        rows = context[:, :8*n].reshape(b, n, 8)
        source, rule, factual = controls.split(2, -1)
        digits = torch.arange(10, device=context.device)
        active = digits > 0
        command = torch.where(active[None, None, :, None],
            self.coefficients[None, None]*source[:, :, None]+(1-self.coefficients[None, None])*rule[:, :, None],
            factual[:, :, None])
        features = torch.cat((rows[:, :, None].expand(-1, -1, 10, -1),
            controls[:, :, None].expand(-1, -1, 10, -1),
            F.one_hot(digits, 10).to(rows.dtype)[None, None].expand(b, n, -1, -1),
            command, command-factual[:, :, None],
            active.to(rows.dtype)[None, None, :, None].expand(b, n, -1, -1)), -1)
        if self.context_conditioned:
            features = torch.cat((features, context[:, None, None, -5:].expand(-1, n, 10, -1)), -1)
        if self.motion_basis:
            if responses is None:
                responses = response_basis(context, controls)
            features = torch.cat((features, responses[0]), -1)
        own = self.node(features)
        peer = own if self.peer_conditioned else own[:, :, :1].expand_as(own)
        difference = rows[:, :, None]-rows[:, None]
        distance = difference[..., :2].square().sum(-1).clamp_min(1e-8).sqrt()
        closing = (difference[..., :2]*difference[..., 2:4]).sum(-1)/distance
        geometry = torch.cat((difference, distance[..., None], closing[..., None]), -1)
        geometry = geometry[:, :, :, None, None].expand(-1, -1, -1, 10, 10, -1)
        if self.motion_basis:
            own_path = responses[1]
            peer_path = own_path if self.peer_conditioned else own_path[:, :, :1].expand_as(own_path)
            geometry = torch.cat((geometry, response_pair_geometry(own_path[:, :, None, :, None],
                peer_path[:, None, :, None])), -1)
        messages = self.message(torch.cat((
            own[:, :, None, :, None].expand(-1, -1, n, -1, 10, -1),
            peer[:, None, :, None].expand(-1, n, -1, 10, -1, -1),
            geometry), -1))
        boats = torch.arange(n, device=context.device)
        mask = (~torch.eye(n, dtype=torch.bool, device=context.device))[None, None, :, :, None]
        distinct, inverse = torch.unique(programs, dim=0, return_inverse=True)
        parts = []; encodings = []
        reference = None
        if self.residual_potential:
            reference = self.encode(context, controls,
                torch.zeros((b, n), dtype=torch.long, device=context.device),
                torch.zeros((b, 2), dtype=torch.long, device=context.device), responses)[1]
        for start in range(0, len(distinct), 256):
            q = distinct[start:start+256]; size = len(q); held = q > 0
            selected = own[:, boats[None], q]
            pair = messages[:, boats[None, :, None], boats[None, None, :], q[:, :, None], q[:, None, :]]
            encoded = self.update(torch.cat((selected, (pair*mask).sum(3)/max(n-1, 1),
                pair.masked_fill(~mask, -1e4).amax(3)), -1))
            if return_encodings:
                encodings.append(encoded)
            changed = (encoded*held[None, :, :, None]).sum(2)/held.sum(1)[None, :, None].clamp_min(1)
            global_state = torch.cat((context[:, None, -5:].expand(-1, size, -1),
                rows.new_zeros((b, size, 2)), rows.new_full((b, size, 1), n/6.)), -1)
            representation = torch.cat((encoded.mean(2), encoded.amax(2), changed, global_state), -1)
            if self.residual_potential:
                factual = reference[:, None].expand(-1, size, -1)
                parts.append(self.effect_head[0](torch.cat((factual, representation-factual), -1)))
            else:
                parts.append(self.head[0](representation))
        # Timing enters the final conditional-value head. Reuse the exact
        # same joint-plan representation across immediate and delayed choices.
        clock = timing.to(rows.dtype).log1p()/6.*(programs > 0).any(-1, keepdim=True)
        head = self.effect_head if self.residual_potential else self.head
        hidden = torch.cat(parts, 1)[:, inverse]+F.linear(clock, head[0].weight[:, -3:-1])[None]
        values = head[2](head[1](hidden)).squeeze(-1)
        if self.residual_potential:
            exposure = -torch.expm1(-.2*timing[:, 1].to(context.dtype))*(programs > 0).any(-1)
            values = self.head(reference).squeeze(-1)[:, None]+exposure[None]*values
        return (values, torch.cat(encodings, 1)[:, inverse]) if return_encodings else values


def local_edges(options, n):
    """Undirected comparisons changing one boat, with an identical clock."""
    lookup = {tuple(option): i for i, option in enumerate(options)}
    pairs = set()
    for a, (code, delay, span) in enumerate(options):
        if code == 0:
            continue
        for boat in range(n):
            digit = (code//10**boat) % 10
            for other in range(10):
                if other == digit:
                    continue
                alternate = code+(other-digit)*10**boat
                # The factual node represents the same frozen continuation
                # for every window; changing one held boat to free is local.
                b = 0 if alternate == 0 else lookup.get((alternate, delay, span))
                if b is not None and b != a:
                    pairs.add((min(a, b), max(a, b)))
    return sorted(pairs)


def single_vessel_neighborhood(code, n):
    """Every alternative that changes exactly one component of a full plan."""
    return sorted({code+(other-code//10**boat % 10)*10**boat
        for boat in range(n) for other in range(10)
        if other != code//10**boat % 10})


def connected_programs(packet, order, interaction_order=2):
    """Include full-team plans together with every single-boat path to them."""
    n = order.shape[-1]
    codes = {0}
    for digit in range(1, 10):
        prefix = 0
        for boat in range(n):
            codes.add(digit*10**boat)
            prefix += digit*10**boat
            codes.add(prefix)
    positions = packet['motion'][0, :, :2][order[0]]
    distance = torch.cdist(positions, positions).fill_diagonal_(float('inf'))
    index = int(distance.argmin()); a, b = divmod(index, n)
    for first in (1, 3, 7, 9):
        for second in (1, 3, 7, 9):
            codes.add(first*10**a+second*10**b)
    if interaction_order >= 3:
        # Heterogeneous small-group maneuvers cannot be represented by
        # uniform fleet plans or isolated one-boat interventions. Include
        # every deletion neighbour, so their values remain linked by genuine
        # single-vessel comparisons rather than additive credit assumptions.
        for boats in combinations(range(n), 3):
            for digits in product((1, 3, 7, 9), repeat=3):
                terms = [digit*10**boat for boat, digit in zip(boats, digits)]
                code = sum(terms); codes.add(code)
                for term in terms: codes.add(code-term)
    return sorted(codes-{0})


def observed_programs(root):
    """Retain every sampled plan, including all negative outcomes."""
    used = sorted({q for q, _ in root['outcomes']})
    if len(used) == len(root['options']): return root
    index = {old: new for new, old in enumerate(used)}
    return dict(root, options=[root['options'][q] for q in used],
        outcomes={(index[q], future): value for (q, future), value in root['outcomes'].items()})


def learning_records(data):
    roots = data['roots']
    node_rows, edge_rows, anchor_rows = [], [], []
    diagnostics = []
    for root_id, root in enumerate(roots):
        n = (len(root['context'])-5)//8
        index = {}; observed_futures = {}
        for (q, future), observation in sorted(root['outcomes'].items()):
            index[q, future] = len(node_rows)
            observed_futures.setdefault(q, set()).add(future)
            code, delay, span = root['options'][q]
            node_rows.append((root_id, q, future, code, delay, span, float(observation['success'])))
        edges = local_edges(root['options'], n)
        count = 0
        for a, b in edges:
            common = sorted(observed_futures.get(a, set()) & observed_futures.get(b, set()))
            for future in common:
                edge_rows.append((index[a, future], index[b, future]))
                count += 1
        for (q, future), position in index.items():
            if q and (0, future) in index:
                anchor_rows.append((index[0, future], position))
        diagnostics.append(dict(nodes=len(index), local_edges=len(edges), paired_local_observations=count))
    if not edge_rows:
        raise ValueError('The conditional learner requires observed single-vessel paired differences.')
    return np.asarray(node_rows), np.asarray(edge_rows, dtype=np.int64), np.asarray(anchor_rows, dtype=np.int64), diagnostics


def merge_paired_data(datasets):
    """Merge observed branches without duplicating a root/program/future."""
    if not datasets:
        raise ValueError('Supply paired terminal observations.')
    predecessor = datasets[0]['predecessor_sha256']
    grouped = {}
    for data in datasets:
        if data['predecessor_sha256'] != predecessor:
            raise ValueError('Conditional and ordinary comparisons need one common frozen predecessor.')
        for original in data['roots']:
            root = original
            # At reset, a seeded factual continuation and a branch with that
            # same seed are the same experiment. Join their observations
            # before estimating contrasts, rather than fitting conflicting
            # potentials at identical public contexts.
            if original['root_steps'] == 0:
                root = copy.deepcopy(original)
                root['futures'] = [root['prefix_future'] if f is None else f for f in root['futures']]
                root['prefix_future'] = None
            key = (tuple(root['scene']), root['prefix_future'], root['root_steps'])
            if key not in grouped:
                grouped[key] = copy.deepcopy(root)
                continue
            old = grouped[key]
            if not np.allclose(old['context'], root['context'], atol=1e-6):
                raise ValueError('A reused paired root has changed physical context.')
            if not np.allclose(old['effect_controls'], root['effect_controls'], atol=1e-6):
                raise ValueError('A reused paired root has changed predecessor controls.')
            options = [(0, 0, 0)]+sorted((set(map(tuple, old['options'])) | set(map(tuple, root['options'])))-{(0, 0, 0)})
            futures = list(old['futures'])
            for future in root['futures']:
                if future not in futures: futures.append(future)
            position = {option: i for i, option in enumerate(options)}
            future_position = {future: i for i, future in enumerate(futures)}
            outcomes = {}
            for entry in (old, root):
                for (q, f), outcome in entry['outcomes'].items():
                    index = (position[tuple(entry['options'][q])], future_position[entry['futures'][f]])
                    if index in outcomes and outcomes[index]['success'] != outcome['success']:
                        raise ValueError('Identical physical branches have conflicting terminal labels.')
                    outcomes[index] = copy.deepcopy(outcome)
            old.update(options=options, futures=futures, outcomes=outcomes)
    return dict(model=copy.deepcopy(datasets[0]['model']), roots=list(grouped.values()),
        predecessor_sha256=predecessor, simulation_steps=sum(d.get('simulation_steps', 0) for d in datasets),
        training_data=[d.get('training_data') for d in datasets], completed=all(d.get('completed', False) for d in datasets))


def factual_reference_data(policy, references):
    """Fit the factual value on the entire observed development population.

    Failure-focused branch acquisition must not make ordinary successful
    states look like factual failures. These are existing complete task
    outcomes; no counterfactual label or future seed enters the representation.
    """
    import conditional_fusion_value as c
    import develop_source_fusion as d
    policy = Path(policy)
    digest = hashlib.sha256(policy.read_bytes()).hexdigest()
    model = torch.load(policy, map_location='cpu', weights_only=False)
    if model.get('successor_task_value') is not None:
        raise ValueError('Factual references require the frozen F00 or F10 predecessor.')
    actor = d.joint_load(str(policy), policy.stat().st_mtime_ns)
    roots = {}; steps = 0
    for result in references:
        if not result['completed'] or result.get('policy_sha256') != digest:
            raise ValueError('Use completed evaluations of this exact predecessor.')
        for (scene, future), row in zip(result['tasks'], result['rows']):
            scene = tuple(scene)
            if scene not in roots:
                np.random.seed(scene[0]); torch.manual_seed(scene[0])
                env = d.numerical_source().TADEnv(scene[1])
                obs, _ = env.reset(agility=scene[2], noisy_agility=False)
                packet = d.mechanism_tensor(d.joint_packet(env, obs))
                with torch.no_grad():
                    action = actor(packet, deterministic=True, gate_only=True)[0][..., :3]
                    context, order = c.intervention_task_context(packet, True, True)
                    controls = c.paired_effect_controls(actor, packet, action)
                roots[scene] = dict(context=context[0].numpy(), effect_controls=controls[0, order[0]].numpy(),
                    options=[(0, 0, 0)], outcomes={}, futures=[], scene=scene, prefix_future=None,
                    root_steps=0, lookback=None, order=order[0].numpy())
            root = roots[scene]
            if future not in root['futures']: root['futures'].append(future)
            key = (0, root['futures'].index(future))
            if key in root['outcomes']:
                if root['outcomes'][key]['success'] != row['success']:
                    raise ValueError('Repeated factual evaluation has conflicting terminal outcomes.')
                continue
            root['outcomes'][key] = dict(success=float(row['success']), outcome=row['outcome'], duration=row['duration'])
            steps += int(round(row['duration']/.2))
    return dict(model=model, roots=list(roots.values()), predecessor_sha256=digest,
        simulation_steps=steps, training_data=[r['policy'] for r in references], completed=True)


def include_delayed_continuations(data, policy=None, coordinate_reference=None):
    """Compare intervening now with an observed later intervention.

    A measured branch following a factual prefix is also a complete delayed
    plan at reset. Only its unchanged (None) continuation can be reused this
    way; freshly reseeded suffixes are not initial-state experiments. An
    already terminal factual prefix is identical for every subsequent plan.
    """
    if 'measured_terminal_observations' in data:
        return copy.deepcopy(data)
    result = copy.deepcopy(data)
    measured = sum(len(root['outcomes']) for root in result['roots'])
    initial = {tuple(root['scene']): root for root in result['roots'] if root['root_steps'] == 0}
    if coordinate_reference is not None:
        if coordinate_reference['predecessor_sha256'] != data['predecessor_sha256']:
            raise ValueError('Reuse boat coordinates only for the same frozen predecessor.')
        known = {(tuple(root['scene']), root['prefix_future'], root['root_steps']): root
                 for root in coordinate_reference['roots'] if 'order' in root}
        for root in result['roots']:
            previous = known.get((tuple(root['scene']), root['prefix_future'], root['root_steps']))
            if 'order' not in root and previous is not None and np.allclose(
                    root['context'], previous['context'], atol=1e-6):
                root['order'] = np.asarray(previous['order']).copy()
    replay_steps = 0; unmatched = 0
    if any('order' not in root for root in result['roots']):
        if policy is None:
            raise ValueError('Supply the frozen predecessor to recover missing physical boat coordinates.')
        import conditional_fusion_value as c
        import develop_source_fusion as d
        policy = Path(policy)
        if hashlib.sha256(policy.read_bytes()).hexdigest() != result['predecessor_sha256']:
            raise ValueError('Delayed labels require their exact measured predecessor.')
        actor = d.joint_load(str(policy), policy.stat().st_mtime_ns)
        for root in result['roots']:
            if 'order' in root: continue
            scene = root['scene']; np.random.seed(scene[0]); torch.manual_seed(scene[0])
            env = d.numerical_source().TADEnv(scene[1]); obs, _ = env.reset(agility=scene[2], noisy_agility=False)
            if root['prefix_future'] is not None: np.random.seed(root['prefix_future'])
            elapsed = done = 0
            while elapsed < root['root_steps'] and not done:
                with torch.no_grad():
                    action = actor(d.mechanism_tensor(d.joint_packet(env, obs)), deterministic=True)[0][0].numpy()
                obs, _, done, _, count = d.joint_advance(env, obs, actor, action, root['root_steps']-elapsed)
                elapsed += count; replay_steps += count
            packet = d.mechanism_tensor(d.joint_packet(env, obs))
            with torch.no_grad(): context, order = c.intervention_task_context(packet, True, True)
            if elapsed != root['root_steps'] or not np.allclose(context[0].numpy(), root['context'], atol=1e-5, rtol=1e-5):
                unmatched += 1
                continue
            root['order'] = order[0].numpy()
    promoted = terminal = 0
    for root in result['roots']:
        if root['root_steps'] <= 0 or None not in root['futures'] or 'order' not in root:
            continue
        target = initial.get(tuple(root['scene']))
        if target is None:
            raise ValueError('A delayed plan requires the observed initial factual context.')
        if 'order' not in target: continue
        # A program's digits name the boats in its decision-time ordering.
        # Transport those physical identities to the initial ordering before
        # reusing a later branch as a delayed complete plan.
        coordinate = np.argsort(root['order'])[target['order']]
        powers = 10**np.arange(len(coordinate))
        future = root['prefix_future']; source_future = root['futures'].index(None)
        if future not in target['futures']: target['futures'].append(future)
        destination_future = target['futures'].index(future)
        options = {tuple(option): q for q, option in enumerate(target['options'])}
        for (q, f), outcome in root['outcomes'].items():
            if f != source_future: continue
            code, delay, span = root['options'][q]
            if code: code = int((((code//powers) % 10)[coordinate]*powers).sum())
            option = (code, root['root_steps']+delay, span) if code else (0, 0, 0)
            if option not in options:
                options[option] = len(target['options']); target['options'].append(option)
            index = (options[option], destination_future)
            if index in target['outcomes']:
                if target['outcomes'][index]['success'] != outcome['success']:
                    raise ValueError('A measured factual prefix has a conflicting complete-task outcome.')
                continue
            target['outcomes'][index] = dict(outcome, reused_prefix=True)
            promoted += 1
    for root in initial.values():
        facts = [(f, outcome) for (q, f), outcome in root['outcomes'].items() if q == 0]
        for q, (code, delay, span) in enumerate(root['options']):
            if not code or delay <= 0: continue
            for future, outcome in facts:
                if outcome['duration'] > .2*delay+1e-6 or (q, future) in root['outcomes']: continue
                root['outcomes'][q, future] = dict(outcome, reused_terminal_prefix=True)
                terminal += 1
    result.update(measured_terminal_observations=measured,
        reused_delayed_labels=promoted, reused_terminal_prefix_labels=terminal,
        coordinate_replay_steps=replay_steps, unmatched_factual_prefixes=unmatched,
        simulation_steps=result.get('simulation_steps', 0)+replay_steps)
    return result


def focus_development_futures(data, references, weight=16.):
    """Optimize the explicitly reusable development population in both arms."""
    result = copy.deepcopy(data); population = {}
    for reference in references:
        for scene, future in reference['tasks']:
            population.setdefault(tuple(scene), set()).add(future)
    for root in result['roots']:
        futures = population.get(tuple(root['scene']), set())
        root['future_weights'] = [float(weight) if (
            (future in futures) if root['root_steps'] == 0 else
            (future is None and root['prefix_future'] in futures)) else 1.
            for future in root['futures']]
    result['development_future_weight'] = float(weight)
    return result


def initial_plan_comparisons(data, policy, factual_bank, references):
    """Bring verified later comparisons to the initial decision horizon.

    A late intervention after a factual prefix is also an executable delayed
    complete plan at reset. Verify the observed prefix against the frozen
    predecessor trajectory before transporting its single-boat comparisons.
    Labels after a different learned prefix remain local to their own state.
    """
    if factual_bank['predecessor_sha256'] != data['predecessor_sha256']:
        raise ValueError('Initial comparisons require the same frozen predecessor.')
    reference = factual_reference_data(policy, references)
    # These task results are already represented in the common trajectory bank.
    reference['simulation_steps'] = 0
    trajectories = {(tuple(record['scene']), record['future']): record
                    for record in factual_bank['records'] if 'option' not in record}
    retained = []; verified = 0; local_only = 0
    for root in data['roots']:
        if root['root_steps'] == 0:
            retained.append(root)
            continue
        trajectory = trajectories.get((tuple(root['scene']), root['prefix_future']))
        if trajectory is None or None not in root['futures']:
            local_only += 1
            continue
        ticks = np.rint(400*trajectory['contexts'][:, -1]).astype(int)
        positions = np.flatnonzero(ticks == root['root_steps'])
        matched = any(np.allclose(root['context'], trajectory['contexts'][i], atol=1e-6, rtol=1e-6)
                      and np.allclose(root['effect_controls'], trajectory['controls'][i], atol=1e-6, rtol=1e-6)
                      for i in positions)
        # The first intervention has an unchanged predecessor prefix by
        # construction. Later learned prefixes need fresh local comparisons;
        # matching only a compressed public snapshot is insufficient.
        factual_prefix = (data.get('recipe', {}).get('context_policy') is None
                          or root.get('lookback') == 'first_intervention')
        if not matched or not factual_prefix:
            local_only += 1
            continue
        future = root['futures'].index(None)
        factual = root['outcomes'].get((0, future))
        if factual is None or factual['success'] != trajectory['values'][0]:
            raise ValueError('A verified predecessor prefix changed its factual task result.')
        retained.append(root); verified += 1
    measured = dict(data, roots=retained, simulation_steps=0)
    prepared = merge_paired_data([reference, measured])
    promoted = include_delayed_continuations(prepared, policy=policy)
    promoted['roots'] = [root for root in promoted['roots'] if root['root_steps'] == 0]
    promoted['simulation_steps'] = promoted.get('coordinate_replay_steps', 0)
    promoted.update(verified_factual_prefixes=verified, unpromoted_local_prefixes=local_only,
                    initial_factual_labels=sum(len(root['outcomes']) for root in reference['roots']),
                    training_data='verified initial-horizon comparisons from the common measured data')
    return promoted


def state_features(context, controls, time_scale=1.):
    # Public kinematics and the actual predecessor command define locality.
    n = controls.shape[-2]
    rows = context[..., :8*n].reshape(*context.shape[:-1], n, 8)
    clock = torch.cat((context[..., -5:-1], time_scale*context[..., -1:]), -1)
    return torch.cat((torch.cat((rows, .25*controls), -1).flatten(-2), clock), -1)


def reconcile_root(root, prior, edge_weight=4., ridge=.5):
    """Fit one integrable potential using absolute and paired local outcomes."""
    from scipy import sparse
    from scipy.sparse.linalg import spsolve
    options = root['options']; size = len(options); n = (len(root['context'])-5)//8
    observations = root['outcomes']
    counts = np.zeros(size); totals = np.zeros(size); observed_futures = {}; raw_counts = np.zeros(size)
    future_weights = root.get('future_weights', np.ones(len(root['futures'])))
    for (q, future), item in observations.items():
        weight = future_weights[future]
        counts[q] += weight; totals[q] += weight*item['success']; raw_counts[q] += 1
        observed_futures.setdefault(q, set()).add(future)
    baseline = totals[0]/max(1., counts[0])
    repair = np.zeros(size); damage = np.zeros(size)
    factual_failure = np.zeros(size); factual_success = np.zeros(size)
    for (q, future), item in observations.items():
        if q and (0, future) in observations:
            factual = observations[0, future]['success']
            weight = future_weights[future]
            if factual:
                factual_success[q] += weight; damage[q] += weight*(1-item['success'])
            else:
                factual_failure[q] += weight; repair[q] += weight*item['success']
    rescue = (repair+.5)/(factual_failure+1.)
    injury = (damage+.5)/(factual_success+1.)
    rescue_var = rescue*(1-rescue)/(factual_failure+2.)
    injury_var = injury*(1-injury)/(factual_success+2.)
    conditional_success = np.stack((rescue, 1-injury))
    conditional_success[:, 0] = (0., 1.)
    standardized = (1-baseline)*rescue+baseline*(1-injury)
    standardized[0] = baseline
    variance = (1-baseline)**2*rescue_var+baseline**2*injury_var
    precision = np.where(counts > 0, np.minimum(100., 1./(4*variance+.01)), 0.)
    rhs = precision*standardized+ridge*np.asarray(prior)
    row_indices = []; column_indices = []; entries = []
    edge_count = 0
    for a, b in local_edges(options, n):
        futures = sorted(observed_futures.get(a, set()) & observed_futures.get(b, set()))
        if not futures:
            continue
        differences = np.array([observations[b, f]['success']-observations[a, f]['success'] for f in futures])
        weights = np.asarray([future_weights[f] for f in futures])
        strata = np.array([observations[0, f]['success'] for f in futures], dtype=int)
        # Match the factual-success distribution, rather than extrapolating
        # two sampled factual failures to every possible future.
        difference = 0.
        for stratum, population in ((0, 1-baseline), (1, baseline)):
            selected = differences[strata == stratum]
            mass = weights[strata == stratum]
            prior_difference = conditional_success[stratum, b]-conditional_success[stratum, a]
            difference += population*((selected*mass).sum()+prior_difference)/(mass.sum()+1.)
        # Each edge estimates a signed consequence, never a smoothing target.
        weight = edge_weight*weights.sum()
        row_indices.extend((a, b, a, b)); column_indices.extend((a, b, b, a))
        entries.extend((weight, weight, -weight, -weight))
        rhs[b] += weight*difference; rhs[a] -= weight*difference
        edge_count += len(futures)
    # The factual value is measured by its own complete future population.
    # Reusing that node in many noisy contrasts must not move its baseline.
    # Unobserved nodes have only their independent ridge prior. Eliminate
    # them exactly instead of solving a large empty part of the comparison.
    active = np.flatnonzero(counts[1:] > 0)+1
    matrix = sparse.diags(precision+ridge, format='csr')+sparse.coo_matrix(
        (entries, (row_indices, column_indices)), shape=(size, size)).tocsr()
    reduced = matrix[active][:, active].tocsc()
    reduced_rhs = rhs[active]-matrix[active, 0].toarray().ravel()*baseline
    free_value = spsolve(reduced, reduced_rhs) if len(active) else np.empty(0)
    if np.any((free_value < 0.) | (free_value > 1.)):
        from scipy.optimize import minimize
        solution = minimize(lambda x: (.5*x@reduced@x-reduced_rhs@x, reduced@x-reduced_rhs),
            np.clip(free_value, 0., 1.), jac=True, method='L-BFGS-B', bounds=[(0., 1.)]*len(active),
            options=dict(maxiter=200, ftol=1e-10, gtol=1e-7))
        free_value = solution.x
    value = np.asarray(prior).copy(); value[0] = baseline; value[active] = free_value
    # A symmetric variance penalty can reward an unobserved repair stratum:
    # two successful factual continuations say nothing about rescuing a
    # factual failure. Use separate one-sided bounds for rescue and harm.
    from scipy.stats import beta
    paired_count = factual_failure+factual_success
    repair_lower = beta.ppf(.2, repair+.5, factual_failure-repair+.5)
    damage_upper = beta.ppf(.8, damage+.5, factual_success-damage+.5)
    gain_lower = (1-baseline)*repair_lower-baseline*damage_upper
    uncertainty = np.maximum(0., value-baseline-gain_lower)
    uncertainty[0] = 0.
    return value, uncertainty, counts, dict(local_difference_observations=edge_count,
        factual_value=float(baseline), factual_observations=int(raw_counts[0]),
        factual_objective_mass=float(counts[0]), counts_are_objective_weights='future_weights' in root,
        paired_factual_failure=factual_failure.tolist(), paired_factual_success=factual_success.tolist(),
        paired_repair=repair.tolist(), paired_damage=damage.tolist(), paired_count=paired_count.tolist(),
        repair_lower=repair_lower.tolist(), damage_upper=damage_upper.tolist())


class PlainJointReturnDecision(nn.Module):
    """Absolute-return argmax over the shared complete intervention catalog.

    This execution path contains only fitted networks and candidate programs.
    It has no training-state memory, paired-difference correction, factual
    calibration, uncertainty threshold, inherited value stage or support test.
    """
    def __init__(self, width, states, options, defenders, peer_conditioned=True,
                 context_conditioned=True, motion_basis=True, decision_period=5,
                 inference_device=None, residual_potential=False):
        super().__init__()
        self.models = nn.ModuleList([JointTaskPotential(width, peer_conditioned,
            context_conditioned=context_conditioned, motion_basis=motion_basis,
            residual_potential=residual_potential) for _ in states])
        for net, state in zip(self.models, states):
            net.load_state_dict(state)
        self.register_buffer('options', torch.as_tensor(options, dtype=torch.long))
        self.register_buffer('programs', (self.options[:, :1]//(10**torch.arange(defenders))) % 10)
        self.decision_period = decision_period
        self.inference_device = inference_device
        self.prior = None
        self.ordinary = True

    def eligible(self, packet):
        return (packet['node'][:, 0, 15]*400.).round().long() % self.decision_period == 0

    @torch.no_grad()
    def prepare_packet(self, actor, packet, action):
        from conditional_fusion_value import paired_effect_controls
        result = dict(packet)
        if bool(self.eligible(packet).any()):
            result['_ordinary_return_controls'] = paired_effect_controls(actor, packet, action)
        return result

    @torch.no_grad()
    def forward(self, packet, action):
        from conditional_fusion_value import intervention_task_context
        eligible = self.eligible(packet)
        if not bool(eligible.any()):
            return action
        return_device = action.device
        if self.inference_device is not None and self.options.device != torch.device(self.inference_device):
            if str(self.inference_device).startswith('cuda'):
                os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
                torch.use_deterministic_algorithms(True)
                torch.backends.cuda.matmul.allow_tf32 = False
            self.to(self.inference_device)
        context, order = intervention_task_context(packet, True, True)
        if order.shape[1] != self.programs.shape[1]:
            raise ValueError('The return estimator and deployed fleet must have the same size.')
        controls = packet['_ordinary_return_controls'].gather(1, order[..., None].expand(-1, -1, 6))
        context = context.to(self.options.device); controls = controls.to(self.options.device)
        order = order.to(self.options.device); action = action.to(self.options.device)
        eligible = eligible.to(self.options.device)
        responses = response_basis(context, controls) if self.models[0].motion_basis else None
        values = torch.stack([net.forward_catalog(context, controls, self.programs,
            self.options[:, 1:], responses=responses).sigmoid() for net in self.models]).mean(0)
        choice = values.argmax(-1)
        accept = eligible & (choice != 0)
        if not bool(accept.any()):
            return action.to(return_device)
        preference = self.models[0].coefficients[self.programs[choice]]
        preference = preference.gather(1, order.argsort(-1)[..., None].expand(-1, -1, 2))
        delay, span = self.options[choice, 1:].unbind(-1)
        one = torch.ones_like(action[..., :1]); free = -one
        first = torch.where((delay == 0)[:, None, None], preference, free.expand(-1, -1, 2))
        proposed = torch.cat((action[..., :3], free, (delay+span)[:, None, None]*one, 2*free,
            torch.zeros_like(action[..., :2]), delay[:, None, None]*one, first, preference, one), -1)
        factual = torch.cat((action[..., :3], free, one, 2*free, torch.zeros_like(action[..., :2]),
            one, free.expand(-1, -1, 2), free.expand(-1, -1, 2), free), -1)
        return torch.where(accept[:, None, None], proposed, factual).to(return_device)


class LocalDifferenceDecision(nn.Module):
    def __init__(self, width=64, states=(), peer_conditioned=True, ordinary=False,
                 contexts=None, controls=None, options=(), corrections=None, uncertainty=None,
                 observed=None, bandwidth=.12, margin=.08, confidence=.5, global_penalty=.35,
                 decision_period=5, intervention_budget=1, context_time_scale=1., interpolation_power=0.,
                 member_corrections=None, conditional_strata=False, factual_values=None,
                 decision_mode='rolling', project_task_value=False, commit_factual=False,
                 continuation_contexts=None, continuation_controls=None, continuation_values=None,
                 continuation_remaining=None, temporal_value_bounds=False, context_conditioned=False,
                 local_contrast_head=False, projection_strength=2., projection_steps=24, motion_basis=False,
                 align_context_roles=False, joint_factual_calibration=False, comparison_weights_override=None,
                 inference_device=None, stratum_member_corrections=None, stratum_uncertainty=None,
                 stratum_observed=None, replan_delayed=False, intervention_locality=False,
                 residual_potential=False, factual_bound_pruning=False, candidate_bound_pruning=False,
                 stratum_value_bounds=False):
        super().__init__()
        self.conditional_strata = conditional_strata
        self.models = nn.ModuleList([JointTaskPotential(width, peer_conditioned,
            3 if conditional_strata else 1, context_conditioned, local_contrast_head, motion_basis,
            residual_potential) for _ in states])
        for net, state in zip(self.models, states):
            net.load_state_dict(state)
        self.ordinary = ordinary
        self.bandwidth = bandwidth; self.margin = margin; self.confidence = confidence
        self.global_penalty = global_penalty; self.decision_period = decision_period
        self.intervention_budget = intervention_budget; self.prior = None
        self.decision_mode = decision_mode
        self.project_task_value = project_task_value
        self.commit_factual = commit_factual
        self.temporal_value_bounds = temporal_value_bounds
        self.local_contrast_head = local_contrast_head
        self.projection_strength = projection_strength
        self.projection_steps = projection_steps
        self.align_context_roles = align_context_roles
        self.joint_factual_calibration = joint_factual_calibration
        self.inference_device = inference_device
        self.replan_delayed = replan_delayed
        self.intervention_locality = intervention_locality
        self.factual_bound_pruning = factual_bound_pruning
        self.candidate_bound_pruning = candidate_bound_pruning
        self.stratum_value_bounds = stratum_value_bounds
        if intervention_locality and align_context_roles:
            raise ValueError('Intervention locality uses the fitted physical boat correspondence.')
        if decision_mode not in ('rolling', 'complete_plan'):
            raise ValueError('Unknown conditional decision horizon.')
        self.context_time_scale = context_time_scale; self.interpolation_power = interpolation_power
        self.register_buffer('contexts', torch.as_tensor(contexts, dtype=torch.float32))
        self.register_buffer('controls', torch.as_tensor(controls, dtype=torch.float32))
        self.register_buffer('options', torch.as_tensor(options, dtype=torch.long))
        n = self.controls.shape[1]
        self.register_buffer('programs', (self.options[:, :1]//(10**torch.arange(n))) % 10)
        if local_contrast_head:
            pairs = torch.as_tensor(local_edges(options, n), dtype=torch.long)
            degrees = torch.bincount(pairs.flatten(), minlength=len(options)).to(torch.float32)
            weights = projection_strength/(1.+.5*(degrees[pairs[:, 0]]+degrees[pairs[:, 1]]))
            if comparison_weights_override is not None:
                weights = torch.as_tensor(comparison_weights_override, dtype=torch.float32)
                if len(weights) != len(pairs):
                    raise ValueError('The retained local-comparison weights do not match the candidate graph.')
            diagonal = torch.ones(len(options)).index_add(0, pairs[:, 0], weights).index_add(0, pairs[:, 1], weights)
            changed = (self.programs[pairs[:, 0]] != self.programs[pairs[:, 1]]).to(torch.long).argmax(-1)
            self.register_buffer('comparison_pairs', pairs)
            self.register_buffer('comparison_boats', changed)
            self.register_buffer('comparison_weights', weights)
            self.register_buffer('comparison_diagonal', diagonal)
            _, first, inverse = np.unique(self.options[pairs, 0].numpy(), axis=0, return_index=True, return_inverse=True)
            self.register_buffer('comparison_distinct_pairs', pairs[first])
            self.register_buffer('comparison_distinct_boats', changed[first])
            self.register_buffer('comparison_inverse', torch.as_tensor(inverse, dtype=torch.long))
            self.register_buffer('comparison_clock', self.options[pairs, 1:].amax(1).to(torch.float32).log1p()/6.)
        self.register_buffer('corrections', torch.as_tensor(corrections, dtype=torch.float32))
        self.register_buffer('member_corrections', None if member_corrections is None else
                             torch.as_tensor(member_corrections, dtype=torch.float32))
        self.register_buffer('uncertainty', torch.as_tensor(uncertainty, dtype=torch.float32))
        self.register_buffer('observed', torch.as_tensor(observed, dtype=torch.bool))
        for key, value, dtype in (('stratum_member_corrections', stratum_member_corrections, torch.float32),
                                  ('stratum_uncertainty', stratum_uncertainty, torch.float32),
                                  ('stratum_observed', stratum_observed, torch.bool)):
            self.register_buffer(key, None if value is None else torch.as_tensor(value, dtype=dtype))
        if stratum_member_corrections is not None and (ordinary or align_context_roles):
            raise ValueError('Stratified local calibration requires paired learning and the fitted boat correspondence.')
        if align_context_roles:
            positions = self.observed.nonzero()
            self.register_buffer('observation_roots', positions[:, 0])
            self.register_buffer('observation_options', positions[:, 1])
            keys = (self.options[:, 0]*512+self.options[:, 1])*512+self.options[:, 2]
            sorted_keys, lookup_order = keys.sort()
            self.register_buffer('option_keys', sorted_keys)
            self.register_buffer('option_lookup_order', lookup_order)
        self.register_buffer('root_features', state_features(self.contexts, self.controls, context_time_scale))
        self.register_buffer('factual_values', None if factual_values is None else
                             torch.as_tensor(factual_values, dtype=torch.float32))
        if continuation_contexts is None:
            self.register_buffer('continuation_features', None)
            self.register_buffer('continuation_values', None)
            self.register_buffer('continuation_failure_alive', None)
            self.register_buffer('continuation_success_alive', None)
            self.register_buffer('continuation_delay_index', None)
        else:
            features = state_features(torch.as_tensor(continuation_contexts, dtype=torch.float32),
                torch.as_tensor(continuation_controls, dtype=torch.float32), context_time_scale)
            outcomes = torch.as_tensor(continuation_values, dtype=torch.float32)
            remaining = torch.as_tensor(continuation_remaining, dtype=torch.float32)
            delays, index = self.options[:, 1].unique(return_inverse=True)
            alive = (remaining[:, None] > delays[None]).to(torch.float32)
            self.register_buffer('continuation_features', features)
            self.register_buffer('continuation_values', outcomes)
            self.register_buffer('continuation_failure_alive', alive*(1-outcomes[:, None]))
            self.register_buffer('continuation_success_alive', alive*outcomes[:, None])
            self.register_buffer('continuation_delay_index', index)

    def eligible(self, packet):
        tick = (packet['node'][:, 0, 15]*400.).round().long()
        # Evaluate complete finite interventions with a frozen continuation;
        # a rolling controller revisits the choice on the configured clock.
        if self.decision_mode == 'complete_plan':
            return tick == 0
        eligible = tick % self.decision_period == 0
        if not self.ordinary and self.intervention_budget and '_conditional_count' in packet:
            eligible &= packet['_conditional_count'].flatten() < self.intervention_budget
        return eligible

    @torch.no_grad()
    def prepare_packet(self, actor, packet, action):
        from conditional_fusion_value import paired_effect_controls
        result = dict(packet)
        if bool(self.eligible(packet).any()):
            result['_local_difference_controls'] = paired_effect_controls(actor, packet, action)
        return result

    def continuation_statistics(self, context, controls):
        if self.continuation_features is None:
            return None
        features = state_features(context, controls, self.context_time_scale)
        distance = (features[:, None]-self.continuation_features[None]).square().mean(-1)
        kernels = torch.exp(-distance/(2*self.bandwidth**2))
        weights = kernels/(distance+1e-6).pow(self.interpolation_power)
        total = weights.sum(-1)
        success_mass = weights@self.continuation_values
        failure_mass = weights@(1-self.continuation_values)
        factual = success_mass/total.clamp_min(1e-8)
        survival_failure = weights@self.continuation_failure_alive/failure_mass[:, None].clamp_min(1e-8)
        survival_success = weights@self.continuation_success_alive/success_mass[:, None].clamp_min(1e-8)
        # An unobserved factual stratum supplies no survival restriction.
        survival_failure = torch.where(failure_mass[:, None] > 1e-8, survival_failure,
                                       torch.ones_like(survival_failure))
        survival_success = torch.where(success_mass[:, None] > 1e-8, survival_success,
                                       torch.ones_like(survival_success))
        influence = kernels.amax(-1)
        result = (factual, influence, survival_failure[:, self.continuation_delay_index], survival_success[:, self.continuation_delay_index])
        return result+(total,) if self.joint_factual_calibration else result

    def context_relation(self, context, controls):
        features = state_features(context, controls, self.context_time_scale)
        if not self.align_context_roles:
            return (features[:, None]-self.root_features[None]).square().mean(-1), None
        from scipy.optimize import linear_sum_assignment
        n = controls.shape[1]
        query = features[:, :14*n].reshape(-1, n, 14).detach().cpu().numpy()
        reference = self.root_features[:, :14*n].reshape(-1, n, 14).detach().cpu().numpy()
        total = np.empty((len(query), len(reference)), np.float32)
        mapping = np.empty((len(query), len(reference), n), np.int64)
        for b, item in enumerate(query):
            costs = ((item[None, :, None]-reference[:, None])**2).sum(-1)
            for r, cost in enumerate(costs):
                own, source = linear_sum_assignment(cost)
                total[b, r] = cost[own, source].sum()
                mapping[b, r, source] = own
        global_difference = (features[:, None, -5:]-self.root_features[None, :, -5:]).square().sum(-1)
        distance = (torch.as_tensor(total, device=context.device)+global_difference)/features.shape[-1]
        return distance, torch.as_tensor(mapping, device=context.device)

    def aligned_local_statistics(self, weights, kernels, mapping):
        """Transfer complete plans through a physical boat correspondence."""
        roots, options = self.observation_roots, self.observation_options
        b, k = len(weights), len(self.options)
        destination = mapping[:, roots]
        code = (self.programs[options][None]*(10**destination)).sum(-1)
        key = (code*512+self.options[options, 1])*512+self.options[options, 2]
        position = torch.searchsorted(self.option_keys, key).clamp_max(k-1)
        valid = self.option_keys[position] == key
        query_option = self.option_lookup_order[position]
        selected = weights[:, roots]*valid
        mass = weights.new_zeros((b, k)).scatter_add(1, query_option, selected)
        error = weights.new_zeros((b, k)).scatter_add(1, query_option,
            selected*self.uncertainty[roots, options])/mass.clamp_min(1e-8)
        influence = weights.new_zeros((b, k)).scatter_reduce(1, query_option,
            kernels[:, roots]*valid, reduce='amax', include_self=True)
        if self.member_corrections is None:
            residual = weights.new_zeros((b, k)).scatter_add(1, query_option,
                selected*self.corrections[roots, options])/mass.clamp_min(1e-8)
            residual = residual[None]
        else:
            members = self.member_corrections[:, roots, options]
            residual = weights.new_zeros((len(members), b, k)).scatter_add(2,
                query_option[None].expand(len(members), -1, -1), selected[None]*members[:, None])
            residual = residual/mass[None].clamp_min(1e-8)
        return residual, error, influence

    def intervention_distances(self, context, controls, global_distance):
        """Condition transferred differences on the boats the plan changes.

        An unchanged majority must not hide a large change in the intervened
        boat's state or source commands. Whole-fleet and active-boat locality
        must both hold. The factual plan keeps the whole-context metric.
        """
        n = controls.shape[1]
        query = state_features(context, controls, self.context_time_scale)
        boat_difference = (query[:, None, :14*n].reshape(-1, 1, n, 14)-
                           self.root_features[None, :, :14*n].reshape(1, -1, n, 14)).square().sum(-1)
        global_difference = (query[:, None, -5:]-self.root_features[None, :, -5:]).square().sum(-1)
        active = (self.programs > 0).to(query.dtype)
        count = active.sum(-1)
        local = (torch.einsum('brn,kn->brk', boat_difference, active)+global_difference[:, :, None])/(14*count+5)
        local = torch.where(count[None, None] > 0, local, global_distance[:, :, None])
        return torch.maximum(global_distance[:, :, None], local)

    def values(self, context, controls, continuation=None, relation=None, responses=None, factual_only=False,
               stratum=None, candidate_indices=None):
        all_values = []
        if candidate_indices is not None and self.local_contrast_head:
            raise ValueError('Coupled value reconstruction requires its complete comparison graph.')
        programs = self.programs if candidate_indices is None else self.programs[candidate_indices]
        timing = self.options[:, 1:] if candidate_indices is None else self.options[candidate_indices, 1:]
        if responses is None and self.models[0].motion_basis:
            responses = response_basis(context, controls)
        if continuation is None:
            continuation = self.continuation_statistics(context, controls)
        factual_reference = influence = factual_mass = None
        if not self.ordinary and self.factual_values is not None:
            distance, _ = self.context_relation(context, controls) if relation is None else relation
            kernels = torch.exp(-distance/(2*self.bandwidth**2))
            weights = kernels/(distance+1e-6).pow(self.interpolation_power)
            factual_reference = (weights@self.factual_values)/weights.sum(-1).clamp_min(1e-8)
            influence = kernels.amax(-1)
            factual_mass = weights.sum(-1)
        for net in self.models:
            if factual_only:
                raw = net(context, controls,
                    torch.zeros((len(context), controls.shape[1]), dtype=torch.long, device=context.device),
                    torch.zeros((len(context), 2), dtype=torch.long, device=context.device), responses).sigmoid()[:, None]
            else:
                catalog = net.forward_catalog(context, controls, programs, timing,
                                              return_encodings=self.local_contrast_head, responses=responses)
                if self.local_contrast_head:
                    raw, encoded = catalog; raw = raw.sigmoid()
                else:
                    raw = catalog.sigmoid()
            if self.conditional_strata:
                baseline = raw[:, :1, 0]
                if self.joint_factual_calibration and continuation is not None and factual_reference is not None:
                    reference, locality, _, _, mass = continuation
                    # Pool both sets of factual evidence once. In particular,
                    # an approximate branch root must not overwrite an exact
                    # factual trajectory state merely because it is applied last.
                    combined = (mass*reference+factual_mass*factual_reference)/(mass+factual_mass).clamp_min(1e-8)
                    locality = torch.maximum(locality, influence)
                    baseline = (1-locality[:, None])*baseline+locality[:, None]*combined[:, None]
                else:
                    if continuation is not None:
                        reference, locality, _, _ = continuation[:4]
                        baseline = (1-locality[:, None])*baseline+locality[:, None]*reference[:, None]
                    if factual_reference is not None:
                        baseline = (1-influence[:, None])*baseline+influence[:, None]*factual_reference[:, None]
                if stratum is not None:
                    baseline = torch.full_like(baseline, float(stratum))
                values = (1-baseline)*raw[:, :, 1]+baseline*(1-raw[:, :, 2])
                values[:, 0] = baseline[:, 0]
                if self.local_contrast_head and not factual_only:
                    values = self.reconstruct_values(net, encoded, context, values, baseline)
            else:
                values = raw
                if not self.ordinary and factual_reference is not None:
                    reference = factual_reference; locality = influence
                    if continuation is not None:
                        continuation_reference, continuation_locality, _, _, mass = continuation
                        reference = (mass*continuation_reference+factual_mass*reference)/(mass+factual_mass).clamp_min(1e-8)
                        locality = torch.maximum(locality, continuation_locality)
                    baseline = (1-locality[:, None])*values[:, :1]+locality[:, None]*reference[:, None]
                    values = values.clone(); values[:, 0] = baseline[:, 0]
                    if self.local_contrast_head and not factual_only:
                        precision = (1+40*locality/(1-locality+1e-6)).clamp_max(1e4)
                        values = self.reconstruct_values(net, encoded, context, values, baseline, precision)
            all_values.append(values)
        return torch.stack(all_values)

    def reconstruct_values(self, net, encoded, context, prior, baseline, anchor_precision=None):
        """Jointly reconcile learned local differences and complete-plan values.

        Projected Jacobi iterations fit one bounded quadratic potential.
        A factual anchor can be fixed, or have finite precision when its
        uncertain estimate must be reconciled with local comparisons.
        """
        pairs = self.comparison_pairs
        delta = net.catalog_contrasts(context, encoded, self.comparison_distinct_pairs,
            self.comparison_distinct_boats, self.comparison_inverse, self.comparison_clock)
        difference = ((1-baseline)*delta[:, :, 0]+baseline*delta[:, :, 1]
                      if self.conditional_strata else delta[:, :, 0])*self.comparison_weights
        rhs = prior.clone().index_add(1, pairs[:, 1], difference).index_add(1, pairs[:, 0], -difference)
        diagonal = self.comparison_diagonal
        if anchor_precision is not None:
            diagonal = diagonal[None].expand(len(prior), -1).clone()
            diagonal[:, 0] += anchor_precision
            rhs[:, 0] += anchor_precision*baseline[:, 0]
        value = prior
        for _ in range(self.projection_steps):
            message = torch.zeros_like(value).index_add(1, pairs[:, 0], value[:, pairs[:, 1]]*self.comparison_weights)
            message.index_add_(1, pairs[:, 1], value[:, pairs[:, 0]]*self.comparison_weights)
            value = ((rhs+message)/diagonal).clamp(0., 1.)
            if anchor_precision is None:
                value[:, 0] = baseline[:, 0]
        return value

    def combine_stratum_gains(self, gains, baseline, locality, residual):
        if not self.stratum_value_bounds:
            return gains+(1-baseline)*locality[0]*residual[0]+baseline*locality[1]*residual[1]
        failed = gains+locality[0]*residual[0]
        succeeded = gains+locality[1]*residual[1]
        # Conditional on factual failure, a binary task gain is in [0,1].
        # Conditional on factual success, it is in [-1,0]. Enforce these
        # identities before mixing; a bound on the final average alone
        # does not exclude a fictitious gain in the success stratum.
        failed = failed.clamp(0., 1.)
        succeeded = succeeded.clamp(-1., 0.)
        return (1-baseline)*failed+baseline*succeeded

    @torch.no_grad()
    def forward(self, packet, action):
        from conditional_fusion_value import intervention_task_context
        eligible = self.eligible(packet)
        if not bool(eligible.any()):
            return action
        return_device = action.device
        if self.inference_device is not None and self.options.device != torch.device(self.inference_device):
            if torch.device(self.inference_device).type == 'cuda':
                os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
                torch.use_deterministic_algorithms(True)
                torch.backends.cuda.matmul.allow_tf32 = False
            self.to(self.inference_device)
        context, order = intervention_task_context(packet, True, True)
        b, n = order.shape
        if n != self.programs.shape[1]:
            raise ValueError('Fit a fleet-compatible representation before claiming cross-fleet results.')
        controls = packet['_local_difference_controls'].gather(1, order[..., None].expand(-1, -1, 6))
        if context.device != self.options.device:
            context = context.to(self.options.device); controls = controls.to(self.options.device)
            order = order.to(self.options.device); eligible = eligible.to(self.options.device)
            action = action.to(self.options.device)
        continuation = self.continuation_statistics(context, controls)
        relation = None if self.ordinary else self.context_relation(context, controls)
        responses = response_basis(context, controls) if self.models[0].motion_basis else None
        factual_value = None
        if (not self.ordinary and (self.conditional_strata or self.models[0].residual_potential
                                  or self.factual_bound_pruning)
                and self.project_task_value and not self.commit_factual
                and self.confidence >= 0. and self.global_penalty >= 0.):
            factual_value = self.values(context, controls, continuation, relation, responses, factual_only=True)[:, :, 0]
            # Every bounded task potential is at most one. If even this upper
            # bound cannot improve the factual value by the decision margin,
            # no candidate can be admitted; future states are still revisited.
            tolerance = 1e-4 if self.factual_bound_pruning else 1e-6
            eligible &= 1.-factual_value.mean(0) > self.margin-tolerance
            if not bool(eligible.any()):
                return action.to(return_device)
        candidate_indices = None
        if (self.candidate_bound_pruning and factual_value is not None
                and not self.local_contrast_head and not self.intervention_locality
                and relation[1] is None):
            kernels = torch.exp(-relation[0]/(2*self.bandwidth**2))
            reference = factual_value.mean(0)[:, None]
            if self.stratum_member_corrections is not None:
                locality = (kernels[None, :, :, None] *
                            self.stratum_observed[:, None].to(kernels.dtype)).amax(2)
                influence = (1-reference)*locality[0]+reference*locality[1]
            else:
                influence = (kernels[:, :, None]*self.observed[None]).amax(1)
            # A corrected success value cannot exceed one. The global
            # uncertainty term is a lower bound on the total penalty; local
            # uncertainty and ensemble dispersion are both nonnegative.
            upper = 1-reference-self.confidence*(1-influence)*self.global_penalty
            possible = (upper > self.margin-1e-4).any(0)
            possible[0] = True
            candidate_indices = possible.nonzero().flatten()
        reduced = self.values(context, controls, continuation, relation, responses,
                              candidate_indices=candidate_indices)
        if candidate_indices is None:
            estimates = reduced
        else:
            estimates = reduced[:, :, :1].expand(-1, -1, len(self.options)).clone()
            estimates[:, :, candidate_indices] = reduced
        if self.ordinary:
            score = estimates.mean(0)
            choice = score.argmax(-1)
            accept = eligible & (choice != 0)
        else:
            gains = estimates-estimates[:, :, :1]
            distance, mapping = relation
            # Continuous confidence, not a training-root admission test.
            kernels = torch.exp(-distance/(2*self.bandwidth**2))
            weights = kernels/(distance+1e-6).pow(self.interpolation_power)
            if self.intervention_locality:
                distance = self.intervention_distances(context, controls, distance)
                kernels = torch.exp(-distance/(2*self.bandwidth**2))
                weights = kernels/(distance+1e-6).pow(self.interpolation_power)
                if self.stratum_member_corrections is not None:
                    mask = self.stratum_observed.to(kernels.dtype)
                    mass = torch.einsum('brk,srk->sbk', weights, mask).clamp_min(1e-8)
                    locality = (kernels[None]*mask[:, None]).amax(2)
                    residual = torch.einsum('brk,smrk->smbk', weights, self.stratum_member_corrections)/mass[:, None]
                    stratum_error = torch.einsum('brk,srk->sbk', weights, self.stratum_uncertainty)/mass
                    baseline = estimates[:, :, :1]
                    corrected_members = self.combine_stratum_gains(gains, baseline, locality, residual)
                    reference = baseline.mean(0)
                    influence = (1-reference)*locality[0]+reference*locality[1]
                    error = ((1-reference)*locality[0]*stratum_error[0]+
                             reference*locality[1]*stratum_error[1])/influence.clamp_min(1e-8)
                else:
                    mass = (weights*self.observed[None]).sum(1).clamp_min(1e-8)
                    influence = (kernels*self.observed[None]).amax(1)
                    members = self.corrections[None] if self.member_corrections is None else self.member_corrections
                    residual = torch.einsum('brk,mrk->mbk', weights, members)/mass[None]
                    error = (weights*self.uncertainty[None]).sum(1)/mass
                    corrected_members = gains+influence[None]*residual
            elif self.stratum_member_corrections is not None:
                # Transfer rescue and damage separately. A net gain measured
                # where the predecessor fails cannot be carried unchanged to
                # a state where that predecessor is likely to succeed.
                mask = self.stratum_observed.to(kernels.dtype)
                mass = torch.einsum('br,srk->sbk', weights, mask).clamp_min(1e-8)
                stratum_error = torch.einsum('br,srk->sbk', weights, self.stratum_uncertainty)/mass
                locality = (kernels[None, :, :, None]*mask[:, None]).amax(2)
                residual = torch.einsum('br,smrk->smbk', weights, self.stratum_member_corrections)/mass[:, None]
                baseline = estimates[:, :, :1]
                corrected_members = self.combine_stratum_gains(gains, baseline, locality, residual)
                reference = baseline.mean(0)
                influence = (1-reference)*locality[0]+reference*locality[1]
                # This is the already locality-weighted conditional error.
                error = ((1-reference)*locality[0]*stratum_error[0]+
                         reference*locality[1]*stratum_error[1])/influence.clamp_min(1e-8)
            elif mapping is not None:
                residual, error, influence = self.aligned_local_statistics(weights, kernels, mapping)
                corrected_members = gains+influence[None]*residual
            else:
                mass = weights @ self.observed.to(kernels.dtype)
                correction = weights @ self.corrections/mass.clamp_min(1e-8)
                error = weights @ self.uncertainty/mass.clamp_min(1e-8)
                # Repeating distant roots must not manufacture local confidence.
                influence = (kernels[:, :, None]*self.observed[None]).amax(1)
                if self.member_corrections is None:
                    corrected_members = gains+influence[None]*correction[None]
                else:
                    residual = torch.einsum('br,mrk->mbk', weights, self.member_corrections)/mass[None].clamp_min(1e-8)
                    corrected_members = gains+influence[None]*residual
            if self.project_task_value:
                # Transporting a local difference to a different context must
                # retain the range of the success-valued task potential. In
                # particular, a factual value of one permits no positive gain.
                reference = estimates[:, :, :1]
                corrected_members = (reference+corrected_members).clamp(0., 1.)-reference
            if self.temporal_value_bounds and continuation is not None:
                _, locality, survive_failure, survive_success = continuation[:4]
                survive_failure = 1-locality[:, None]*(1-survive_failure)
                survive_success = 1-locality[:, None]*(1-survive_success)
                reference = estimates[:, :, :1]
                lower = -reference*survive_success[None]
                upper = (1-reference)*survive_failure[None]
                # Until a delayed intervention starts, its continuation is
                # factual. It cannot repair or damage an already ended task.
                corrected_members = torch.maximum(lower, torch.minimum(upper, corrected_members))
            corrected = corrected_members.mean(0)
            error = influence*error+corrected_members.std(0, unbiased=False)+(1-influence)*self.global_penalty
            score = corrected-self.confidence*error
            score[:, 0] = 0.
            best, choice = score.max(-1)
            accept = eligible & (choice != 0) & (best > self.margin)
        if self.replan_delayed:
            # A future alternative is a reason to continue observing now,
            # not a commitment to suppress every decision until that time.
            # Both estimators reconsider it at the next decision period.
            accept &= self.options[choice, 1] == 0
        if self.ordinary:
            commit = eligible & (choice == 0) & self.commit_factual
        else:
            upper_gain = 1.-estimates[:, :, 0].mean(0)
            commit = eligible & ~accept & (upper_gain <= self.margin) & self.commit_factual
        if not bool((accept | commit).any()):
            return action.to(return_device)
        selected = self.programs[choice]
        preference = self.models[0].coefficients[selected]
        preference = preference.gather(1, order.argsort(-1)[..., None].expand(-1, -1, 2))
        delay, span = self.options[choice, 1:].unbind(-1)
        one = torch.ones_like(action[..., :1]); free = -one
        first = torch.where((delay == 0)[:, None, None], preference, free.expand(-1, -1, 2))
        proposed = torch.cat((action[..., :3], free, (delay+span)[:, None, None]*one, 2*free,
            torch.zeros_like(action[..., :2]), delay[:, None, None]*one, first, preference, one), -1)
        factual = torch.cat((action[..., :3], free, one, 2*free, torch.zeros_like(action[..., :2]),
            one, free.expand(-1, -1, 2), free.expand(-1, -1, 2), free), -1)
        # Retain the explicit terminal-commit option for historical recipes.
        # Current rolling recipes leave commit_factual false and reconsider
        # both factual and deferred alternatives at later observations.
        tick = packet['node'][:, 0, 15].to(action.device)*400.
        remaining = (400-tick.round()).clamp_min(1.)[:, None, None]*one
        committed = torch.cat((action[..., :3], free, remaining, 2*free,
            torch.zeros_like(action[..., :2]), remaining, free.expand(-1, -1, 2),
            free.expand(-1, -1, 2), one), -1)
        factual = torch.where(commit[:, None, None], committed, factual)
        return torch.where(accept[:, None, None], proposed, factual).to(return_device)


def fit_joint_potential(data, output, *, ordinary=False, updates=24000, ensemble_size=3, width=64,
                        edge_weight=4., anchor_weight=2., seed=42, device='cuda:0', bandwidth=.06,
                        margin=.02, confidence=.5, global_penalty=.2, peer_conditioned=True,
                        context_time_scale=20., interpolation_power=2., rank_weight=1., factual_weight=4.,
                        conditional_strata=False, factual_bank=None, factual_bank_weight=1., context_conditioned=True,
                        local_contrast_head=False, projection_strength=2., projection_steps=24, motion_basis=True,
                        joint_factual_calibration=True, balanced_local_sampling=True,
                        stratified_local_calibration=False, intervention_locality=False, residual_potential=False,
                        ordinary_architecture='mlp'):
    if ordinary_architecture not in ('mlp', 'interaction'):
        raise ValueError('Choose the plain MLP or the explicit interaction-return comparator.')
    if ordinary and ordinary_architecture == 'mlp':
        from plain_return import fit_plain_return
        capacity = ensemble_size*(10*width*width+(54+5*context_conditioned+60*motion_basis)*width+1)
        return fit_plain_return(data, output, factual_bank=factual_bank, updates=updates,
            parameter_budget=capacity, seed=seed, device=device, factual_bank_weight=factual_bank_weight)
    roots = [observed_programs(root) for root in data['roots']]
    n = (len(roots[0]['context'])-5)//8
    conditional_strata = bool(conditional_strata and not ordinary)
    local_contrast_head = local_contrast_head if not ordinary else False
    rows, edges, anchors, diagnostics = learning_records(dict(data, roots=roots))
    digest = hashlib.sha256()
    for root in roots:
        digest.update(np.asarray(root['context'], np.float32).tobytes())
        digest.update(np.asarray(root['effect_controls'], np.float32).tobytes())
        digest.update(np.asarray(root['options'], np.int64).tobytes())
        digest.update(np.asarray(root.get('future_weights', np.ones(len(root['futures']))), np.float32).tobytes())
        digest.update(np.asarray([(q, f, item['success']) for (q, f), item in
                                  sorted(root['outcomes'].items())], np.float64).tobytes())
    continuation_context = continuation_controls = continuation_target = continuation_remaining = None
    if factual_bank is not None:
        if factual_bank['predecessor_sha256'] != data['predecessor_sha256']:
            raise ValueError('Continuation supervision requires the common frozen predecessor.')
        arrays = [np.concatenate([record[key] for record in factual_bank['records']]).astype(np.float32)
                  for key in ('contexts', 'controls', 'values', 'remaining')]
        for array in arrays: digest.update(array.tobytes())
        continuation_context, continuation_controls, continuation_target, continuation_remaining = [
            torch.as_tensor(array, device=device) for array in arrays]
    options = [(0, 0, 0)]+sorted({tuple(option) for root in roots for option in root['options'] if option[0]})
    context = torch.as_tensor(np.asarray([r['context'] for r in roots]), dtype=torch.float32, device=device)
    controls = torch.as_tensor(np.asarray([r['effect_controls'] for r in roots]), dtype=torch.float32, device=device)
    root_ids = torch.as_tensor(rows[:, 0], dtype=torch.long, device=device)
    codes = torch.as_tensor(rows[:, 3], dtype=torch.long, device=device)
    digits = (codes[:, None]//(10**torch.arange(n, device=device))) % 10
    timing = torch.as_tensor(rows[:, 4:6], dtype=torch.long, device=device)
    target = torch.as_tensor(rows[:, 6], dtype=torch.float32, device=device)
    factual_labels = np.asarray([roots[int(row[0])]['outcomes'][0, int(row[2])]['success'] for row in rows])
    factual_target = torch.as_tensor(factual_labels, dtype=torch.float32, device=device)
    importance_array = np.asarray([roots[int(row[0])].get('future_weights',
        np.ones(len(roots[int(row[0])]['futures'])))[int(row[2])] for row in rows], np.float32)
    importance = torch.as_tensor(importance_array, device=device)
    standardization = np.ones(len(rows), np.float32)
    factual_population = np.asarray([np.average(
        [v['success'] for (q, f), v in root['outcomes'].items() if q == 0],
        weights=[root.get('future_weights', np.ones(len(root['futures'])))[f]
                 for (q, f), v in root['outcomes'].items() if q == 0]) for root in roots], np.float32)
    if conditional_strata:
        for root_id, root in enumerate(roots):
            baseline = factual_population[root_id]
            for q in range(1, len(root['options'])):
                subset = np.flatnonzero((rows[:, 0] == root_id) & (rows[:, 1] == q))
                for stratum, population in ((0, 1-baseline), (1, baseline)):
                    index = subset[factual_labels[subset] == stratum]
                    if len(index): standardization[index] = population*importance_array[subset].sum()/importance_array[index].sum()
    standardization = torch.as_tensor(standardization, device=device)
    factual_population = torch.as_tensor(factual_population, device=device)
    edge_indices = torch.as_tensor(edges, dtype=torch.long, device=device)
    anchor_indices = torch.as_tensor(anchors, dtype=torch.long, device=device)
    edge_probability = None
    if balanced_local_sampling:
        discordance = rows[edges[:, 0], 6] != rows[edges[:, 1], 6]
        if discordance.any():
            # Consequential single-vessel changes can be rare among neutral
            # neighbours. Allocate half the draws to them, correcting the
            # sampling probabilities below to retain the original objective.
            edge_probability = .5/len(edges)+.5*discordance/discordance.sum()
    candidate_edges = edges[(rows[edges[:, 0], 1] != 0) & (rows[edges[:, 1], 1] != 0)]
    discordant = candidate_edges[rows[candidate_edges[:, 0], 6] != rows[candidate_edges[:, 1], 6]]
    rank_indices = torch.as_tensor(candidate_edges, dtype=torch.long, device=device)
    factual = np.flatnonzero(rows[:, 1] == 0)
    responses = response_basis(context, controls) if motion_basis else None
    continuation_responses = None
    if motion_basis and continuation_context is not None:
        chunks = [response_basis(continuation_context[i:i+128], continuation_controls[i:i+128])
                  for i in range(0, len(continuation_context), 128)]
        continuation_responses = tuple(torch.cat([part[j] for part in chunks]) for j in range(2))
    def select_responses(records, index):
        return None if records is None else tuple(item[index] for item in records)
    torch.manual_seed(seed); rng = np.random.default_rng(seed)
    states = []; losses = []
    per_member = [updates//ensemble_size+int(i < updates % ensemble_size) for i in range(ensemble_size)]
    for member, iterations in enumerate(per_member):
        net = JointTaskPotential(width, peer_conditioned, 3 if conditional_strata else 1,
                                context_conditioned, local_contrast_head, motion_basis, residual_potential).to(device)
        optimizer = torch.optim.AdamW(net.parameters(), lr=8e-4, weight_decay=.005)
        schedule = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, iterations, eta_min=8e-5)
        root_weight = torch.as_tensor(np.ones(len(roots)) if member == 0 else rng.exponential(1., len(roots)),
                                      dtype=torch.float32, device=device)
        def predict(index, condition=False):
            raw = net(context[root_ids[index]], controls[root_ids[index]], digits[index], timing[index],
                      select_responses(responses, root_ids[index]))
            if not conditional_strata:
                return raw
            if condition:
                logits = torch.where(factual_target[index] > .5, -raw[:, 2], raw[:, 1])
                return torch.where(codes[index] == 0, 24.*factual_target[index]-12., logits)
            # Candidate contrasts do not move the independently fitted factual
            # value; they learn repair and damage conditional on that reference.
            factual = factual_population[root_ids[index]]
            value = (1-factual)*raw[:, 1].sigmoid()+factual*(1-raw[:, 2].sigmoid())
            return torch.where(codes[index] == 0, raw[:, 0], torch.logit(value.clamp(1e-6, 1-1e-6)))
        with torch.enable_grad():
            for step in range(iterations):
                ids = torch.as_tensor(rng.integers(len(rows), size=128), device=device)
                logits = predict(ids)
                loss = (F.binary_cross_entropy_with_logits(logits, target[ids], reduction='none')*
                        root_weight[root_ids[ids]]*standardization[ids]*importance[ids]).sum()/importance[ids].sum()
                if continuation_context is not None:
                    index = torch.as_tensor(rng.integers(len(continuation_target), size=64), device=device)
                    factual_logits = net(continuation_context[index], continuation_controls[index],
                        torch.zeros((len(index), n), dtype=torch.long, device=device),
                        torch.zeros((len(index), 2), dtype=torch.long, device=device),
                        select_responses(continuation_responses, index))
                    if conditional_strata: factual_logits = factual_logits[:, 0]
                    # Common factual outcome data also train the ordinary
                    # absolute-return estimator, with the identical weight.
                    loss += factual_bank_weight*F.binary_cross_entropy_with_logits(
                        factual_logits, continuation_target[index])
                if not ordinary:
                    if conditional_strata:
                        candidates = ids[codes[ids] != 0]
                        if len(candidates):
                            loss += .5*(F.binary_cross_entropy_with_logits(predict(candidates, condition=True),
                                target[candidates], reduction='none')*importance[candidates]).sum()/importance[candidates].sum()
                    ref = torch.as_tensor(rng.choice(factual, size=32), device=device)
                    loss += factual_weight*(F.binary_cross_entropy_with_logits(predict(ref), target[ref],
                        reduction='none')*importance[ref]).sum()/importance[ref].sum()
                    for pairs, weight in ((edge_indices, edge_weight), (anchor_indices, anchor_weight)):
                        if not weight:
                            continue
                        probability = edge_probability if pairs is edge_indices else None
                        draw = (rng.integers(len(pairs), size=64) if probability is None else
                                rng.choice(len(pairs), size=64, p=probability))
                        pair = pairs[torch.as_tensor(draw, device=device)]
                        if local_contrast_head and pairs is edge_indices:
                            index = pair.flatten()
                            delta, raw = net.local_contrasts(context[root_ids[index]], controls[root_ids[index]],
                                digits[index], timing[index], return_distribution=net.contrast_categorical,
                                responses=select_responses(responses, root_ids[index]))
                            distribution = None
                            if net.contrast_categorical:
                                delta, distribution = delta
                            stratum = (factual_target[pair[:, 0]].to(torch.long) if conditional_strata else
                                       torch.zeros(len(pair), dtype=torch.long, device=device))
                            predicted_difference = delta.gather(1, stratum[:, None]).flatten()
                            if conditional_strata:
                                conditioned = torch.where(factual_target[index] > .5, -raw[:, 2], raw[:, 1]).sigmoid()
                                conditioned = torch.where(codes[index] == 0, factual_target[index], conditioned)
                            else:
                                conditioned = raw.squeeze(-1).sigmoid()
                            node_difference = conditioned.reshape(-1, 2).diff(dim=1).flatten()
                        else:
                            values = predict(pair.flatten(), condition=conditional_strata).sigmoid().reshape(-1, 2)
                            predicted_difference = values[:, 1]-values[:, 0]
                            node_difference = None
                        difference = target[pair[:, 1]]-target[pair[:, 0]]
                        mass = importance[pair[:, 0]]
                        if probability is not None:
                            mass = mass/torch.as_tensor(len(pairs)*probability[draw], device=device, dtype=mass.dtype)
                        error = (predicted_difference-difference).square()
                        if node_difference is not None:
                            if distribution is not None:
                                selected_distribution = distribution[torch.arange(len(pair), device=device), stratum]
                                error = F.cross_entropy(selected_distribution, (difference+1).to(torch.long), reduction='none')
                            # The endpoint values and local consequence head
                            # jointly fit the same measured single-boat effect.
                            error = error+.5*(node_difference-difference).square()+.25*(node_difference-predicted_difference).square()
                        loss += weight*(error*
                            root_weight[root_ids[pair[:, 0]]]*mass).sum()/mass.sum()
                    if rank_weight and len(rank_indices):
                        pair = rank_indices[torch.as_tensor(rng.integers(len(rank_indices), size=32), device=device)]
                        pair_logits = predict(pair.flatten(), condition=conditional_strata).reshape(-1, 2)
                        preferred = (target[pair[:, 1]] > target[pair[:, 0]]).to(target.dtype)
                        informative = (target[pair[:, 1]] != target[pair[:, 0]]).to(target.dtype)
                        mass = importance[pair[:, 0]]
                        # Normalize over the entire local comparison population.
                        # Conditioning only on discordant outcomes removes their
                        # frequency and can overweight rare task changes relative
                        # to the value-fitting terms.
                        # Neutral futures have zero rank gradient but remain
                        # in its normalization and in the value/difference fit.
                        loss += rank_weight*(F.binary_cross_entropy_with_logits(pair_logits[:, 1]-pair_logits[:, 0],
                            preferred, reduction='none')*informative*mass).sum()/mass.sum()
                optimizer.zero_grad(); loss.backward(); nn.utils.clip_grad_norm_(net.parameters(), 5.); optimizer.step()
                schedule.step()
                if (step+1) % 1000 == 0 or step+1 == iterations:
                    print(dict(phase='joint_potential_fit', ordinary=ordinary, member=member,
                               update=step+1, loss=float(loss.detach())), flush=True)
        states.append({k: v.detach().cpu() for k, v in net.state_dict().items()}); losses.append(float(loss.detach()))
    recipe = dict(width=width, states=states, peer_conditioned=peer_conditioned, ordinary=ordinary,
        context_conditioned=context_conditioned,
        residual_potential=residual_potential,
        motion_basis=motion_basis,
        joint_factual_calibration=joint_factual_calibration and not ordinary,
        intervention_locality=intervention_locality and not ordinary,
        local_contrast_head=local_contrast_head, projection_strength=projection_strength, projection_steps=projection_steps,
        contexts=context.cpu(), controls=controls.cpu(), options=options,
        corrections=np.zeros((len(roots), len(options)), np.float32),
        member_corrections=np.zeros((ensemble_size, len(roots), len(options)), np.float32),
        uncertainty=np.zeros((len(roots), len(options)), np.float32),
        observed=np.zeros((len(roots), len(options)), bool), bandwidth=bandwidth, margin=margin,
        confidence=confidence, global_penalty=global_penalty, decision_period=5, intervention_budget=0,
        context_time_scale=context_time_scale, interpolation_power=interpolation_power,
        conditional_strata=conditional_strata,
        factual_values=factual_population.cpu() if not ordinary else None,
        project_task_value=True, commit_factual=False,
        replan_delayed=False,
        continuation_contexts=None if ordinary or continuation_context is None else continuation_context.cpu(),
        continuation_controls=None if ordinary or continuation_controls is None else continuation_controls.cpu(),
        continuation_values=None if ordinary or continuation_target is None else continuation_target.cpu(),
        continuation_remaining=None if ordinary or continuation_remaining is None else continuation_remaining.cpu(),
        temporal_value_bounds=not ordinary and factual_bank is not None)
    lookup = {option: i for i, option in enumerate(options)}; local_fits = []
    if not ordinary:
        learner = LocalDifferenceDecision(**recipe).to(device).eval()
        with torch.no_grad():
            member_predictions = torch.cat([learner.values(context[i:i+1], controls[i:i+1])
                                            for i in range(len(roots))], 1).cpu().numpy()
            predictions = member_predictions.mean(0)
        for i, root in enumerate(roots):
            mapping = [lookup[tuple(option)] for option in root['options']]
            values, errors, counts, detail = reconcile_root(root, predictions[i, mapping], edge_weight=edge_weight)
            residual = (values-values[0])-(predictions[i, mapping]-predictions[i, 0])
            observed = counts > 0
            recipe['corrections'][i, np.asarray(mapping)[observed]] = residual[observed]
            for member in range(ensemble_size):
                difference = member_predictions[member, i, mapping]-member_predictions[member, i, 0]
                recipe['member_corrections'][member, i, np.asarray(mapping)[observed]] = ((values-values[0])-difference)[observed]
            recipe['uncertainty'][i, np.asarray(mapping)[observed]] = errors[observed]
            recipe['observed'][i, np.asarray(mapping)[observed]] = True
            local_fits.append(detail)
    model = copy.deepcopy(data['model'])
    # This is a fresh whole-mechanism replacement, without inherited stages.
    model['successor_task_value'] = (dict(kind='plain_joint_return', width=width, states=states,
        peer_conditioned=peer_conditioned, context_conditioned=context_conditioned,
        motion_basis=motion_basis, residual_potential=residual_potential,
        options=options, defenders=n, decision_period=5) if ordinary else
        dict(kind='local_difference_joint', **recipe))
    removal = tuple(model.get('mechanism_ablation', (False, False, False)))+(False,)*3
    model['mechanism_ablation'] = (removal[0], False, removal[2])
    model.update(gate_period=1, physical_interventions=True, fixed_intervention_clock=True, success_objective=True)
    model['successor_task_fit'] = dict(ordinary=ordinary, roots=len(roots),
        unique_terminal_observations=data.get('measured_terminal_observations', len(rows)),
        supervised_node_labels=len(rows)+(0 if continuation_target is None else len(continuation_target)),
        reused_delayed_labels=data.get('reused_delayed_labels', 0),
        reused_terminal_prefix_labels=data.get('reused_terminal_prefix_labels', 0),
        paired_local_observations=len(edges), factual_comparisons=len(anchors), updates=updates,
        member_updates=per_member, width=width, seed=seed, objective='absolute return' if ordinary else
        'whole-plan outcome likelihood plus paired single-vessel value differences and factual contrasts',
        local_reconciliation=not ordinary, inherited_stages=False, root_diagnostics=diagnostics,
        return_representation='candidate-interaction network',
        local_fits=local_fits, last_loss=losses, training_data=data.get('training_data'),
        training_observation_sha256=digest.hexdigest(), execution_revision=33,
        difference_weight=edge_weight, factual_contrast_weight=anchor_weight,
        local_rank_weight=0. if ordinary else rank_weight, discordant_local_observations=len(discordant),
        local_rank_sampling='all nonfactual single-vessel comparisons with neutral outcomes in the normalization',
        factual_weight=0. if ordinary else factual_weight, factual_value_anchored=not ordinary,
        context_conditioned_nodes=context_conditioned,
        duration_centered_potential=residual_potential,
        common_motion_response_features=motion_basis,
        learned_single_vessel_contrasts=local_contrast_head,
        probability_corrected_local_sampling=balanced_local_sampling and not ordinary,
        learning_rate_schedule='cosine 0.0008 to 0.00008 over each member budget',
        inference_joint_value_reconstruction=local_contrast_head,
        receding_option_improvement=not ordinary,
        joint_factual_calibration=joint_factual_calibration and not ordinary,
        intervention_conditioned_locality=intervention_locality and not ordinary,
        factual_choice_keeps_future_decisions=True,
        delayed_choice_keeps_future_decisions=False,
        conditional_factual_strata=conditional_strata,
        empirical_factual_reference=not ordinary,
        development_future_weight=data.get('development_future_weight', 1.),
        candidate_catalog='all sampled complete programs, including negative outcomes',
        uncertainty_estimator='separate paired rescue lower and harm upper Beta bounds' if not ordinary else None,
        predecessor_sha256=data.get('predecessor_sha256'),
        factual_trajectory_replays=0 if factual_bank is None else factual_bank['trajectories'],
        paired_continuation_state_labels=0 if factual_bank is None else factual_bank.get('paired_continuation_state_labels', 0),
        factual_bank_training_data=None if factual_bank is None else factual_bank.get('training_data'),
        additional_factual_state_labels=0 if continuation_target is None else len(continuation_target),
        factual_bank_weight=0. if factual_bank is None else factual_bank_weight,
        simulation_steps=data.get('simulation_steps', 0)+(0 if factual_bank is None else factual_bank['simulation_steps']))
    if stratified_local_calibration and not ordinary:
        del learner
        model = calibrate_conditional_differences(model, data, device=device)
    output = Path(output); output.parent.mkdir(parents=True, exist_ok=True); torch.save(model, output)
    return model


@torch.no_grad()
def calibrate_conditional_differences(model, data, *, device='cuda:0'):
    """Joint local node/edge fits within each observed factual stratum.

    The two fitted conditional consequences are combined only at the query
    state's factual probability. No unobserved rescue or harm is treated as
    empirical evidence. Neural weights, data and optimizer budget are unchanged.
    """
    result = copy.deepcopy(model); recipe = result['successor_task_value']
    if recipe.get('ordinary') or recipe.get('kind') != 'local_difference_joint':
        raise ValueError('Conditional calibration requires the paired-difference learner.')
    conditional_heads = recipe.get('conditional_strata', False)
    roots = [observed_programs(root) for root in data['roots']]
    options = list(map(tuple, np.asarray(recipe['options']).tolist()))
    if len(roots) != len(recipe['contexts']):
        raise ValueError('Calibration roots must match the fitted data.')
    clean = {k: v for k, v in recipe.items() if k not in
             ('kind', 'stratum_member_corrections', 'stratum_uncertainty', 'stratum_observed')}
    learner = LocalDifferenceDecision(**clean).to(device).eval()
    members = len(learner.models); shape = (2, len(roots), len(options))
    corrections = np.zeros((2, members, len(roots), len(options)), np.float32)
    uncertainty = np.zeros(shape, np.float32); observed = np.zeros(shape, bool)
    lookup = {q: i for i, q in enumerate(options)}; supported = [0, 0]
    weight = result['successor_task_fit']['difference_weight']
    for i, root in enumerate(roots):
        mapping = np.asarray([lookup[tuple(q)] for q in root['options']])
        scalar_predictions = None
        if not conditional_heads:
            scalar_predictions = learner.values(learner.contexts[i:i+1],
                learner.controls[i:i+1])[:, 0].cpu().numpy()
        for stratum in (0, 1):
            outcomes = {key: value for key, value in root['outcomes'].items()
                if (0, key[1]) in root['outcomes'] and
                int(root['outcomes'][0, key[1]]['success']) == stratum}
            if not outcomes or not any(q for q, _ in outcomes):
                continue
            subset = dict(root, outcomes=outcomes)
            if conditional_heads:
                predictions = learner.values(learner.contexts[i:i+1], learner.controls[i:i+1],
                                              stratum=stratum)[:, 0].cpu().numpy()
                differences = predictions[:, mapping]-stratum
                prior = predictions[:, mapping]
            else:
                differences = scalar_predictions[:, mapping]-scalar_predictions[:, :1]
                prior = np.clip(stratum+differences, 0., 1.)
            values, errors, counts, _ = reconcile_root(subset, prior.mean(0), edge_weight=weight)
            available = counts > 0; selected = mapping[available]
            for member in range(members):
                residual = (values-stratum)-differences[member]
                corrections[stratum, member, i, selected] = residual[available]
            uncertainty[stratum, i, selected] = errors[available]
            observed[stratum, i, selected] = True
            supported[stratum] += 1
    recipe.update(stratum_member_corrections=corrections, stratum_uncertainty=uncertainty,
                  stratum_observed=observed)
    result['successor_task_fit'].update(execution_revision=26 if conditional_heads else 36,
        conditional_local_difference_calibration=True, calibrated_factual_stratum_roots=supported,
        conditional_local_calibration='separate anchored joint node/edge objectives, query-state factual mixture',
        calibration_value_model='conditional heads' if conditional_heads else 'shared scalar task potential')
    return result


def limit_decision_windows(model, *, maximum_delay=0, maximum_span=None, decision_period=1):
    """Replan from current observations instead of freezing a long prefix.

    Both estimators can use this common action menu. Training labels and
    parameters stay intact. The retained graph weights preserve every local
    value equation because windows only share the fixed factual node.
    """
    result = copy.deepcopy(model); recipe = result['successor_task_value']
    if recipe['kind'] != 'local_difference_joint':
        raise ValueError('Window selection applies to the local-intervention estimator.')
    options = np.asarray(recipe['options'], dtype=np.int64)
    keep = options[:, 1] <= maximum_delay
    if maximum_span is not None:
        keep &= options[:, 2] <= maximum_span
    keep[0] = True
    selected = np.flatnonzero(keep)
    if recipe.get('local_contrast_head'):
        n = np.asarray(recipe['controls']).shape[1]
        pairs = torch.as_tensor(local_edges(options.tolist(), n), dtype=torch.long)
        if recipe.get('comparison_weights_override') is None:
            degrees = torch.bincount(pairs.flatten(), minlength=len(options)).to(torch.float32)
            weights = recipe.get('projection_strength', 2.)/(1.+.5*(degrees[pairs[:, 0]]+degrees[pairs[:, 1]]))
        else:
            weights = torch.as_tensor(recipe['comparison_weights_override'])
        surviving = keep[pairs.numpy()].all(1)
        index = np.full(len(options), -1, np.int64); index[selected] = np.arange(len(selected))
        expected = np.asarray(local_edges(options[selected].tolist(), n))
        if not np.array_equal(index[pairs.numpy()[surviving]], expected):
            raise ValueError('Window restriction changed the retained single-vessel comparisons.')
        recipe['comparison_weights_override'] = weights[surviving]
    recipe['options'] = [tuple(row) for row in options[selected].tolist()]
    for key in ('corrections', 'uncertainty', 'observed'):
        recipe[key] = np.asarray(recipe[key])[:, selected].copy()
    if recipe.get('member_corrections') is not None:
        recipe['member_corrections'] = np.asarray(recipe['member_corrections'])[:, :, selected].copy()
    for key in ('stratum_member_corrections', 'stratum_uncertainty', 'stratum_observed'):
        if recipe.get(key) is not None:
            recipe[key] = np.asarray(recipe[key])[..., selected].copy()
    recipe.update(decision_period=decision_period, intervention_budget=0, commit_factual=False)
    result['successor_task_fit'].update(execution_revision=24,
        current_observation_replanning=True, decision_period=decision_period,
        maximum_intervention_delay=maximum_delay, maximum_intervention_span=maximum_span,
        trained_candidate_options=len(options), executed_candidate_options=len(selected))
    return result


def refresh_local_calibration(model, data, *, device='cuda:0', **changes):
    """Re-estimate the paired potential after changing factual calibration.

    Neural parameters, labels and optimizer updates are held fixed. The local
    residuals must be recomputed against the modified factual-anchored value,
    rather than carrying a residual fitted to a different reference value.
    """
    result = copy.deepcopy(model)
    recipe = result['successor_task_value']
    if recipe['ordinary']:
        raise ValueError('An ordinary-return replacement has no local calibration.')
    if result['successor_task_fit']['predecessor_sha256'] != data['predecessor_sha256']:
        raise ValueError('Recalibration requires the original paired predecessor.')
    recipe.update(changes)
    roots = [observed_programs(root) for root in data['roots']]
    context = torch.as_tensor(np.stack([r['context'] for r in roots]), dtype=torch.float32, device=device)
    controls = torch.as_tensor(np.stack([r['effect_controls'] for r in roots]), dtype=torch.float32, device=device)
    torch.testing.assert_close(context, torch.as_tensor(recipe['contexts'], device=device))
    torch.testing.assert_close(controls, torch.as_tensor(recipe['controls'], device=device))
    learner = LocalDifferenceDecision(**{k: v for k, v in recipe.items() if k != 'kind'}).to(device).eval()
    with torch.no_grad():
        members = torch.cat([learner.values(context[i:i+1], controls[i:i+1])
                             for i in range(len(roots))], 1).cpu().numpy()
    prediction = members.mean(0)
    options = [tuple(option) for option in np.asarray(recipe['options']).tolist()]
    lookup = {option: q for q, option in enumerate(options)}
    recipe['corrections'] = np.zeros((len(roots), len(options)), np.float32)
    recipe['member_corrections'] = np.zeros((len(members), len(roots), len(options)), np.float32)
    recipe['uncertainty'] = np.zeros((len(roots), len(options)), np.float32)
    recipe['observed'] = np.zeros((len(roots), len(options)), bool)
    details = []
    weight = result['successor_task_fit']['difference_weight']
    for i, root in enumerate(roots):
        mapping = np.asarray([lookup[tuple(option)] for option in root['options']])
        value, error, count, detail = reconcile_root(root, prediction[i, mapping], edge_weight=weight)
        observed = count > 0; selected = mapping[observed]
        difference = value-value[0]
        recipe['corrections'][i, selected] = (difference-(prediction[i, mapping]-prediction[i, 0]))[observed]
        for member in range(len(members)):
            recipe['member_corrections'][member, i, selected] = (
                difference-(members[member, i, mapping]-members[member, i, 0]))[observed]
        recipe['uncertainty'][i, selected] = error[observed]
        recipe['observed'][i, selected] = True
        details.append(detail)
    result['successor_task_fit'].update(local_fits=details, execution_revision=22,
        joint_factual_calibration=recipe.get('joint_factual_calibration', False),
        receding_option_improvement=not recipe['intervention_budget'],
        recalibrated_against_current_factual_value=True)
    return result


def development_roots(references, failures=20, successes=4, late=False):
    """Count distinct layouts, rather than repeated noise evaluations."""
    groups = []
    for reference in references:
        selected = []
        seen = set()
        for success, quota in ((False, failures), (True, successes)):
            count = 0
            for (scene, future), row in zip(reference['tasks'], reference['rows']):
                if scene[0] in seen or bool(row['success']) != success:
                    continue
                seen.add(scene[0]); count += 1
                lookback = (40 if row['outcome'] == 2 else 120) if late and not success else None
                selected.append((scene, future, lookback))
                if count >= quota:
                    break
        groups.append(selected)
    return [group[i] for i in range(max(map(len, groups), default=0)) for group in groups if i < len(group)]


def collect_local_tasks(policy, root_tasks, output, *, spans=(10, 40, 200), repetitions=2,
                        confirmation=6, workers=12, seed=42, existing_data=None, adaptive_screen=True,
                        interaction_order=2, screen_limit=0, screen_strategy='fleet_first',
                        neighborhood_centers=0, record_continuations=False, context_policy=None,
                        neighborhood_width=2):
    """Adaptive paired sampling, confirming selected plans on fresh futures.

    The complete outcome table is shared by conditional and ordinary fits.
    Candidate deletion neighbours receive the same confirmation futures.
    """
    import conditional_fusion_value as c
    import develop_source_fusion as d
    import run_remote_evidence as r
    r.initialize_source_branches(str(d.SOURCE))
    policy = Path(policy); output = Path(output); output.parent.mkdir(parents=True, exist_ok=True)
    model = torch.load(policy, map_location='cpu', weights_only=False)
    if model.get('successor_task_value') is not None:
        raise ValueError('Collect a fresh whole-mechanism comparison from F00 or F10.')
    actor = d.joint_load(str(policy), policy.stat().st_mtime_ns)
    behavior = actor if context_policy is None else d.joint_load(
        str(context_policy), Path(context_policy).stat().st_mtime_ns)
    roots = [] if existing_data is None else list(existing_data['roots'])
    known = {(tuple(root['scene']), root['prefix_future'], root['lookback']) for root in roots}
    requested = {(tuple(scene), future, lookback) for scene, future, lookback in root_tasks}
    steps = 0 if existing_data is None else existing_data['simulation_steps']
    coefficients = np.asarray([[-1., -1.]]+[[a, b] for a in (0., .5, 1.) for b in (0., .5, 1.)])
    rng = np.random.default_rng(seed)
    with (ProcessPoolExecutor(max_workers=workers, initializer=r.initialize_source_branches,
          initargs=(str(d.SOURCE),)) if workers > 1 else nullcontext(None)) as pool:
        for scene, prefix_future, lookback in root_tasks:
            key = (tuple(scene), prefix_future, lookback)
            if key in known:
                continue
            np.random.seed(scene[0]); torch.manual_seed(scene[0])
            env = d.numerical_source().TADEnv(scene[1]); obs, _ = env.reset(agility=scene[2], noisy_agility=False)
            if prefix_future is not None: np.random.seed(prefix_future)
            elapsed = 0
            selected_action = None
            if lookback is not None:
                history = []; done = 0
                while not done:
                    before = (elapsed, copy.deepcopy(env), obs.copy(), np.random.get_state())
                    with torch.no_grad(): action = behavior(d.mechanism_tensor(d.joint_packet(env, obs)), deterministic=True)[0][0].numpy()
                    history.append((*before, action.copy()))
                    obs, _, done, _, count = d.joint_advance(env, obs, behavior, action); elapsed += count; steps += count
                if lookback in ('first_intervention', 'last_intervention'):
                    decisions = [h for h in history if h[4].shape[-1] >= 13 and (h[4][:, 11:13] >= 0.).any()]
                    chosen = (decisions[0] if lookback == 'first_intervention' else decisions[-1]) if decisions else history[0]
                else:
                    cutoff = max(0, (elapsed-lookback)//5*5)
                    chosen = max((h for h in history if h[0] <= cutoff), key=lambda h: h[0])
                elapsed, env, obs, state, selected_action = chosen
                np.random.set_state(state)
            tensor = d.mechanism_tensor(d.joint_packet(env, obs))
            with torch.no_grad():
                control = actor(tensor, deterministic=True, gate_only=True)[0][0].numpy()[:, :3]
                context, order = c.intervention_task_context(tensor, True, True)
                effect = c.paired_effect_controls(actor, tensor, torch.as_tensor(control[None]))
            n = scene[1]; inverse = order[0].argsort().numpy()
            codes = connected_programs(tensor, order, interaction_order)
            options = [(0, 0, 0)]+[(code, 0, span) for code in codes for span in spans]
            focus_option = None
            focus_codes = set()
            if selected_action is not None and selected_action.shape[-1] >= 13 and (selected_action[:, 11:13] >= 0.).any():
                # Re-measure the actual decision that reached this context.
                # Only the sampling prefix follows the current learned policy;
                # every paired branch still has the same frozen predecessor.
                preference = selected_action[order[0].numpy(), 11:13]
                digits = ((preference[:, None]-coefficients[None])**2).sum(-1).argmin(-1)
                code = int((digits*(10**np.arange(n))).sum())
                delay = int(selected_action[0, 8]); span = int(selected_action[0, 4])-delay
                focus_option = (code, delay, span)
                neighbors = single_vessel_neighborhood(code, n)
                focus_codes = {code, *neighbors}
                if neighborhood_width and context_policy is not None:
                    # Spend new rollouts on each boat's promising or uncertain
                    # local alternatives. Retain the decision actually made,
                    # its deletion path and every sampled negative outcome.
                    value = behavior.successor_task_value
                    device = next(value.models[0].parameters()).device
                    cc = context.to(device)
                    uu = effect[:, order[0]].to(device)
                    programs = torch.as_tensor((np.asarray(neighbors)[:, None]//(10**np.arange(n))) % 10,
                        dtype=torch.long, device=device)
                    timing = torch.tensor([[delay, span]], device=device).expand(len(neighbors), -1)
                    predictions = []
                    with torch.no_grad():
                        for net in value.models:
                            raw = net(cc.expand(len(neighbors), -1), uu.expand(len(neighbors), -1, -1), programs, timing).sigmoid()
                            if value.conditional_strata:
                                factual = net(cc, uu, torch.zeros((1, n), dtype=torch.long, device=device),
                                    torch.zeros((1, 2), dtype=torch.long, device=device)).sigmoid()[0, 0]
                                raw = (1-factual)*raw[:, 1]+factual*(1-raw[:, 2])
                            predictions.append(raw)
                    predictions = torch.stack(predictions)
                    score = (predictions.mean(0)+predictions.std(0, unbiased=False)).cpu().numpy()
                    center = (code//(10**np.arange(n))) % 10
                    changed = (programs.cpu().numpy() != center).argmax(-1)
                    focus_codes = {code}
                    for boat in range(n):
                        ids = np.flatnonzero(changed == boat)
                        focus_codes.update(neighbors[j] for j in ids[np.argsort(-score[ids], kind='stable')[:neighborhood_width]])
                        if center[boat]:focus_codes.add(code-int(center[boat])*10**boat)
                    parent = code
                    while parent:
                        boat = int(np.flatnonzero((parent//(10**np.arange(n))) % 10)[-1])
                        parent -= (parent//10**boat % 10)*10**boat
                        focus_codes.add(parent)
                options = list(dict.fromkeys(options+
                    [(q, delay, span) if q else (0, 0, 0) for q in sorted(focus_codes)]))
            one = np.ones((n, 1), np.float32)
            def intervention_action(option):
                code, delay, span = option
                if not code:
                    return control
                preference = coefficients[(code//(10**np.arange(n))) % 10][inverse].astype(np.float32)
                first = preference if delay == 0 else np.full_like(preference, -1.)
                return np.concatenate((control, -one, (delay+span)*one, -2*one, np.zeros((n, 2), np.float32),
                    delay*one, first, preference, np.zeros_like(one)), -1)
            actions = [intervention_action(option) for option in options]
            random_state = np.random.get_state()
            futures = [None]+[int(np.random.SeedSequence([scene[0], elapsed, seed, i, 66719]).generate_state(1)[0])
                              for i in range(max(repetitions, confirmation)+1)]
            outcomes = {}
            def sample(keys):
                nonlocal steps
                missing = sorted(set(keys)-outcomes.keys())
                jobs = [(str(policy), dict(environment=env, observation=obs, random_state=random_state, action=actions[q]),
                         scene, futures[f], max(1, options[q][1]+options[q][2]) if record_continuations else 1)
                        for q, f in missing]
                iterator = pool.map(r.source_successor_branch, jobs, chunksize=1) if pool else map(r.source_successor_branch, jobs)
                for entry, row in zip(missing, iterator):
                    outcomes[entry] = dict(success=float(row['success']), outcome=row['outcome'], duration=row['duration'])
                    response = row.get('response')
                    if record_continuations and response is not None and not response['terminal']:
                        # At the end of the finite option, the remaining
                        # trajectory follows the frozen predecessor. Its
                        # already measured terminal result is therefore a
                        # factual-value label at this reached public state.
                        successor = d.mechanism_tensor(response['packet'])
                        with torch.no_grad():
                            native = actor(successor, deterministic=True, gate_only=True)[0]
                            future_context, future_order = c.intervention_task_context(successor, True, True)
                            future_control = c.paired_effect_controls(actor, successor, native)
                        outcomes[entry].update(continuation_context=future_context[0].numpy(),
                            continuation_controls=future_control[0, future_order[0]].numpy(),
                            continuation_remaining=row['physical_steps']-response['steps'])
                    steps += row['physical_steps']
            if adaptive_screen:
                sample((0, f) for f in range(max(repetitions, confirmation)))
                # Search complete fleet plans early, then acquire the local
                # path connecting each successful plan to its predecessor.
                def priority(q):
                    code, delay, span = options[q]
                    digits = (code//(10**np.arange(n))) % 10
                    held = int(np.count_nonzero(digits))
                    rank = 0 if held == n else 1 if held == interaction_order else 2 if held == 2 else 3
                    return (rank, span, code)
                pending = sorted(range(1, len(options)), key=priority)
                if screen_strategy == 'interleaved':
                    groups = {}
                    for q in pending:
                        code, _, span = options[q]
                        held = int(np.count_nonzero((code//(10**np.arange(n))) % 10))
                        groups.setdefault((held, span), []).append(q)
                    pending = [group[k] for k in range(max(map(len, groups.values())))
                               for group in groups.values() if k < len(group)]
                elif screen_strategy != 'fleet_first':
                    raise ValueError('Unknown local-comparison sampling allocation.')
                if screen_limit:
                    limit = max(screen_limit, 48) if context_policy is not None and focus_option is None else screen_limit
                    pending = pending[:limit]
                if focus_option is not None:
                    focused = [q for q in range(1, len(options)) if options[q][1:] == focus_option[1:] and options[q][0] in focus_codes]
                    pending = list(dict.fromkeys(focused+pending))
                screened = []
                for start in range(0, len(pending), 12):
                    batch = pending[start:start+12]
                    sample((q, 0) for q in batch); screened.extend(batch)
                    effective = [q for q in screened if outcomes[q, 0]['success'] > outcomes[0, 0]['success']]
                    if len(effective) >= 3:
                        break
                lookup = {option: i for i, option in enumerate(options)}
                paired = set(screened)
                for q in screened:
                    code, delay, span = options[q]
                    while code:
                        boat = int(np.flatnonzero((code//(10**np.arange(n))) % 10)[-1])
                        code -= (code//10**boat % 10)*10**boat
                        parent = 0 if not code else lookup.get((code, delay, span))
                        if parent is not None: paired.add(parent)
                sample((q, f) for q in paired for f in range(repetitions))
            else:
                sample((q, f) for q in range(len(options)) for f in range(repetitions))
            # Confirm promising full plans and local deletion edges using
            # additional common noise, retaining every negative observation.
            sampled = [q for q in range(1, len(options)) if all((q, f) in outcomes for f in range(repetitions))]
            ranked = sorted(sampled, key=lambda q: (
                -np.mean([outcomes[q, f]['success']-outcomes[0, f]['success'] for f in range(repetitions)]),
                options[q][2], options[q][0]))
            promising = [q for q in ranked if any(outcomes[q, f]['success'] > outcomes[0, f]['success']
                                                 for f in range(repetitions))][:8]
            chosen = set(promising); lookup = {option: i for i, option in enumerate(options)}
            for q in promising:
                code, delay, span = options[q]
                for boat in range(n):
                    digit = code//10**boat % 10
                    if digit:
                        parent = code-digit*10**boat
                        j = 0 if parent == 0 else lookup.get((parent, delay, span))
                        if j is not None: chosen.add(j)
                # Prefix chains make the whole-team alternative identifiable
                # through genuine single-vessel comparisons at every link.
                while code:
                    boat = int(np.flatnonzero((code//(10**np.arange(n))) % 10)[-1])
                    code -= (code//10**boat % 10)*10**boat
                    parent = 0 if not code else lookup.get((code, delay, span))
                    if parent is not None: chosen.add(parent)
            if neighborhood_centers:
                # Complete a genuine one-vessel neighbourhood around strong
                # rivals, not only a deletion path to the factual plan. This
                # includes harmful alternatives and changes between two active
                # coefficients. Both learners receive every measured outcome.
                centers = (promising or ranked)[:neighborhood_centers]
                for q in centers:
                    code, delay, span = options[q]
                    for alternate in single_vessel_neighborhood(code, n):
                        option = (alternate, delay, span) if alternate else (0, 0, 0)
                        if option not in lookup:
                            lookup[option] = len(options); options.append(option)
                            actions.append(intervention_action(option))
                        chosen.add(lookup[option])
                    chosen.add(q)
            if focus_option is not None:
                # Keep the actual decision and selected one-boat comparisons
                # even when another early screen already succeeds.
                chosen.update(q for q, option in enumerate(options) if option[1:] == focus_option[1:] and option[0] in focus_codes)
            chosen.add(0)
            sample((q, f) for q in chosen for f in range(max(repetitions, confirmation)))
            roots.append(dict(context=context[0].numpy(), effect_controls=effect[0, order[0]].numpy(),
                options=options, outcomes=outcomes, futures=futures, scene=scene, prefix_future=prefix_future,
                root_steps=elapsed, lookback=lookback, order=order[0].numpy(),
                sampled_behavior_option=focus_option))
            known.add(key)
            data = dict(model=model, roots=roots, completed=requested <= known, simulation_steps=steps,
                predecessor_sha256=hashlib.sha256(policy.read_bytes()).hexdigest(), training_data=str(output),
                recipe=dict(spans=spans, repetitions=repetitions, confirmation=confirmation, seed=seed,
                            candidate_selection='full outcomes and connected single-vessel local contrasts',
                            adaptive_screen=adaptive_screen, observed_future=True, interaction_order=interaction_order,
                            screen_limit=screen_limit, screen_strategy=screen_strategy,
                            neighborhood_centers=neighborhood_centers, record_continuations=record_continuations,
                            neighborhood_width=neighborhood_width,
                            context_policy=None if context_policy is None else str(context_policy),
                            context_policy_sha256=None if context_policy is None else hashlib.sha256(Path(context_policy).read_bytes()).hexdigest(),
                            branch_continuation='common frozen predecessor'))
            torch.save(data, output)
            print(dict(phase='local_difference_root', roots=len(roots), scene=scene[0], step=elapsed,
                observations=len(outcomes), promising=len(promising), simulation_steps=steps), flush=True)
    return data


def paired_continuation_bank(data):
    """Factual terminal supervision after observed interventions have ended."""
    records = []
    for root in data['roots']:
        for (q, f), value in root['outcomes'].items():
            if 'continuation_context' not in value or value.get('reused_prefix') or value.get('reused_terminal_prefix'):
                continue
            records.append(dict(contexts=value['continuation_context'][None],
                controls=value['continuation_controls'][None], values=np.asarray([value['success']], np.float32),
                remaining=np.asarray([value['continuation_remaining']], np.float32), scene=root['scene'],
                future=root['futures'][f], option=root['options'][q], physical_steps=0))
    return dict(records=records, predecessor_sha256=data['predecessor_sha256'], simulation_steps=0,
        trajectories=len(records), state_labels=len(records), completed=data['completed'],
        supervision='terminal result at observed post-option predecessor states; no extra environment interaction')


def complete_local_pairs(data, references, output, *, candidates=12, workers=6):
    """Complete promising local comparison paths on the development futures.

    Selection uses the already observed conditional consequences. Each selected
    complete plan and its one-vessel deletion path receives the same future
    population, including futures where the factual controller succeeds. All
    measured outcomes are retained for both conditional and ordinary training.
    """
    import conditional_fusion_value as c
    import develop_source_fusion as d
    import run_remote_evidence as r
    policy = Path(references[0]['policy'])
    if hashlib.sha256(policy.read_bytes()).hexdigest() != data['predecessor_sha256']:
        raise ValueError('Complete local comparisons against the measured predecessor.')
    population = {}
    for reference in references:
        if reference['policy_sha256'] != data['predecessor_sha256']:
            raise ValueError('Development futures must use the common predecessor.')
        for (scene, future), outcome in zip(reference['tasks'], reference['rows']):
            population.setdefault(tuple(scene), {})[future] = outcome
    actor = d.joint_load(str(policy), policy.stat().st_mtime_ns)
    r.initialize_source_branches(str(d.SOURCE))
    coefficients = np.asarray([[-1., -1.]]+[[a, b] for a in (0., .5, 1.) for b in (0., .5, 1.)])
    output = Path(output); roots = []; steps = 0
    pending = [root for root in data['roots'] if root['root_steps'] == 0
               and any(not row['success'] for row in population.get(tuple(root['scene']), {}).values())]
    result = dict(model=data['model'], roots=roots, simulation_steps=steps,
        predecessor_sha256=data['predecessor_sha256'], completed=not pending,
        recipe=dict(candidates=candidates, shared_futures=True, single_vessel_paths=True))
    if not pending:
        torch.save(result, output)
        return result
    with (ProcessPoolExecutor(max_workers=workers, initializer=r.initialize_source_branches,
          initargs=(str(d.SOURCE),)) if workers > 1 else nullcontext(None)) as pool:
        for original in pending:
            root = copy.deepcopy(original); scene = tuple(root['scene']); n = scene[1]
            totals = np.zeros(len(root['options'])); counts = totals.copy()
            for (q, future), row in root['outcomes'].items():
                totals[q] += row['success']; counts[q] += 1
            prior = (totals+.5)/(counts+1.)
            values, errors, _, _ = reconcile_root(root, prior)
            gains = values-values[0]
            # Cover both the best estimated gain and the best conservative gain.
            selected = {0}
            for confidence in (0., .5, 1.):
                scores = gains-confidence*errors
                ranking = sorted(range(1, len(scores)), key=lambda q: (-scores[q], root['options'][q]))
                selected.update(q for q in ranking[:candidates] if scores[q] > 0.)
            lookup = {tuple(option): q for q, option in enumerate(root['options'])}
            powers = 10**np.arange(n)
            for q in list(selected):
                code, delay, span = root['options'][q]
                for boat in np.flatnonzero((code//powers) % 10):
                    parent = code-(code//10**boat % 10)*10**boat
                    option = (parent, delay, span) if parent else (0, 0, 0)
                    if option not in lookup:
                        lookup[option] = len(root['options']); root['options'].append(option)
                    selected.add(lookup[option])
                while code:
                    boat = int(np.flatnonzero((code//powers) % 10)[-1])
                    code -= (code//10**boat % 10)*10**boat
                    option = (code, delay, span) if code else (0, 0, 0)
                    if option not in lookup:
                        lookup[option] = len(root['options']); root['options'].append(option)
                    selected.add(lookup[option])
            for future in population[scene]:
                if future not in root['futures']: root['futures'].append(future)
            future_ids = [root['futures'].index(future) for future in population[scene]]
            missing = [(q, f) for q in sorted(selected) for f in future_ids if (q, f) not in root['outcomes']]
            if missing:
                np.random.seed(scene[0]); torch.manual_seed(scene[0])
                env = d.numerical_source().TADEnv(n); obs, _ = env.reset(agility=scene[2], noisy_agility=False)
                packet = d.mechanism_tensor(d.joint_packet(env, obs))
                with torch.no_grad():
                    control = actor(packet, deterministic=True, gate_only=True)[0][0].numpy()[:, :3]
                    context, order = c.intervention_task_context(packet, True, True)
                if not np.allclose(context[0].numpy(), root['context'], atol=1e-6):
                    raise ValueError('Development comparison changed its physical initial state.')
                inverse = order[0].argsort().numpy(); one = np.ones((n, 1), np.float32)
                actions = {0: control}; random_state = np.random.get_state()
                for q in selected-{0}:
                    code, delay, span = root['options'][q]
                    preference = coefficients[(code//powers) % 10][inverse].astype(np.float32)
                    first = preference if delay == 0 else -np.ones_like(preference)
                    actions[q] = np.concatenate((control, -one, (delay+span)*one, -2*one,
                        np.zeros((n, 2), np.float32), delay*one, first, preference, np.zeros_like(one)), -1)
                jobs = [(str(policy), dict(environment=env, observation=obs, random_state=random_state,
                         action=actions[q]), scene, root['futures'][f], 1) for q, f in missing]
                iterator = pool.map(r.source_successor_branch, jobs, chunksize=1) if pool else map(r.source_successor_branch, jobs)
                for index, row in zip(missing, iterator):
                    root['outcomes'][index] = dict(success=float(row['success']), outcome=row['outcome'], duration=row['duration'])
                    steps += row['physical_steps']
            # This artifact records only incremental measured branches. The
            # source snapshot is merged once, preserving its existing labels.
            root['outcomes'] = {key: root['outcomes'][key] for key in missing}
            root.pop('future_weights', None)
            if root['outcomes']: roots.append(root)
            result = dict(model=data['model'], roots=roots, simulation_steps=steps,
                predecessor_sha256=data['predecessor_sha256'], completed=original is pending[-1],
                recipe=dict(candidates=candidates, shared_futures=True, single_vessel_paths=True))
            torch.save(result, output)
            print(dict(phase='complete_development_local_pairs', scene=scene[0], candidates=len(selected),
                measured=len(missing), roots=len(roots), simulation_steps=steps), flush=True)
    return result


def factual_trajectory_states(task):
    """Observe the frozen factual continuation at successive public states."""
    import conditional_fusion_value as c
    import develop_source_fusion as d
    policy, scene, future, expected, period = task
    policy = Path(policy)
    actor = d.joint_load(str(policy), policy.stat().st_mtime_ns, (False, False))
    if actor.successor_task_value is not None:
        raise ValueError('Factual references require the frozen predecessor.')
    np.random.seed(scene[0]); torch.manual_seed(scene[0])
    env = d.numerical_source().TADEnv(scene[1]); obs, _ = env.reset(agility=scene[2], noisy_agility=False)
    if future is not None: np.random.seed(future)
    contexts = []; controls = []; ticks = []; elapsed = done = 0
    while not done:
        packet = d.mechanism_tensor(d.joint_packet(env, obs))
        with torch.no_grad():
            action = actor(packet, deterministic=True)[0][0].numpy()
            if elapsed % period == 0:
                context, order = c.intervention_task_context(packet, True, True)
                effect = c.paired_effect_controls(actor, packet, torch.as_tensor(action[None]))
                contexts.append(context[0].numpy()); controls.append(effect[0, order[0]].numpy()); ticks.append(elapsed)
        obs, _, done, _, count = d.joint_advance(env, obs, actor, action)
        elapsed += count
    outcome = d.outcome(env, done)
    if expected is not None and outcome['success'] != expected:
        raise ValueError('A factual trajectory changed its measured terminal result.')
    return dict(contexts=np.asarray(contexts), controls=np.asarray(controls),
        values=np.full(len(contexts), outcome['success'], np.float32),
        remaining=np.asarray([elapsed-tick for tick in ticks], np.float32),
        scene=scene, future=future, physical_steps=elapsed)


def factual_trajectory_batch(tasks, *, device='cpu'):
    """Measure factual trajectories with batched copies of the same controller."""
    import conditional_fusion_value as c
    import develop_source_fusion as d
    import run_remote_evidence as r
    policy = Path(tasks[0][0])
    actor = d.joint_load(str(policy), policy.stat().st_mtime_ns)
    if actor.successor_task_value is not None:
        raise ValueError('Factual sampling requires the frozen predecessor.')
    jobs = []
    for _, scene, future, _, _ in tasks:
        np.random.seed(scene[0]); torch.manual_seed(scene[0])
        env = d.numerical_source().TADEnv(scene[1])
        obs, _ = env.reset(agility=scene[2], noisy_agility=False)
        if future is not None: np.random.seed(future)
        with torch.no_grad():
            action = actor(d.mechanism_tensor(d.joint_packet(env, obs)), deterministic=True)[0][0].numpy()
        jobs.append(dict(environment=env, observation=obs, action=action,
                         random_state=np.random.get_state()))
    r.SOURCE = d.SOURCE
    measured = r.batched_credit_rows(policy, [(t[1], t[2]) for t in tasks],
        batch_size=len(tasks), device=device, keep_steps=True, initial_jobs=jobs)
    records = []
    actor = d.joint_load(str(policy), policy.stat().st_mtime_ns).to(device)
    try:
        for task, trajectory in zip(tasks, measured):
            _, scene, future, expected, period = task
            row = trajectory['row']; selected = trajectory['steps'][::period]
            if expected is not None and row['success'] != expected:
                # Resolve a discrete decision near a floating-point tie with
                # the canonical single-episode evaluator used by the reference.
                actor.cpu()
                canonical = factual_trajectory_states(task)
                canonical['sampling_steps'] = row['physical_steps']+canonical['physical_steps']
                records.append(canonical)
                actor.to(device)
                continue
            contexts = []; controls = []
            with torch.no_grad():
                for start in range(0, len(selected), 64):
                    group = selected[start:start+64]
                    packet = {key: torch.as_tensor(np.stack([item['packet'][key] for item in group]),
                              device=device) for key in group[0]['packet']}
                    native = actor(packet, deterministic=True, gate_only=True)[0]
                    context, order = c.intervention_task_context(packet, True, True)
                    effect = c.paired_effect_controls(actor, packet, native)
                    contexts.append(context.cpu().numpy())
                    controls.append(effect.gather(1, order[..., None].expand(-1, -1, 6)).cpu().numpy())
            elapsed = row['physical_steps']
            records.append(dict(contexts=np.concatenate(contexts), controls=np.concatenate(controls),
                values=np.full(len(selected), row['success'], np.float32),
                remaining=np.asarray([elapsed-tick for tick in range(0, elapsed, period)], np.float32),
                scene=scene, future=future, physical_steps=elapsed))
    finally:
        actor.cpu()
    return records


def collect_factual_trajectories(policy, references, output, *, workers=10, period=5,
                                inference_batch=0, inference_device='cpu'):
    """Retain terminal supervision throughout the same factual trajectories.

    These are additional state labels from the same closed-loop episodes,
    not additional independent episodes. The ordinary learner receives the
    identical observations and interaction budget.
    """
    import develop_source_fusion as d
    import run_remote_evidence as r
    from functools import partial
    policy = Path(policy); digest = hashlib.sha256(policy.read_bytes()).hexdigest()
    tasks = []
    for reference in references:
        if reference['policy_sha256'] != digest:
            raise ValueError('Factual trajectory labels require their exact predecessor.')
        tasks.extend((str(policy), scene, future, row['success'], period)
            for (scene, future), row in zip(reference['tasks'], reference['rows']))
    output = Path(output)
    saved = torch.load(output, map_location='cpu', weights_only=False) if output.exists() else None
    if saved is not None and (saved['predecessor_sha256'] != digest or saved['period'] != period):
        raise ValueError('The saved factual trajectories use a different predecessor or recording period.')
    records = [] if saved is None else saved['records']
    steps = 0 if saved is None else saved['simulation_steps']
    known = {(tuple(record['scene']), record['future']) for record in records}
    expected = {(tuple(scene), future) for _, scene, future, _, _ in tasks}
    if not known <= expected:
        raise ValueError('The saved factual trajectories use a different task set.')
    if known == expected:
        return saved
    pending = [task for task in tasks if (tuple(task[1]), task[2]) not in known]
    with (ProcessPoolExecutor(max_workers=workers, initializer=r.initialize_source_branches,
          initargs=(str(d.SOURCE),)) if workers > 1 else nullcontext(None)) as pool:
        if inference_batch:
            groups = [pending[start:start+inference_batch] for start in range(0, len(pending), inference_batch)]
            measure = partial(factual_trajectory_batch, device=inference_device)
            measured = pool.map(measure, groups, chunksize=1) if pool else map(measure, groups)
            iterator = (record for batch in measured for record in batch)
        else:
            iterator = (pool.map(factual_trajectory_states, pending, chunksize=1)
                        if pool else map(factual_trajectory_states, pending))
        for record in iterator:
            records.append(record); steps += record.get('sampling_steps', record['physical_steps'])
            if len(records) % 32 == 0 or len(records) == len(tasks):
                bank = dict(records=records, predecessor_sha256=digest, simulation_steps=steps,
                    trajectories=len(records), state_labels=sum(len(row['values']) for row in records),
                    completed=len(records) == len(tasks), period=period,
                    inference_batch=inference_batch, inference_device=inference_device)
                torch.save(bank, output)
                print(dict(phase='factual_continuation_states', trajectories=len(records),
                    state_labels=bank['state_labels'], simulation_steps=steps), flush=True)
    return bank


def factual_bank_from_model(model, data):
    """Recover the exact fitted factual observations retained in a checkpoint."""
    value = model['successor_task_value']
    fit = model['successor_task_fit']
    record = {}
    for key, field in (('contexts', 'continuation_contexts'), ('controls', 'continuation_controls'),
                       ('values', 'continuation_values'), ('remaining', 'continuation_remaining')):
        if value.get(field) is None:
            raise ValueError('The reference checkpoint does not retain its factual observations.')
        record[key] = torch.as_tensor(value[field]).cpu().numpy().copy()
    return dict(records=[record], predecessor_sha256=data['predecessor_sha256'],
        simulation_steps=fit['simulation_steps']-data['simulation_steps'],
        trajectories=fit['factual_trajectory_replays'], state_labels=len(record['values']),
        paired_continuation_state_labels=fit.get('paired_continuation_state_labels', 0),
        training_data=fit.get('factual_bank_training_data'), completed=True)


def source_successor_batches(tasks, *, batch_size=128, device='cpu'):
    """Batch finite interventions on a frozen predecessor without value stages."""
    import develop_source_fusion as d
    import run_remote_evidence as r
    groups = {}
    for index, (policy, job, scene, future, tick) in enumerate(tasks):
        action = job['action']
        if action.shape[-1] == 14:
            if np.any(action[:, 13] != 0):
                raise ValueError('Batched predecessor sampling cannot traverse a value-stage chain.')
            # With no value module, the depth-zero delayed prefix is the same
            # per-tick native predecessor as the free phase of this program.
            job = dict(job, action=action[:, :13].copy())
        groups.setdefault((policy, job['action'].shape[-1]), []).append((index, job, scene, future, tick))
    result = [None]*len(tasks)
    r.SOURCE = d.SOURCE
    for (policy, _), group in groups.items():
        actor = d.joint_load(str(policy), Path(policy).stat().st_mtime_ns)
        if actor.successor_task_value is not None:
            raise ValueError('Batched local comparisons require a predecessor without M2.')
        rows = r.batched_credit_rows(policy, [(scene, future) for _, _, scene, future, _ in group],
            batch_size=batch_size, device=device, initial_jobs=[job for _, job, _, _, _ in group],
            response_tick=[tick for _, _, _, _, tick in group])
        for (index, _, _, _, _), row in zip(group, rows):
            result[index] = row
    return result


def recollect_local_design(policy, blueprint, output, *, simulation_budget, workers=4,
                           inference_batch=0, inference_device='cpu'):
    """Re-measure a local comparison design under a replacement predecessor.

    Layouts, futures and complete intervention programs come from the common
    design. States, source controls and every terminal label are regenerated.
    Prefixes follow the replacement itself; no reference value or teacher
    action is imported. Behaviour-triggered reference roots retain their
    recorded physical clock under the replacement. The physical-step cap
    includes prefix simulation.
    """
    import conditional_fusion_value as c
    import develop_source_fusion as d
    import run_remote_evidence as r
    from functools import partial
    policy = Path(policy); output = Path(output)
    digest = hashlib.sha256(policy.read_bytes()).hexdigest()
    model = torch.load(policy, map_location='cpu', weights_only=False)
    if model.get('successor_task_value') is not None:
        raise ValueError('Replacement sampling requires its frozen controller without M2.')
    r.initialize_source_branches(str(d.SOURCE))
    actor = d.joint_load(str(policy), policy.stat().st_mtime_ns)
    result = (torch.load(output, map_location='cpu', weights_only=False) if output.exists() else
              dict(model=model, roots=[], predecessor_sha256=digest, simulation_steps=0,
                   next_design_root=0, completed=False, training_data=str(output),
                   simulation_budget=int(simulation_budget), inherited_labels=False))
    if result['predecessor_sha256'] != digest or result['simulation_budget'] != simulation_budget:
        raise ValueError('The saved replacement data belongs to a different predecessor or budget.')
    if result['completed']:
        return result
    result.update(inference_batch=inference_batch, inference_device=inference_device)
    coefficients = np.asarray([[-1., -1.]]+[[a, b] for a in (0., .5, 1.) for b in (0., .5, 1.)])
    with (ProcessPoolExecutor(max_workers=workers, initializer=r.initialize_source_branches,
          initargs=(str(d.SOURCE),)) if workers > 1 else nullcontext(None)) as pool:
        for design_id in range(result['next_design_root'], len(blueprint['roots'])):
            if simulation_budget-result['simulation_steps'] < 800:
                break
            original = observed_programs(blueprint['roots'][design_id])
            scene = tuple(original['scene']); future = original['prefix_future']
            np.random.seed(scene[0]); torch.manual_seed(scene[0])
            env = d.numerical_source().TADEnv(scene[1])
            obs, _ = env.reset(agility=scene[2], noisy_agility=False)
            if future is not None: np.random.seed(future)
            elapsed = done = 0
            history = []
            if original['root_steps']:
                lookback = original.get('lookback')
                if isinstance(lookback, str) and lookback not in ('first_intervention', 'last_intervention'):
                    raise ValueError(f'Unknown reference root timing: {lookback}')
                clock_target = (original['root_steps'] if lookback is None or
                                isinstance(lookback, str) else None)
                while not done:
                    history.append((elapsed, copy.deepcopy(env), obs.copy(), np.random.get_state()))
                    with torch.no_grad():
                        action = actor(d.mechanism_tensor(d.joint_packet(env, obs)), deterministic=True)[0][0].numpy()
                    obs, _, done, _, count = d.joint_advance(env, obs, actor, action)
                    elapsed += count; result['simulation_steps'] += count
                    if clock_target is not None and elapsed >= clock_target:
                        break
                if not done:
                    history.append((elapsed, copy.deepcopy(env), obs.copy(), np.random.get_state()))
                cutoff = (max(0, elapsed-int(lookback)) if clock_target is None else clock_target)
                elapsed, env, obs, random_state = max(
                    (item for item in history if item[0] <= cutoff), key=lambda item: item[0])
                np.random.set_state(random_state)
            packet = d.mechanism_tensor(d.joint_packet(env, obs))
            with torch.no_grad():
                control = actor(packet, deterministic=True, gate_only=True)[0][0].numpy()[:, :3]
                context, order = c.intervention_task_context(packet, True, True)
                effect = c.paired_effect_controls(actor, packet, torch.as_tensor(control[None]))
            inverse = order[0].argsort().numpy(); one = np.ones((scene[1], 1), np.float32)
            options = list(map(tuple, original['options']))
            actions = []
            for code, delay, span in options:
                if not code:
                    actions.append(control)
                    continue
                preference = coefficients[(code//(10**np.arange(scene[1]))) % 10][inverse].astype(np.float32)
                first = preference if delay == 0 else np.full_like(preference, -1.)
                actions.append(np.concatenate((control, -one, (delay+span)*one, -2*one,
                    np.zeros((scene[1], 2), np.float32), delay*one, first, preference,
                    np.zeros_like(one)), -1))
            random_state = np.random.get_state()
            pending_root = result.get('partial_root')
            if pending_root is not None and (pending_root['design_root'] != design_id or
                    not np.array_equal(pending_root['context'], context[0].numpy())):
                raise ValueError('The saved comparison batch has a different predecessor state.')
            outcomes = {} if pending_root is None else dict(pending_root['outcomes'])
            keys = sorted(original['outcomes'])
            # Complete factual observations before candidate comparisons.
            # Preserve negative as well as positive labels at every root.
            position = len(outcomes)
            if set(outcomes) != set(keys[:position]):
                raise ValueError('The saved comparison batch changed its observation design.')
            remaining_horizon = max(1, 400-elapsed)
            while position < len(keys):
                allowance = (simulation_budget-result['simulation_steps'])//remaining_horizon
                size = min(inference_batch*4 if inference_batch else max(1, workers*2),
                           len(keys)-position, allowance)
                if not size:
                    break
                selected = keys[position:position+size]
                jobs = [(str(policy), dict(environment=env, observation=obs,
                    random_state=random_state, action=actions[q]), scene, original['futures'][f],
                    max(1, options[q][1]+options[q][2])) for q, f in selected]
                if inference_batch:
                    # Similar reference horizons keep inference batches occupied;
                    # all selected comparisons are still measured and restored
                    # to their original order before entering the learning data.
                    schedule = sorted(range(len(jobs)), key=lambda i:
                        original['outcomes'][selected[i]]['duration'])
                    ordered_jobs = [jobs[i] for i in schedule]
                    groups = [ordered_jobs[start:start+inference_batch] for start in range(0, len(jobs), inference_batch)]
                    measure = partial(source_successor_batches, batch_size=inference_batch, device=inference_device)
                    batches = pool.map(measure, groups, chunksize=1) if pool else map(measure, groups)
                    ordered_rows = [row for batch in batches for row in batch]
                    measured = [None]*len(jobs)
                    for index, row in zip(schedule, ordered_rows):
                        measured[index] = row
                else:
                    measured = pool.map(r.source_successor_branch, jobs, chunksize=1) if pool else map(r.source_successor_branch, jobs)
                for key, row in zip(selected, measured):
                    item = dict(success=float(row['success']), outcome=row['outcome'], duration=row['duration'])
                    response = row.get('response')
                    if response is not None and not response['terminal']:
                        successor = d.mechanism_tensor(response['packet'])
                        with torch.no_grad():
                            native = actor(successor, deterministic=True, gate_only=True)[0]
                            later_context, later_order = c.intervention_task_context(successor, True, True)
                            later_control = c.paired_effect_controls(actor, successor, native)
                        item.update(continuation_context=later_context[0].numpy(),
                            continuation_controls=later_control[0, later_order[0]].numpy(),
                            continuation_remaining=row['physical_steps']-response['steps'])
                    outcomes[key] = item
                    result['simulation_steps'] += row['physical_steps']
                position += size
                result['partial_root'] = dict(design_root=design_id, context=context[0].numpy(),
                                               outcomes=outcomes)
                output.parent.mkdir(parents=True, exist_ok=True)
                torch.save(result, output)
                if position % 128 < size or position == len(keys):
                    print(dict(phase='replacement_local_branches', root=design_id+1,
                        observations=position, planned=len(keys), steps=result['simulation_steps'],
                        budget=simulation_budget), flush=True)
            if outcomes:
                result['roots'].append(dict(context=context[0].numpy(),
                    effect_controls=effect[0, order[0]].numpy(), options=options, outcomes=outcomes,
                    futures=list(original['futures']), scene=scene, prefix_future=future,
                    root_steps=elapsed, lookback=original.get('lookback'), order=order[0].numpy(),
                    future_weights=np.asarray(original.get('future_weights',
                        np.ones(len(original['futures']))), np.float32), design_root=design_id))
            result['next_design_root'] = design_id+1
            result.pop('partial_root', None)
            output.parent.mkdir(parents=True, exist_ok=True)
            torch.save(result, output)
            print(dict(phase='replacement_local_comparisons', root=design_id+1,
                roots=len(blueprint['roots']), observations=len(outcomes),
                steps=result['simulation_steps'], budget=simulation_budget), flush=True)
            if position < len(keys):
                break
    result.update(completed=True, measured_terminal_observations=sum(
        len(root['outcomes']) for root in result['roots']))
    torch.save(result, output)
    return result
