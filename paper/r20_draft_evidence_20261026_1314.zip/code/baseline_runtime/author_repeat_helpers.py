class AuthorSourceRepeatPolicy:
    """Pinned source actor with the same per-vessel inference as the controls."""
    def __init__(self, checkpoint, config):
        import sys
        from source_arboids import numerical_source
        source = numerical_source()
        agent = config['agent']
        environment = source.TADEnv(agent['defender_num'], agent['boid_state'], agent['form_reward'])
        adaptive = bool(agent['adaptive'])
        constructor = source.ActorAdap if adaptive else sys.modules[source.SAC.__module__].ActorSAC
        self.actor = constructor(environment.feature1_dim, environment.feature2_dim,
                                 environment.action_dim+int(adaptive), config['rl']['hidden_dim'])
        self.actor.load_state_dict(torch.load(checkpoint, map_location='cpu', weights_only=True), strict=True)
        self.actor.eval()
        self.device = torch.device('cpu')
        self.choose_action = source.SAC.choose_action.__get__(self)
        self.controller = 'RL' if not agent['residual'] else ('AdaRes' if adaptive else 'Res')
        self.environment_options = (agent['boid_state'], agent['form_reward'])

    def __call__(self, observations):
        return np.stack([self.choose_action(row[None], deterministic=True) for row in observations])

def validate_author_source_repeat(directory):
    """Verify the completed budget and the predeclared training checkpoint choice."""
    import csv
    import yaml
    from source_arboids import SOURCE_ROOT, SOURCE_COMMIT
    directory = Path(directory)
    record = torch.load(directory/'source-repeat-result.pth', map_location='cpu', weights_only=False)
    family = record.get('family', 'arboids')
    if (family not in ('arboids', 'rp', 'sac') or not record.get('completed')
            or not record.get('fresh_initialization') or record.get('source_commit') != SOURCE_COMMIT):
        raise ValueError('Baseline evaluation requires a completed independent pinned-source run.')
    config_path = directory/'config.yaml'
    config = yaml.safe_load(config_path.read_text())
    expected = yaml.safe_load((SOURCE_ROOT/'train/configs/train.yaml').read_text())
    expected['agent'].update(defender_num=record.get('training_defenders', 3),
                             adaptive=family == 'arboids', residual=family != 'sac')
    # Earlier repeats set the recorded seed directly before constructing the
    # experiment manager; later repeats additionally serialize it in YAML.
    if 'seed' in config['training']:
        expected['training']['seed'] = record['seed']
    if (config != expected or record['training_steps'] != expected['training']['total_steps']
            or hashlib.sha256(config_path.read_bytes()).hexdigest() != record['configuration_sha256']):
        raise ValueError('The baseline configuration differs from its full-budget source recipe.')
    for name, key in [('adares1.pth', 'checkpoint_sha256'),
                      ('best-development.pth', 'selected_checkpoint_sha256')]:
        if hashlib.sha256((directory/name).read_bytes()).hexdigest() != record.get(key):
            raise ValueError('The completed baseline checkpoint has changed.')
    with (directory/'metrics1.csv').open(newline='') as stream:
        metrics = list(csv.DictReader(stream))
    if not metrics or int(metrics[-1]['step']) != record['training_steps']:
        raise ValueError('The baseline training stream did not reach the recorded budget.')
    # The manager saves the first lexicographic maximum of success and reward.
    best = max(metrics, key=lambda row: (float(row['def_sr']), float(row['reward'])))
    selected = record['development_selection']
    if (int(best['step']) != selected['step'] or any(not np.isclose(float(best[key]), selected[key],
            atol=1e-12, rtol=1e-12) for key in ('def_sr', 'reward'))):
        raise ValueError('The selected baseline is not the recorded training-development maximum.')
    return record, config

def author_source_repeat_episode(task):
    """Use the frozen source dynamics and the common layout/future seed pair."""
    import develop_source_fusion as d
    scene, future, directory, digest = task
    key = (directory, digest)
    if key not in _AUTHOR_REPEAT_POLICIES:
        record, config = validate_author_source_repeat(directory)
        if record['selected_checkpoint_sha256'] != digest:
            raise ValueError('Baseline evaluation is bound to another checkpoint.')
        _AUTHOR_REPEAT_POLICIES[key] = AuthorSourceRepeatPolicy(Path(directory)/'best-development.pth', config)
    policy = _AUTHOR_REPEAT_POLICIES[key]
    seed, defenders, agility = scene
    np.random.seed(int(seed)); torch.manual_seed(int(seed))
    env = d.numerical_source().TADEnv(defenders, *policy.environment_options)
    observations, _ = env.reset(agility=agility, noisy_agility=False)
    if future is not None:
        np.random.seed(int(future))
    done = 0; total = 0.; discount = 1.; steps = 0
    while not done:
        observations, reward, done, _ = env.step(policy(observations), policy.controller)
        total += discount*float(np.mean(reward)); discount *= .99; steps += 1
    row = dict(seed=int(seed), defenders=defenders, agility=agility, **d.outcome(env, done),
               discounted_return=total, environment_protocol='source', conditional_interventions=0,
               physical_steps=steps)
    if future is not None:
        row['future_seed'] = int(future)
    return row