"""Real archived-environment development pipeline; no toy task in this runner.

Example (CPU diagnostic, not formal training):
python -m pcf_mbrl.runner --project archived_project --source assets/source_arboids_seed42.pth \
  --out results/dev --episodes 24 --updates 512 --evaluation-episodes 4
"""
from __future__ import annotations
import argparse
import hashlib
from dataclasses import asdict
import json
from pathlib import Path
import time
import numpy as np
import torch
from .contracts import Protocol
from .archive_env import ArchiveEnv
from .sources import ArchivedSources
from .models import InteractionModel,ContinuationValue
from .planner import FusionPlanner,PlannerConfig
from .training import (collect_complete_episodes,collect_branches,train_value,train_model,
                       prediction_metrics,controller_identity,module_hash,train_multistep)


def summary(rows):
    return {'episodes':len(rows),'successes':sum(r['success'] for r in rows),
            'captures':sum(r['capture'] for r in rows),'collisions':sum(r['collision'] for r in rows),
            'breaches':sum(r['breach'] for r in rows),'timeouts':sum(r['terminal_code']==4 for r in rows),
            'mean_control_latency_ms':float(np.mean([r['latency_mean_ms'] for r in rows])) if rows else None,
            'episode_seed_list':[r['seed'] for r in rows]}


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--project',default='archived_project');ap.add_argument('--source',required=True)
    ap.add_argument('--out',required=True);ap.add_argument('--episodes',type=int,default=24)
    ap.add_argument('--updates',type=int,default=512);ap.add_argument('--evaluation-episodes',type=int,default=4)
    ap.add_argument('--seed',type=int,default=7301);ap.add_argument('--device',default='cpu')
    ap.add_argument('--horizon',type=int,default=8);ap.add_argument('--population',type=int,default=16)
    ap.add_argument('--iterations',type=int,default=2);ap.add_argument('--outer-rounds',type=int,default=1)
    ap.add_argument('--source-kind',choices=['adaptive','sac'],default='adaptive')
    ap.add_argument('--multistep-updates',type=int,default=128);ap.add_argument('--task-weight',type=float,default=.1);ap.add_argument('--no-spatial',action='store_true')
    args=ap.parse_args();out=Path(args.out)
    if (out/'run.json').exists():raise RuntimeError('Run directory already exists; use a new directory to avoid overwriting.')
    out.mkdir(parents=True,exist_ok=True);torch.set_num_threads(1);torch.manual_seed(args.seed);np.random.seed(args.seed)
    p=Protocol();p.save(out/'protocol.json')
    env=ArchiveEnv(args.project,p);src=ArchivedSources(args.project,args.source,args.device,args.source_kind)
    model=InteractionModel(spatial=not args.no_spatial).to(args.device);value=ContinuationValue().to(args.device)
    cfg=PlannerConfig(args.horizon,args.population,args.iterations,min(4,args.population),control_block=4)
    planner=FusionPlanner(model,value,src,p,cfg)
    manifest={'status':'running','evidence_level':'development integration only','arguments':vars(args),
              'protocol':asdict(p),'planner':asdict(cfg),'provenance':env.provenance(),'source_sha256':module_hash(src),
              'model_parameters':sum(x.numel() for x in model.parameters()),'device':args.device,
              'simulation_time_semantics':'offline synchronous numerical simulation; no real-time delay insertion; latency only diagnostic',
              'code_sha256':{str(p.relative_to(Path(__file__).parent)):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path(__file__).parent.glob('*.py')}}
    def write():
        (out/'run.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
    write();t0=time.perf_counter()
    # Same source snapshot bootstrap; its rewards are true complete-task returns.
    train_seeds=list(range(args.seed*10000,args.seed*10000+args.episodes))
    records,source_rows,envsteps=collect_complete_episodes(env,src,train_seeds,[2.,2.5],args.device,
                                                         out=out/'source_training_tasks.jsonl')
    current_id=records[0]['controller_id']
    manifest['source_collection']=summary(source_rows);manifest['real_environment_steps']=envsteps;write()
    # Distinct training roots and explicitly sampled complete fusion plans.
    roots=[]
    for k in range(min(8,args.episodes)):
        env.reset(args.seed*10000+500+k,2.+.5*(k%2))
        for _ in range(20):
            batch=env.batch(args.device)
            with torch.no_grad():
                l,b=src(batch[0][:,-1]);g=src.reference_gates(batch[0][:,-1]);u=g*l+(1-g)*b
            _,done,_=env.step(u[0].cpu().numpy())
            if done:break
        if not env.done:roots.append(env.clone())
    branches,branch_sequences,branchsteps=collect_branches(env,src,roots,4,args.horizon,args.device,args.seed+9)
    all_model_records=records+branches
    manifest['branch_steps']=branchsteps;manifest['branch_roots']=len(roots)
    # Separate geometry family. It is diagnostic, not a final hypothesis test.
    diag,diagrows,diagsteps=collect_complete_episodes(env,src,list(range(args.seed*10000+1000,args.seed*10000+1000+max(2,args.evaluation_episodes))),
                                                     [2.,2.5],args.device,out=out/'diagnostic_source_tasks.jsonl')
    manifest['diagnostic_environment_steps']=diagsteps
    manifest['prediction_before_training']=prediction_metrics(model,diag,args.device)
    torch.save({'training_records':records,'branch_sequences':branch_sequences,'diagnostic_records':diag,'protocol':asdict(p)},out/'development_data.pt')
    write()
    all_logs=[]
    for r in range(args.outer_rounds):
        vlogs=train_value(value,records,current_id,args.updates,seed=args.seed+r,device=args.device)
        mlogs=train_model(model,value,all_model_records,args.updates,task_weight=args.task_weight,seed=args.seed+11+r,device=args.device)
        multilogs=train_multistep(model,value,src,branch_sequences,args.multistep_updates,task_weight=args.task_weight,seed=args.seed+31+r,device=args.device) if args.multistep_updates else []
        all_logs.append({'round':r,'value':vlogs,'model':mlogs,'multistep':multilogs,'evaluated_policy_id':current_id})
        write()
        if r<args.outer_rounds-1:
            policyid=controller_identity(model,value,src,p,cfg)
            new,rows,steps=collect_complete_episodes(env,src,list(range(args.seed*10000+2000+1000*r,args.seed*10000+2000+1000*r+args.episodes)),
                                                   [2.,2.5],args.device,planner,policyid,out/f'planner_collection_{r}.jsonl')
            records=new;all_model_records+=new;current_id=policyid
            manifest['real_environment_steps']+=steps
    manifest['prediction_after_training']=prediction_metrics(model,diag,args.device)
    policyid=controller_identity(model,value,src,p,cfg)
    eval_seeds=list(range(args.seed*10000+1000,args.seed*10000+1000+args.evaluation_episodes))
    if eval_seeds:
        _,rows,steps=collect_complete_episodes(env,src,eval_seeds,[2.,2.5],args.device,planner,policyid,out/'planner_diagnostic_tasks.jsonl')
        manifest['planner_diagnostic']=summary(rows);manifest['paired_source_diagnostic']=summary(diagrows[:len(rows)])
        manifest['paired_success_difference_count']=sum(a['success']-b['success'] for a,b in zip(rows,diagrows))
        manifest['diagnostic_environment_steps']+=steps
    manifest['status']='completed_development_diagnostic';manifest['elapsed_seconds']=time.perf_counter()-t0
    manifest['formal_training_runs']=0;manifest['vrx_trials']=0
    manifest['value_policy_snapshot']=current_id
    manifest['new_planning_policy']=policyid
    (out/'learning.json').write_text(json.dumps(all_logs,indent=2),encoding='utf8')
    torch.save({'model':model.state_dict(),'value':value.state_dict(),'protocol':asdict(p),'planner':asdict(cfg),
                'source_path':str(Path(args.source).resolve()),'source_sha256':module_hash(src),'torch_rng':torch.get_rng_state(),
                'value_policy_snapshot':current_id,'policy_snapshot':policyid,'arguments':vars(args)},out/'development_checkpoint.pt')
    write();print(json.dumps(manifest,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
