"""One task scorer shared by real data and imagined planning.

Terminal reward +1 for capture/holding, -1 for breach/collision.
Potential term has zero terminal potential, gamma=1. Thus each completed
return equals 2*success-1-Phi(initial), not a hidden geometry surrogate.
"""
import torch
from .contracts import Protocol


def events(s, valid, elapsed, p: Protocol):
    pos, apos = s[:, :-1, :2], s[:, -1, :2]
    dv = valid[:, :-1]
    dist_a = torch.linalg.vector_norm(pos-apos[:, None], dim=-1).masked_fill(~dv, float('inf'))
    d = torch.cdist(pos, pos)
    pair = dv[:, :, None] & dv[:, None, :]
    diag = torch.eye(pos.shape[1], dtype=torch.bool, device=s.device)[None]
    d = d.masked_fill(~pair | diag, float('inf'))
    breach = torch.linalg.vector_norm(apos, dim=-1) <= p.target_radius
    collision = d.amin(dim=(-1,-2)) <= p.collision_radius
    capture = dist_a.amin(-1) < p.capture_radius
    timeout = elapsed >= p.time_limit-1e-5
    # Priority is identical to archived paper-parameters-v1.
    code = torch.zeros_like(elapsed, dtype=torch.long)
    code = torch.where(timeout, 4, code)
    code = torch.where(capture, 3, code)
    code = torch.where(collision, 2, code)
    code = torch.where(breach, 1, code)
    return code


def potential(s, valid, p: Protocol):
    """Bounded observed geometry; coefficients are fixed in the protocol."""
    pos, apos = s[:, :-1, :2], s[:, -1, :2]
    dv = valid[:, :-1]
    rel = apos[:, None]-pos
    ds = torch.linalg.vector_norm(rel, dim=-1).clamp_min(1e-6)
    nearest = ds.masked_fill(~dv, float('inf')).amin(-1)
    directions = (rel/ds[..., None])*dv[..., None]
    direction_sum = directions.sum(1)
    norm = torch.linalg.vector_norm(direction_sum, dim=-1)
    target_dir = apos/torch.linalg.vector_norm(apos, dim=-1, keepdim=True).clamp_min(1e-6)
    form = 0.5*(target_dir*direction_sum/norm[:,None].clamp_min(1e-6)).sum(-1)-norm/dv.sum(-1)
    approach = 1-(nearest/60).clamp(0,2)
    return p.potential_weight*(0.5*approach+0.5*form)


def transition_reward(s, next_s, valid, next_elapsed, p: Protocol):
    code = events(next_s, valid, next_elapsed, p)
    done = code != 0
    success = (code == 3) | (code == 4)
    terminal = torch.where(success, torch.ones_like(next_elapsed), -torch.ones_like(next_elapsed))
    terminal = torch.where(done, terminal, torch.zeros_like(terminal))
    next_phi = torch.where(done, torch.zeros_like(terminal), potential(next_s, valid, p))
    return terminal + next_phi-potential(s, valid, p), done, code


def discounted_returns(rewards, dones, gamma=1.0):
    if rewards.ndim != 1 or dones.shape != rewards.shape:
        raise ValueError('One complete trajectory is required.')
    if not bool(dones[-1]):
        raise ValueError('Incomplete trajectories require an explicit bootstrap, not implicit zero.')
    out = torch.zeros_like(rewards)
    v = rewards.new_zeros(())
    for k in reversed(range(len(rewards))):
        v = rewards[k]+gamma*(~dones[k]).to(rewards.dtype)*v
        out[k] = v
    return out
