from __future__ import annotations
import torch
from torch import nn
from .contracts import wrap_angle, validate_state
from .physics import wamv_step, constant_velocity


def tokens(history, action_history, remaining, valid):
    """Histories end at t. action_history[t] means u[t-1], never u[t]."""
    b,l,e,d=history.shape
    if d!=9 or action_history.shape!=(b,l,e,2):
        raise ValueError('Invalid history/action-history shapes.')
    role=history.new_zeros((b,l,e,1));role[:,:,-1]=1
    rem=remaining[:,None,None,None].expand(b,l,e,1)/60
    return torch.cat((history[...,:2]/60,history[...,2:3].sin(),history[...,2:3].cos(),
                      history[...,3:5]/5,history[...,5:6],history[...,6:8]/5,
                      history[...,8:9], action_history/1000,role,rem),-1)


class HistoryEncoder(nn.Module):
    def __init__(self,width=48,heads=4,history_length=6,spatial=True):
        super().__init__()
        self.width,self.history_length,self.spatial=width,history_length,spatial
        self.input=nn.Linear(14,width)
        self.time=nn.Parameter(torch.zeros(history_length,width))
        nn.init.normal_(self.time,std=.01)
        def layer():
            return nn.TransformerEncoderLayer(width,heads,2*width,dropout=0.,activation='gelu',batch_first=True,norm_first=True)
        self.temporal=nn.TransformerEncoder(layer(),1,enable_nested_tensor=False)
        self.entities=nn.TransformerEncoder(layer(),1,enable_nested_tensor=False)

    def forward(self,history,action_history,remaining,valid):
        validate_state(history[:,-1],valid)
        b,l,e,_=history.shape
        if l>self.history_length: raise ValueError('History exceeds configured context.')
        raw=tokens(history,action_history,remaining,valid)
        h=self.input(raw).permute(0,2,1,3).reshape(b*e,l,self.width)
        h=h+self.time[-l:][None]
        causal=torch.triu(torch.ones(l,l,dtype=torch.bool,device=h.device),diagonal=1)
        h=self.temporal(h,mask=causal)[:,-1].reshape(b,e,self.width)
        h=h*valid[...,None]
        if self.spatial:
            h=self.entities(h,src_key_padding_mask=~valid)
        return h*valid[...,None]


class InteractionModel(nn.Module):
    """Control-conditioned causal joint response with local first-step physics.

At t, an attacker's output and defender i's learned acceleration do not see
other agents' not-yet-executed current commands. Joint feedback coupling appears
at subsequent simulated states/history updates. This matches simultaneous action.
"""
    def __init__(self,width=48,heads=4,history_length=6,spatial=True,dt=.2):
        super().__init__();self.dt=dt
        self.encoder=HistoryEncoder(width,heads,history_length,spatial)
        self.decoder=nn.Sequential(nn.Linear(width+2,width),nn.GELU(),nn.Linear(width,3))
        nn.init.zeros_(self.decoder[-1].weight);nn.init.zeros_(self.decoder[-1].bias)
        self.register_buffer('acceleration_scale',torch.tensor([4.,4.,1.]))

    def forward(self,history,action_history,remaining,valid,defender_thrust):
        s=history[:,-1]
        b,e,_=s.shape
        if defender_thrust.shape!=(b,e-1,2): raise ValueError('Wrong defender command shape.')
        h=self.encoder(history,action_history,remaining,valid)
        # Current attacker command is deliberately absent.
        cmd=torch.cat((defender_thrust/1000,s.new_zeros((b,1,2))),1)
        accel=self.decoder(torch.cat((h,cmd),-1)).tanh()*self.acceleration_scale
        nominal=torch.cat((wamv_step(s[:,:-1],defender_thrust,dt=self.dt),
                           constant_velocity(s[:,-1:],dt=self.dt)),1)
        dp=.5*self.dt**2*accel[...,:2]
        dyaw=.5*self.dt**2*accel[...,2:3]
        pred=torch.cat((nominal[...,:2]+dp,
                        wrap_angle(nominal[...,2:3]+dyaw),
                        nominal[...,3:6]+self.dt*accel,
                        nominal[...,6:9]+(self.dt-.05)*accel),-1)
        return torch.where(valid[...,None],pred,s)


class ContinuationValue(nn.Module):
    """Value of one identified feedback-controller snapshot, not CV intervention."""
    def __init__(self,width=48,heads=4,history_length=6):
        super().__init__()
        self.encoder=HistoryEncoder(width,heads,history_length)
        self.readout=nn.Sequential(nn.Linear(3*width+1,2*width),nn.GELU(),nn.Linear(2*width,1))
        nn.init.zeros_(self.readout[-1].weight);nn.init.zeros_(self.readout[-1].bias)

    def forward(self,history,action_history,remaining,valid):
        h=self.encoder(history,action_history,remaining,valid)
        mean=h.sum(1)/valid.sum(1,keepdim=True)
        mx=h.masked_fill(~valid[...,None],-torch.inf).amax(1)
        x=torch.cat((mean,mx,h[:,-1],remaining[:,None]/60),-1)
        # Bound reflects terminal ±1 plus bounded potential correction.
        return 1.5*self.readout(x).squeeze(-1).tanh()


def update_history(history,actions,next_s,defender_thrust):
    b,_,e,_=history.shape
    u=torch.cat((defender_thrust,history.new_zeros((b,1,2))),1)
    return torch.cat((history[:,1:],next_s[:,None]),1),torch.cat((actions[:,1:],u[:,None]),1)


def state_loss(pred,true,valid):
    """Scale-normalized Huber errors; heading error is periodic."""
    diff=pred-true
    diff=torch.cat((diff[...,:2]/2,wrap_angle(diff[...,2:3]),diff[...,3:5]/2,
                    diff[...,5:6],diff[...,6:8]/2,diff[...,8:9]),-1)
    loss=torch.nn.functional.smooth_l1_loss(diff,torch.zeros_like(diff),reduction='none').mean(-1)
    return (loss*valid).sum()/valid.sum().clamp_min(1)
