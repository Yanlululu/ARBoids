"""Tensor version of the uploaded WAM-V nominal integrator.

The archive uses world-frame velocity_r and clockwise-positive NED yaw.
No unobserved future currents or attacker commands enter the nominal model.
"""
import torch
from .contracts import wrap_angle


def wamv_step(s, thrust, dt=0.2, inner_dt=0.05):
    if s.shape[:-1] != thrust.shape[:-1] or s.shape[-1] != 9 or thrust.shape[-1] != 2:
        raise ValueError('WAMV step shape mismatch.')
    steps = round(dt / inner_dt)
    if abs(steps * inner_dt - dt) > 1e-7:
        raise ValueError('dt must be a multiple of inner_dt.')
    p, yaw, v = s[..., :2], s[..., 2], s[..., 3:6]
    for _ in range(steps):
        legacy = v
        p = p + inner_dt * v[..., :2]
        yaw = wrap_angle(yaw + inner_dt * v[..., 2])
        c, ss = yaw.cos(), yaw.sin()
        u = c*v[..., 0] + ss*v[..., 1]
        w = -ss*v[..., 0] + c*v[..., 1]
        r = v[..., 2]
        ax = (400*r*w - (100+150*u.abs())*u + thrust.sum(-1))/380
        ay = (-380*r*u - (100+150*w.abs())*w)/400
        ar = (-20*u*w - (980+950*r.abs())*r + 1.25*(thrust[..., 0]-thrust[..., 1]))/1430
        a = torch.stack((c*ax-ss*ay, ss*ax+c*ay, ar), -1)
        v = v + inner_dt*a
    return torch.cat((p, yaw.unsqueeze(-1), v, legacy), -1)


def constant_velocity(s, dt=0.2):
    return torch.cat((s[..., :2]+dt*s[..., 3:5],
                      wrap_angle(s[..., 2]+dt*s[..., 5]).unsqueeze(-1),
                      s[..., 3:6], s[..., 3:6]), -1)
