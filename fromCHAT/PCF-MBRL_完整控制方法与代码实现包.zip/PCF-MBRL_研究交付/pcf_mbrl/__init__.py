"""Predictive cooperative fusion research implementation.

All numbers produced by this package carry a protocol and controller identity.
The included archive integration is a development run, not a published result.
"""
__version__ = '0.1.0'
