from __future__ import annotations
import copy
import hashlib
import json
import time
from pathlib import Path
import numpy as np
import torch
from .contracts import blend
from .models import update_history,state_loss
from .reward import discounted_returns


def module_hash(module):
    digest=hashlib.sha256()
    for key,value in sorted(module.state_dict().items()):
        digest.update(key.encode());digest.update(value.detach().cpu().numpy().tobytes())
    return digest.hexdigest()


def controller_identity(model,value,sources,protocol,planner_config):
    from dataclasses import asdict
    obj={'model':module_hash(model),'value':module_hash(value),'sources':module_hash(sources),
         'protocol':protocol.fingerprint(),'planner':asdict(planner_config)}
    return hashlib.sha256(json.dumps(obj,sort_keys=True).encode()).hexdigest()


@torch.no_grad()
def collect_complete_episodes(env,sources,seeds,agilities,device='cpu',planner=None,controller_id=None,out=None):
    """Collect under one fixed controller. Full MC labels only for completed tasks."""
    records=[];episodes=[];step_count=0
    if planner is None: controller_id='source-warmstart:'+module_hash(sources)
    if not controller_id: raise ValueError('Planner snapshot ID required.')
    for ep,seed in enumerate(seeds):
        agility=float(agilities[ep%len(agilities)])
        env.reset(int(seed),agility)
        if planner:planner.reset()
        start=len(records);lat=[];ret=0.;decision_rng=torch.Generator(device=device).manual_seed(int(seed)+17)
        done=False
        while not done:
            batch=env.batch(device);h,a,rem,valid=batch
            st=time.perf_counter()
            if planner:
                gate,meta=planner.plan(*batch,generator=decision_rng)
                evaluated=meta['evaluated_plans_per_state']
            else:
                gate=sources.reference_gates(h[:,-1]);evaluated=0
            learned,rules=sources(h[:,-1]);u=blend(learned,rules,gate)
            physical_thrust=u[0].cpu().numpy()  # Includes device synchronization/transfer in measured latency.
            lat.append(time.perf_counter()-st)
            reward,done,info=env.step(physical_thrust)
            nxt=env.batch(device)
            records.append({'history':h[0].cpu(),'actions':a[0].cpu(),'remaining':rem[0].cpu(),
                            'valid':valid[0].cpu(),'thrust':u[0].cpu(),'gate':gate[0].cpu(),
                            'next_state':nxt[0][0,-1].cpu(),'reward':torch.tensor(reward),
                            'done':torch.tensor(done),'seed':int(seed),'controller_id':controller_id,
                            'evaluated_plans':evaluated})
            ret+=reward;step_count+=1
        rs=torch.stack([r['reward'] for r in records[start:]])
        ds=torch.stack([r['done'] for r in records[start:]])
        targets=discounted_returns(rs,ds,env.protocol.gamma)
        for k,target in enumerate(targets):records[start+k]['return']=target
        row={'seed':int(seed),'agility':agility,'controller_id':controller_id,'steps':len(records)-start,
             **info,'return':ret,'latency_mean_ms':1000*float(np.mean(lat)),
             'latency_p95_ms':1000*float(np.percentile(lat,95)),
             'latency_p99_ms':1000*float(np.percentile(lat,99)),
             'deadline_miss_fraction':float(np.mean(np.array(lat)>env.protocol.dt))}
        episodes.append(row)
        if out:
            Path(out).parent.mkdir(parents=True,exist_ok=True)
            with Path(out).open('a',encoding='utf-8') as f:f.write(json.dumps(row,ensure_ascii=False)+'\n')
    return records,episodes,step_count


@torch.no_grad()
def collect_branches(env,sources,roots,plans_per_root,horizon,device='cpu',seed=0):
    """Actual simulator feedback branches. roots are environment snapshots.

These truncated branches train only the response model. No fake complete
returns are attached and they cannot enter MC value fitting.
"""
    rng=np.random.RandomState(seed);sequences=[];steps=0
    for root_id,root in enumerate(roots):
        for k in range(plans_per_root):
            e=root.clone();seq=[]
            gates=rng.uniform(0,1,(max(1,(horizon+3)//4),e.protocol.defenders,2)).astype('float32')
            for t in range(horizon):
                batch=e.batch(device);h,a,rem,valid=batch
                g=torch.tensor(gates[t//4][None],device=device)
                l,b=sources(h[:,-1]);u=blend(l,b,g)
                reward,done,info=e.step(u[0].cpu().numpy());next_s=e.batch(device)[0][0,-1]
                seq.append({'history':h[0].cpu(),'actions':a[0].cpu(),'remaining':rem[0].cpu(),
                            'valid':valid[0].cpu(),'thrust':u[0].cpu(),'gate':g[0].cpu(),
                            'next_state':next_s.cpu(),'reward':torch.tensor(reward),'done':torch.tensor(done),
                            'root_id':root_id,'candidate_id':k,'controller_id':'branched-feedback:'+module_hash(sources)})
                steps+=1
                if done:break
            sequences.append(seq)
    return [r for seq in sequences for r in seq],sequences,steps


def stack_batch(records,indices,device):
    keys=['history','actions','remaining','valid','thrust','next_state','reward','done']
    batch={key:torch.stack([records[int(j)][key] for j in indices]).to(device) for key in keys}
    return batch


def train_value(value,records,controller_id,updates,batch_size=128,lr=3e-4,seed=0,device='cpu'):
    # Reject unspecified policy mixtures. A branch without complete return cannot fit V.
    selected=[r for r in records if r.get('controller_id')==controller_id and 'return' in r]
    if not selected:raise ValueError('No complete returns for the specified controller snapshot.')
    opt=torch.optim.AdamW(value.parameters(),lr=lr,weight_decay=1e-5)
    value.train().requires_grad_(True);rng=np.random.RandomState(seed);logs=[]
    for step in range(updates):
        ix=rng.randint(0,len(selected),min(batch_size,len(selected)))
        batch=stack_batch(selected,ix,device)
        target=torch.stack([selected[int(j)]['return'] for j in ix]).to(device)
        pred=value(batch['history'],batch['actions'],batch['remaining'],batch['valid'])
        loss=torch.nn.functional.smooth_l1_loss(pred,target)
        opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(value.parameters(),10);opt.step()
        if step==0 or (step+1)%max(1,updates//10)==0:
            logs.append({'update':step+1,'mc_value_loss':float(loss.detach()),'controller_id':controller_id})
    value.eval()
    return logs


def train_model(model,value,records,updates,batch_size=128,lr=3e-4,task_weight=.1,seed=0,device='cpu'):
    """Real one-step dynamics + fixed-continuation-value consistency.

The target value model has no gradients into its parameters; the predicted
history branch remains differentiable. Real terminal transitions have no tail.
"""
    target=copy.deepcopy(value).to(device).eval().requires_grad_(False)
    model.train();opt=torch.optim.AdamW(model.parameters(),lr=lr,weight_decay=1e-5)
    rng=np.random.RandomState(seed);logs=[]
    for step in range(updates):
        ix=rng.randint(0,len(records),min(batch_size,len(records)))
        b=stack_batch(records,ix,device)
        pred=model(b['history'],b['actions'],b['remaining'],b['valid'],b['thrust'])
        motion=state_loss(pred,b['next_state'],b['valid'])
        hp,ap=update_history(b['history'],b['actions'],pred,b['thrust'])
        ht,at=update_history(b['history'],b['actions'],b['next_state'],b['thrust'])
        rem=(b['remaining']-model.dt).clamp_min(0)
        with torch.no_grad():real_value=target(ht,at,rem,b['valid'])
        predicted_value=target(hp,ap,rem,b['valid'])
        alive=(~b['done']).to(pred.dtype)
        task=(((predicted_value-real_value)**2)*alive).sum()/alive.sum().clamp_min(1)
        loss=motion+task_weight*task
        if not torch.isfinite(loss):raise FloatingPointError('Nonfinite model training loss.')
        opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),10);opt.step()
        if step==0 or (step+1)%max(1,updates//10)==0:
            logs.append({'update':step+1,'motion_loss':float(motion.detach()),'task_consistency_loss':float(task.detach()),
                         'total_loss':float(loss.detach()),'task_weight':task_weight})
    if any(p.grad is not None for p in target.parameters()):raise AssertionError('Frozen target acquired gradients.')
    model.eval()
    return logs


@torch.no_grad()
def prediction_metrics(model,records,device='cpu',batch_size=128):
    sums={'position_squared':0.,'velocity_squared':0.,'relative_distance_abs':0.};nodes=0;pairs=0
    for start in range(0,len(records),batch_size):
        b=stack_batch(records,range(start,min(start+batch_size,len(records))),device)
        pred=model(b['history'],b['actions'],b['remaining'],b['valid'],b['thrust'])
        true=b['next_state'];mask=b['valid'];nodes+=int(mask.sum())
        sums['position_squared']+=float((((pred[...,:2]-true[...,:2])**2).sum(-1)*mask).sum())
        sums['velocity_squared']+=float((((pred[...,3:5]-true[...,3:5])**2).sum(-1)*mask).sum())
        pair=mask[:,:,None]&mask[:,None,:]
        pair=pair&torch.triu(torch.ones_like(pair,dtype=torch.bool),diagonal=1)
        err=(torch.cdist(pred[...,:2],pred[...,:2])-torch.cdist(true[...,:2],true[...,:2])).abs()
        sums['relative_distance_abs']+=float(err[pair].sum());pairs+=int(pair.sum())
    return {'one_step_position_rmse_m':(sums['position_squared']/max(nodes,1))**.5,
            'one_step_velocity_rmse_mps':(sums['velocity_squared']/max(nodes,1))**.5,
            'one_step_pair_distance_mae_m':sums['relative_distance_abs']/max(pairs,1),
            'transition_count':len(records)}


def train_multistep(model,value,sources,sequences,updates,batch_size=16,max_steps=4,lr=1e-4,task_weight=.1,seed=0,device='cpu'):
    """Feedback-consistent multistep loss on preselected simulator gate plans.

Only preselected branch plans enter this objective. Future controls are
recomputed from predicted states, exactly as in the deployed planner.
"""
    if not sequences:raise ValueError('No branch sequences.')
    target=copy.deepcopy(value).to(device).eval().requires_grad_(False)
    model.train();opt=torch.optim.AdamW(model.parameters(),lr=lr,weight_decay=1e-5)
    rng=np.random.RandomState(seed);logs=[]
    for update in range(updates):
        selected=[sequences[int(j)] for j in rng.randint(0,len(sequences),min(batch_size,len(sequences)))]
        b0=stack_batch([seq[0] for seq in selected],range(len(selected)),device)
        history,actions,rem,valid=b0['history'],b0['actions'],b0['remaining'],b0['valid']
        motion=history.new_zeros(());task=history.new_zeros(());count=0
        for k in range(min(max_steps,max(map(len,selected)))):
            active=torch.tensor([k<len(seq) for seq in selected],device=device)
            if not bool(active.any()):break
            rows=[seq[min(k,len(seq)-1)] for seq in selected]
            b=stack_batch(rows,range(len(rows)),device)
            gates=torch.stack([row['gate'] for row in rows]).to(device)
            learned,rules=sources(history[:,-1]);u=blend(learned,rules,gates)
            pred=model(history,actions,rem,valid,u)
            motion=motion+state_loss(pred[active],b['next_state'][active],valid[active])
            hp,ap=update_history(history,actions,pred,u)
            ht,at=update_history(b['history'],b['actions'],b['next_state'],b['thrust'])
            next_rem=(rem-model.dt).clamp_min(0)
            with torch.no_grad():truth=target(ht,at,next_rem,valid)
            pv=target(hp,ap,next_rem,valid)
            keep=active&~b['done']
            if bool(keep.any()):task=task+((pv[keep]-truth[keep])**2).mean()
            history=torch.where(active[:,None,None,None],hp,history)
            actions=torch.where(active[:,None,None,None],ap,actions);rem=next_rem;count+=1
        loss=(motion+task_weight*task)/max(count,1)
        if not torch.isfinite(loss):raise FloatingPointError('Nonfinite multistep loss.')
        opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),10);opt.step()
        if update==0 or (update+1)%max(1,updates//5)==0:
            logs.append({'update':update+1,'multistep_motion':float(motion.detach()/count),
                         'multistep_task':float(task.detach()/count),'max_steps':max_steps})
    model.eval();return logs
