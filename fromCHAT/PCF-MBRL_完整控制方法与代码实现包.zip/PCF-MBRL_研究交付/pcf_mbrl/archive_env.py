"""Read-only integration of the user's supplied ARBoids evidence environment."""
from pathlib import Path
from collections import deque
import sys
import copy
import hashlib
import numpy as np
import torch
from .contracts import Protocol
from .reward import transition_reward


class ArchiveEnv:
    def __init__(self,project_root,protocol:Protocol,history_length=6):
        self.root=Path(project_root)
        path=str(self.root/'train')
        if path not in sys.path:sys.path.insert(0,path)
        from envs.TADgame import TADEnv
        self.env=TADEnv(protocol.defenders,protocol='paper-parameters-v1',total_time=protocol.time_limit)
        self.protocol=protocol;self.length=history_length
        self.history=deque(maxlen=history_length);self.actions=deque(maxlen=history_length)
        self.rng=np.random.RandomState(0);self.done=False

    def _rng_call(self,fn,*args,**kw):
        old=np.random.get_state();np.random.set_state(self.rng.get_state())
        try:
            result=fn(*args,**kw);self.rng.set_state(np.random.get_state());return result
        finally:np.random.set_state(old)

    def state(self):
        return np.stack([np.r_[boat.pos,boat.theta,
                               boat.motion_state()[3:],boat.velocity]
                         for boat in [*self.env.defender_list,self.env.attacker]]).astype('float32')

    def reset(self,seed,agility=2.):
        self.rng=np.random.RandomState(seed)
        self._rng_call(self.env.reset,agility=agility,noisy_agility=False)
        self.done=False;self.history.clear();self.actions.clear()
        s=self.state()
        for _ in range(self.length):self.history.append(s.copy());self.actions.append(np.zeros((len(s),2),dtype='float32'))
        return self.batch()

    def batch(self,device='cpu'):
        h=torch.tensor(np.stack(self.history)[None],device=device)
        a=torch.tensor(np.stack(self.actions)[None],device=device)
        rem=torch.tensor([max(0.,self.protocol.time_limit-self.env.Current_T)],device=device,dtype=torch.float32)
        valid=torch.ones(h.shape[0],h.shape[2],dtype=torch.bool,device=device)
        return h,a,rem,valid

    def step(self,thrust):
        if self.done:raise RuntimeError('Cannot step a terminated task.')
        thrust=np.asarray(thrust,dtype=float)
        if thrust.shape!=(self.protocol.defenders,2) or not np.isfinite(thrust).all():raise ValueError('Invalid thrust.')
        if (thrust<self.protocol.thrust_min-1e-4).any() or (thrust>self.protocol.thrust_max+1e-4).any():raise ValueError('Thrust out of range.')
        before=torch.tensor(self.state()[None])
        _,source_rewards,code,_=self._rng_call(self.env.step,np.zeros_like(thrust),controller='Boids',defender_thrust=thrust)
        s=self.state();valid=torch.ones(1,len(s),dtype=torch.bool)
        reward,done,scored=transition_reward(before,torch.tensor(s[None]),valid,torch.tensor([self.env.Current_T]),self.protocol)
        if int(scored)!=int(code):raise AssertionError(f'Archive/scorer terminal mismatch {code}/{int(scored)}')
        self.history.append(s);self.actions.append(np.r_[thrust,np.zeros((1,2))].astype('float32'))
        self.done=bool(done)
        info={'terminal_code':int(code),'success':code in (3,4),'capture':code==3,
              'collision':bool(self.env.physical_events()['collision']),'breach':bool(self.env.physical_events()['breach']),
              'time':self.env.Current_T,'original_reward_mean':float(np.mean(source_rewards))}
        return float(reward),self.done,info

    def clone(self):return copy.deepcopy(self)

    def provenance(self):
        files=['train/envs/TADgame.py','train/envs/modules.py','train/policy/networks.py']
        return {'archive_source':str(self.root), 'protocol':self.protocol.fingerprint(),
                'sha256':{f:hashlib.sha256((self.root/f).read_bytes()).hexdigest() for f in files}}
