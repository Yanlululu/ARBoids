"""Frozen-controller evaluation with explicit final-freeze authorization."""
import argparse
import csv
from dataclasses import replace
import hashlib
import json
from pathlib import Path
import torch
from .contracts import Protocol
from .archive_env import ArchiveEnv
from .sources import ArchivedSources
from .models import InteractionModel,ContinuationValue
from .planner import FusionPlanner,PlannerConfig
from .training import collect_complete_episodes,controller_identity,module_hash
from .runner import summary


def main():
    p=argparse.ArgumentParser();p.add_argument('--checkpoint',required=True);p.add_argument('--project',default='archived_project')
    p.add_argument('--source',required=True);p.add_argument('--out',required=True);p.add_argument('--seed-start',type=int,required=True)
    p.add_argument('--episodes-per-agility',type=int,default=100);p.add_argument('--agilities',type=float,nargs='+',default=[2.,2.5])
    p.add_argument('--defenders',type=int);p.add_argument('--device',default='cpu')
    p.add_argument('--phase',choices=['validation','final'],default='validation');p.add_argument('--freeze-manifest')
    a=p.parse_args();out=Path(a.out)
    if out.exists() and any(out.iterdir()):raise RuntimeError('Output directory is not empty.')
    ckhash=hashlib.sha256(Path(a.checkpoint).read_bytes()).hexdigest()
    if a.phase=='final':
        if not a.freeze_manifest:raise ValueError('Final evaluation requires a frozen-manifest path.')
        freeze=json.loads(Path(a.freeze_manifest).read_text())
        if not freeze.get('final_frozen') or freeze.get('checkpoint_sha256')!=ckhash:
            raise ValueError('Freeze manifest does not authorize this checkpoint.')
        authorized=freeze.get('evaluation_seed_start')
        if authorized!=a.seed_start:raise ValueError('Evaluation seed start does not match the frozen manifest.')
    torch.set_num_threads(1)
    record=torch.load(a.checkpoint,map_location='cpu',weights_only=False)
    proto=Protocol(**record['protocol'])
    if a.defenders:proto=replace(proto,defenders=a.defenders)
    args=record.get('arguments',{})
    src=ArchivedSources(a.project,a.source,a.device,args.get('source_kind','adaptive'))
    if module_hash(src)!=record['source_sha256']:raise ValueError('Source weights differ from the checkpoint training source.')
    model=InteractionModel(spatial=not args.get('no_spatial',False)).to(a.device)
    value=ContinuationValue().to(a.device);model.load_state_dict(record['model']);value.load_state_dict(record['value'])
    config=PlannerConfig(**record['planner']);planner=FusionPlanner(model,value,src,proto,config)
    identity=controller_identity(model,value,src,proto,config)
    env=ArchiveEnv(a.project,proto);out.mkdir(parents=True)
    result={'phase':a.phase,'checkpoint_sha256':ckhash,'controller_id':identity,'agility_results':{},
            'numerical_timing':'offline synchronous; no physics-during-computation claim','training_defenders':record['protocol']['defenders'],
            'evaluation_defenders':proto.defenders,'formal_training_repeats_in_this_file':1}
    allrows=[]
    for agility in a.agilities:
        seeds=list(range(a.seed_start,a.seed_start+a.episodes_per_agility))
        _,rows,steps=collect_complete_episodes(env,src,seeds,[agility],a.device,planner,identity,out/f'tasks_L{agility}.jsonl')
        result['agility_results'][str(agility)]=summary(rows)|{'evaluation_steps':steps};allrows+=rows
        (out/'summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    with (out/'tasks.csv').open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.DictWriter(f,fieldnames=list(allrows[0]));writer.writeheader();writer.writerows(allrows)
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
