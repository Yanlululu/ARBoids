"""Continuous team feedback-composition planning, not fixed CI candidate search."""
from dataclasses import dataclass
import torch
from .contracts import Protocol,blend
from .models import update_history
from .reward import transition_reward

@dataclass
class PlannerConfig:
    horizon: int = 16
    population: int = 64
    iterations: int = 3
    elite: int = 8
    control_block: int = 4
    min_std: float = .08
    terminal_value: bool = True
    warm_start: bool = False


class FusionPlanner:
    def __init__(self,model,value,sources,protocol:Protocol,config:PlannerConfig):
        self.model,self.value,self.sources,self.protocol,self.cfg=model,value,sources,protocol,config
        if not 1<=config.elite<=config.population: raise ValueError('Invalid elite count.')
        if config.warm_start and config.terminal_value:
            raise ValueError('Warm-start planning requires continuation-value input to include solver memory; use warm_start=False in this implementation.')
        self.previous=None

    def reset(self): self.previous=None

    def score(self,history,actions,remaining,valid,plans):
        # Different plans are separate batch elements, never attention tokens.
        if plans.ndim!=5 or plans.shape[0]!=history.shape[0] or plans.shape[-1]!=2:
            raise ValueError('Plans must be [batch,candidates,horizon,defenders,2].')
        b,c,h,n,_=plans.shape
        if h!=self.cfg.horizon or n!=history.shape[2]-1: raise ValueError('Plan horizon/fleet mismatch.')
        def rep(t): return t.repeat_interleave(c,dim=0)
        hist,acts,rem,mask=map(rep,(history,actions,remaining,valid))
        pp=plans.reshape(b*c,h,n,2)
        scores=hist.new_zeros(b*c);alive=torch.ones(b*c,dtype=torch.bool,device=hist.device)
        for k in range(h):
            learned,rules=self.sources(hist[:,-1])
            u=blend(learned,rules,pp[:,k])
            nxt=self.model(hist,acts,rem,mask,u)
            next_rem=(rem-self.protocol.dt).clamp_min(0)
            reward,done,_=transition_reward(hist[:,-1],nxt,mask,self.protocol.time_limit-next_rem,self.protocol)
            scores=scores+(self.protocol.gamma**k)*alive*reward
            next_hist,next_acts=update_history(hist,acts,nxt,u)
            hist=torch.where(alive[:,None,None,None],next_hist,hist)
            acts=torch.where(alive[:,None,None,None],next_acts,acts)
            rem=torch.where(alive,next_rem,rem)
            alive=alive & ~done
        if self.cfg.terminal_value:
            scores=scores+(self.protocol.gamma**h)*alive*self.value(hist,acts,rem,mask)
        return scores.reshape(b,c)

    @torch.no_grad()
    def plan(self,history,actions,remaining,valid,generator=None):
        self.model.eval();self.value.eval();self.sources.eval()
        b,_,e,_=history.shape;n=e-1;cfg=self.cfg
        blocks=(cfg.horizon+cfg.control_block-1)//cfg.control_block
        shape=(b,blocks,n,2)
        mu=history.new_full(shape,.5);std=history.new_full(shape,.4)
        warm=None
        if cfg.warm_start and self.previous is not None and self.previous.shape==(b,cfg.horizon,n,2):
            warm=torch.cat((self.previous[:,1:],self.previous[:,-1:]),1)
            mu=warm[:,::cfg.control_block].clone()
        best_score=history.new_full((b,),-torch.inf);best=None;evaluations=0
        for _ in range(cfg.iterations):
            noise=torch.randn((b,cfg.population,blocks,n,2),device=history.device,dtype=history.dtype,generator=generator)
            sampled=(mu[:,None]+std[:,None]*noise).clamp(0,1)
            sampled[:,0]=mu
            if cfg.population>1:sampled[:,1]=0
            if cfg.population>2:sampled[:,2]=1
            plans=sampled.repeat_interleave(cfg.control_block,dim=2)[:,:,:cfg.horizon]
            if warm is not None and cfg.population>3:plans[:,3]=warm
            scores=self.score(history,actions,remaining,valid,plans)
            evaluations+=cfg.population
            if not torch.isfinite(scores).all(): raise FloatingPointError('Nonfinite planning score.')
            top=scores.topk(cfg.elite,dim=1).indices
            idx=top[...,None,None,None].expand(-1,-1,blocks,n,2)
            elite=torch.gather(sampled,1,idx)
            mu=elite.mean(1);std=elite.std(1,unbiased=False).clamp_min(cfg.min_std)
            value,ix=scores.max(1)
            selected=plans[torch.arange(b,device=history.device),ix]
            if best is None:best=selected.clone()
            best=torch.where((value>best_score)[:,None,None,None],selected,best)
            best_score=torch.maximum(value,best_score)
        self.previous=best.detach().clone()
        return best[:,0],{'plan':best,'score':best_score,'evaluated_plans_per_state':evaluations}
