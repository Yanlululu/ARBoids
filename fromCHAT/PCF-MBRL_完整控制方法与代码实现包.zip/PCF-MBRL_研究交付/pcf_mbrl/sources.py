"""Frozen source commands recomputed at EVERY imagined state.

The archived ActorAdap action head is identified as a jointly-trained source,
not relabeled as independently trained SAC. Its gate is excluded from planning.
"""
import sys
from pathlib import Path
import torch
from torch import nn
from .contracts import wrap_angle


def safe_atan2(y,x):
    zero=(x.abs()+y.abs())<1e-10
    return torch.atan2(torch.where(zero,torch.zeros_like(y),y),torch.where(zero,torch.ones_like(x),x))


def source_observations(s):
    """Exact archive obs/Boids geometry on an unpadded homogeneous fleet."""
    pos, yaw, vel = s[:, :-1, :2], s[:, :-1, 2], s[:, :-1, 6:8]
    apos, av = s[:, -1, :2], s[:, -1, 6:8]
    b,n,_ = pos.shape
    delta = pos[:, :, None]-pos[:, None, :]
    dist = torch.linalg.vector_norm(delta,dim=-1)
    neighbors = (dist < 15) & ~torch.eye(n,dtype=torch.bool,device=s.device)[None]
    separation = (delta/((dist-3.5).clamp_min(.01)**2)[...,None]*neighbors[...,None]).sum(2)
    alignment = vel.mean(1,keepdim=True).expand(-1,n,-1)
    cohesion = pos.mean(1,keepdim=True)-pos
    f = .5*(apos[:,None]-pos)+10*separation+.1*alignment+.1*cohesion
    f = f/torch.linalg.vector_norm(f,dim=-1,keepdim=True).clamp_min(1e-9)
    forward = yaw.cos()*f[...,0]+yaw.sin()*f[...,1]
    lateral = -yaw.sin()*f[...,0]+yaw.cos()*f[...,1]
    angle = safe_atan2(lateral,forward)
    rules = (1000*torch.stack((forward+.75*angle,forward-.75*angle),-1)).clamp(-500,1000)
    def polar(v):
        return torch.stack((torch.linalg.vector_norm(v,dim=-1),wrap_angle(safe_atan2(v[...,1],v[...,0])-yaw)),-1)
    own = torch.cat((polar(-pos),polar(apos[:,None]-pos),polar(av[:,None].expand(-1,n,-1)),
                     polar(separation),polar(alignment),polar(cohesion),(2*rules-500)/1500),-1)
    other = -delta
    other_angle = wrap_angle(safe_atan2(other[...,1],other[...,0])-yaw[:,:,None])
    pair = torch.stack((dist,other_angle),-1)
    offdiag = ~torch.eye(n,dtype=torch.bool,device=s.device)
    pair = pair[:,offdiag].reshape(b,n,2*(n-1))
    return torch.cat((own,pair),-1),rules


class ArchivedSources(nn.Module):
    def __init__(self, project_root, checkpoint, device='cpu', kind='adaptive'):
        super().__init__()
        root=Path(project_root)/'train'
        if str(root) not in sys.path: sys.path.insert(0,str(root))
        from policy.networks import ActorAdap, ActorSAC
        self.kind=kind
        self.actor=(ActorAdap(6,8,3,512) if kind=='adaptive' else ActorSAC(6,8,2,512))
        self.actor.load_state_dict(torch.load(checkpoint,map_location='cpu',weights_only=True),strict=True)
        self.actor.to(device).eval().requires_grad_(False)
        self.checkpoint=str(Path(checkpoint).resolve())

    def forward(self,s):
        obs,rules=source_observations(s)
        b,n,_=obs.shape
        actions,_=self.actor(obs.reshape(b*n,-1),deterministic=True,with_logprob=False)
        actions=actions.reshape(b,n,-1)
        learned=(actions[...,:2]*1500+500)/2
        return learned.clamp(-500,1000),rules

    def reference_gates(self,s):
        obs,_=source_observations(s)
        b,n,_=obs.shape
        a,_=self.actor(obs.reshape(b*n,-1),deterministic=True,with_logprob=False)
        if self.kind!='adaptive': return torch.ones((b,n,2),device=s.device,dtype=s.dtype)
        return a.reshape(b,n,3)[...,2:3].expand(-1,-1,2)
