"""Independent SAC source preparation on the real project environment.

This is the NEW METHOD's learned source, not a relabeled vanilla-SAC benchmark.
It may use Boids warm-start actions and Boids observation features. Baselines
must be run according to their own separately recorded definitions.
"""
import argparse
import json
from pathlib import Path
import sys
from types import SimpleNamespace
import numpy as np
import torch


class Buffer:
    def __init__(self,capacity,state_dim,action_dim):
        self.capacity=capacity;self.size=0;self.cursor=0
        self.s=np.empty((capacity,state_dim),np.float32);self.a=np.empty((capacity,action_dim),np.float32)
        self.r=np.empty((capacity,1),np.float32);self.next=np.empty_like(self.s);self.done=np.empty((capacity,1),np.float32)
    def store(self,s,a,r,nxt,done):
        j=self.cursor;self.s[j]=s;self.a[j]=a;self.r[j]=r;self.next[j]=nxt;self.done[j]=done
        self.cursor=(j+1)%self.capacity;self.size=min(self.size+1,self.capacity)
    def sample(self,batch,device):
        ix=np.random.randint(0,self.size,batch)
        return tuple(torch.as_tensor(a[ix],device=device) for a in (self.s,self.a,self.r,self.next,self.done))


def main():
    p=argparse.ArgumentParser();p.add_argument('--project',default='archived_project');p.add_argument('--out',required=True)
    p.add_argument('--seed',type=int,required=True);p.add_argument('--steps',type=int,default=1000000)
    p.add_argument('--warm-steps',type=int,default=50000);p.add_argument('--batch',type=int,default=4096)
    p.add_argument('--device',default='cuda:0');p.add_argument('--defenders',type=int,default=6)
    p.add_argument('--capacity',type=int,default=250000);p.add_argument('--log-every',type=int,default=5000)
    a=p.parse_args();out=Path(a.out)
    if out.exists() and any(out.iterdir()):raise RuntimeError('Nonempty output directory; refusing overwrite.')
    out.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(Path(a.project)/'train'))
    from envs.TADgame import TADEnv
    from policy.SAC import SAC
    torch.set_num_threads(1);torch.manual_seed(a.seed);np.random.seed(a.seed)
    cfg=SimpleNamespace(rl=SimpleNamespace(batch_size=a.batch,GAMMA=.99,TAU=.005,learning_rate=1e-4,hidden_dim=512))
    env=TADEnv(a.defenders,protocol='paper-parameters-v1')
    agent=SAC(cfg,6,8,2,adaptive=False,device=torch.device(a.device))
    buffer=Buffer(a.capacity,env.state_dim,2)
    obs,_=env.reset(agility=2.,noisy_agility=True);episode_reward=0.;episodes=0;success=0
    for step in range(a.steps):
        if step<a.warm_steps:
            boids=env.thrust_to_action(env.boids_actions)
            noise=np.random.uniform(-1,1,boids.shape)
            action=np.clip(.7*boids+.3*noise,-1,1)
        else:
            with torch.no_grad():
                action,_=agent.actor(torch.as_tensor(obs,dtype=torch.float32,device=a.device))
                action=action.cpu().numpy()
        nxt,rewards,done,_=env.step(action,controller='RL')
        for i in range(a.defenders):buffer.store(obs[i],action[i],rewards[i],nxt[i],bool(done))
        if buffer.size>=a.batch:agent.learn(buffer)
        episode_reward+=float(np.mean(rewards));obs=nxt
        if done:
            episodes+=1;success+=done in (3,4)
            agility=2.+.25*min(3,step//250000)
            obs,_=env.reset(agility=agility,noisy_agility=True);episode_reward=0.
        if (step+1)%a.log_every==0 or step+1==a.steps:
            row={'source_environment_steps':step+1,'episodes':episodes,'training_successes':success,
                 'kind':'source_sac_with_boids_observation_and_warmstart','seed':a.seed}
            with (out/'progress.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
            torch.save(agent.actor.state_dict(),out/'source_actor.pth')
            torch.save({'actor':agent.actor.state_dict(),'critic':agent.critic.state_dict(),
                        'critic_target':agent.critic_target.state_dict(),
                        'actor_optimizer':agent.actor_optimizer.state_dict(),'critic_optimizer':agent.critic_optimizer.state_dict(),
                        'log_alpha':agent.log_alpha.detach(),'alpha_optimizer':agent.alpha_optimizer.state_dict(),
                        'torch_rng':torch.get_rng_state(),'numpy_rng':np.random.get_state(),
                        'steps':step+1,'arguments':vars(a)},out/'source_training.pt')
            print(json.dumps(row),flush=True)
    (out/'source_identity.json').write_text(json.dumps(vars(a)|{'kind':'source_sac_with_boids_observation_and_warmstart',
      'evaluation_status':'source training only; final controller requires predictive training'},indent=2))

if __name__=='__main__':main()
