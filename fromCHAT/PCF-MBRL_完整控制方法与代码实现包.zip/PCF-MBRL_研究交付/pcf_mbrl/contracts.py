from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
import hashlib
import json
import torch

@dataclass(frozen=True)
class Protocol:
    """A proposed new-task protocol, not an inherited empirical result."""
    name: str = 'pcf-six-physical-60-v1'
    defenders: int = 6
    time_limit: float = 60.0
    dt: float = 0.2
    dt_integration: float = 0.05
    target_radius: float = 15.0
    capture_radius: float = 5.0
    collision_radius: float = 5.0
    thrust_min: float = -500.0
    thrust_max: float = 1000.0
    gamma: float = 1.0
    # Potential shaping preserves finite-horizon terminal success objective.
    potential_weight: float = 0.25
    radial_early_termination: bool = False

    def __post_init__(self):
        if self.defenders < 2 or self.dt <= 0 or self.time_limit <= 0:
            raise ValueError('Invalid protocol dimensions/time.')
        if self.gamma != 1.0:
            raise ValueError('This success-equivalent protocol uses gamma=1.')
        if self.radial_early_termination:
            raise ValueError('Primary protocol excludes radial early failure.')

    def fingerprint(self) -> str:
        return hashlib.sha256(json.dumps(asdict(self), sort_keys=True).encode()).hexdigest()

    def save(self, path: str | Path):
        Path(path).write_text(json.dumps(asdict(self), ensure_ascii=False, indent=2), encoding='utf-8')


def blend(learned: torch.Tensor, rules: torch.Tensor, gates: torch.Tensor) -> torch.Tensor:
    if learned.shape != rules.shape or gates.shape != learned.shape or learned.shape[-1] != 2:
        raise ValueError('Expected matching [..., defenders, 2] tensors.')
    if not torch.isfinite(gates).all() or bool(((gates < 0) | (gates > 1)).any()):
        raise ValueError('Fusion coefficients must be finite in [0, 1].')
    return gates * learned + (1 - gates) * rules


def wrap_angle(x: torch.Tensor) -> torch.Tensor:
    return torch.atan2(torch.sin(x), torch.cos(x))


def validate_state(s: torch.Tensor, valid: torch.Tensor):
    # Last entity is the attacker; padded defenders precede it.
    # State = x,y,yaw,current_ground_v(3),source_observation_v(3).
    if s.ndim != 3 or s.shape[-1] != 9 or valid.shape != s.shape[:2]:
        raise ValueError('State [batch, defenders+1, 9], valid [batch, entities].')
    if not bool(valid[:, -1].all()):
        raise ValueError('The final entity must be a valid attacker.')
    if not bool((valid[:, :-1].sum(-1) >= 2).all()):
        raise ValueError('At least two defenders are required.')
    if not torch.isfinite(s).all():
        raise ValueError('Nonfinite state.')
