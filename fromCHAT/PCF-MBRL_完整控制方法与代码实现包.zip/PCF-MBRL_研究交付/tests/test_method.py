import copy
import unittest
from pathlib import Path
import numpy as np
import torch
from pcf_mbrl.contracts import Protocol,blend
from pcf_mbrl.archive_env import ArchiveEnv
from pcf_mbrl.sources import ArchivedSources,source_observations
from pcf_mbrl.physics import wamv_step
from pcf_mbrl.models import InteractionModel,ContinuationValue,update_history,state_loss
from pcf_mbrl.planner import FusionPlanner,PlannerConfig
from pcf_mbrl.reward import transition_reward,events,potential,discounted_returns
from pcf_mbrl.training import train_model,train_value,collect_branches,train_multistep

ROOT=Path(__file__).resolve().parents[1]

class MethodTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(1);torch.manual_seed(177)
        cls.p=Protocol()
        cls.env=ArchiveEnv(ROOT/'archived_project',cls.p)
        cls.batch=cls.env.reset(1101)
        cls.sources=ArchivedSources(ROOT/'archived_project',ROOT/'assets/source_arboids_seed42.pth')

    def setUp(self):
        self.model=InteractionModel();self.value=ContinuationValue()
        self.batch=tuple(x.clone() for x in self.__class__.batch)

    def randomize_head(self):
        torch.nn.init.normal_(self.model.decoder[-1].weight,std=.1)

    def test_01_blend_hull(self):
        l=torch.rand(4,6,2)*1500-500;b=torch.rand_like(l)*1500-500;g=torch.rand_like(l)
        u=blend(l,b,g)
        self.assertTrue(bool((u>=torch.minimum(l,b)-1e-4).all()))
        self.assertTrue(bool((u<=torch.maximum(l,b)+1e-4).all()))
        self.assertTrue(torch.equal(blend(l,b,torch.zeros_like(g)),b))
        self.assertTrue(torch.equal(blend(l,b,torch.ones_like(g)),l))

    def test_02_bad_gate_rejected(self):
        a=torch.zeros(1,6,2)
        with self.assertRaises(ValueError):blend(a,a,a-1)

    def test_03_source_observation_matches_archive(self):
        env=ArchiveEnv(ROOT/'archived_project',self.p);batch=env.reset(1101)
        obs,boids=source_observations(batch[0][:,-1]);ref,_=env.env._get_obs()
        np.testing.assert_allclose(obs.numpy()[0],ref,atol=2e-4,rtol=2e-5)
        np.testing.assert_allclose(boids.numpy()[0],env.env.boids_actions,atol=.01,rtol=2e-5)

    def test_04_source_feedback_changes_with_state(self):
        s=self.batch[0][:,-1].clone()
        s[0,:-1,0]=torch.arange(6)*20.-50
        s[0,:-1,1]=20.;s[0,:-1,2]=0
        a,b=self.sources(s)
        t=s.clone();t[:,-1,1]+=150
        c,d=self.sources(t)
        self.assertGreater(float((b-d).abs().sum()),1)

    def test_05_nominal_physics_matches_zero_current_archive(self):
        env=ArchiveEnv(ROOT/'archived_project',self.p);batch=env.reset(991)
        boat=copy.deepcopy(env.env.defender_list[0]);u=np.array([400.,900.])
        pred=wamv_step(batch[0][:,-1,:1],torch.tensor(u,dtype=torch.float32)[None,None])
        boat.step(u,np.zeros(3))
        ref=np.r_[boat.pos,boat.theta,boat.motion_state()[3:],boat.velocity]
        # Angle equivalence accounts for [0,2pi) versus [-pi,pi].
        arr=pred[0,0].numpy();arr[2]=(arr[2]%(2*np.pi));ref[2]=ref[2]%(2*np.pi)
        np.testing.assert_allclose(arr,ref,atol=3e-5,rtol=3e-5)

    def test_06_zero_initialization_nominal(self):
        h,a,r,v=self.batch;u=self.sources(h[:,-1])[1]
        out=self.model(h,a,r,v,u)
        ref=wamv_step(h[:,-1,:-1],u)
        torch.testing.assert_close(out[:,:-1],ref)

    def test_07_attacker_cannot_see_unexecuted_commands(self):
        self.randomize_head();h,a,r,v=self.batch
        u=torch.zeros(1,6,2);up=torch.ones_like(u)*900
        p=self.model(h,a,r,v,u);q=self.model(h,a,r,v,up)
        torch.testing.assert_close(p[:,-1],q[:,-1])

    def test_08_first_step_local_dynamics(self):
        self.randomize_head();h,a,r,v=self.batch
        u=torch.zeros(1,6,2);up=u.clone();up[:,1]=900
        p=self.model(h,a,r,v,u);q=self.model(h,a,r,v,up)
        torch.testing.assert_close(p[:,0],q[:,0])
        self.assertGreater(float((p[:,1]-q[:,1]).abs().sum().detach()),.01)

    def test_09_delayed_interaction_response(self):
        self.randomize_head();h,a,r,v=self.batch
        u=torch.zeros(1,6,2);up=u.clone();up[:,1]=900
        p=self.model(h,a,r,v,u);q=self.model(h,a,r,v,up)
        hp,ap=update_history(h,a,p,u);hq,aq=update_history(h,a,q,up)
        pp=self.model(hp,ap,r-.2,v,u);qq=self.model(hq,aq,r-.2,v,u)
        self.assertGreater(float((pp[:,0]-qq[:,0]).abs().sum().detach()),0)

    def test_10_defender_permutation(self):
        self.randomize_head();h,a,r,v=self.batch;u=self.sources(h[:,-1])[1]
        perm=torch.tensor([4,1,5,0,3,2,6])
        p=self.model(h,a,r,v,u)
        q=self.model(h[:,:,perm],a[:,:,perm],r,v[:,perm],u[:,perm[:-1]])
        torch.testing.assert_close(p[:,perm],q,atol=3e-5,rtol=2e-5)

    def test_11_padding_mask(self):
        self.randomize_head();h,a,r,v=self.batch;u=self.sources(h[:,-1])[1]
        hp=torch.cat((h[:,:,:-1],torch.randn(1,6,2,9)*50,h[:,:,-1:]),2)
        ap=torch.cat((a[:,:,:-1],torch.randn(1,6,2,2)*500,a[:,:,-1:]),2)
        vp=torch.tensor([[True]*6+[False]*2+[True]])
        up=torch.cat((u,torch.zeros(1,2,2)),1)
        p=self.model(h,a,r,v,u);q=self.model(hp,ap,r,vp,up)
        idx=[0,1,2,3,4,5,8]
        torch.testing.assert_close(p,q[:,idx],atol=3e-5,rtol=3e-5)

    def test_12_candidate_batch_isolation(self):
        self.randomize_head();h,a,r,v=self.batch;u=self.sources(h[:,-1])[1]
        p=self.model(h,a,r,v,u)
        q=self.model(h.repeat(2,1,1,1),a.repeat(2,1,1,1),r.repeat(2),v.repeat(2,1),torch.cat((u,-.1*u),0))
        torch.testing.assert_close(p,q[:1],atol=1e-5,rtol=1e-5)

    def test_13_same_real_command_same_prediction(self):
        h,a,r,v=self.batch;l,b=self.sources(h[:,-1]);b=l.clone()
        ua=blend(l,b,torch.zeros_like(l));ub=blend(l,b,torch.ones_like(l))
        torch.testing.assert_close(self.model(h,a,r,v,ua),self.model(h,a,r,v,ub))

    def test_14_terminal_priority(self):
        s=self.batch[0][:,-1].clone();valid=self.batch[-1]
        s[:,-1,:2]=0;s[:,1,:2]=s[:,0,:2]
        self.assertEqual(int(events(s,valid,torch.tensor([60.]),self.p)),1)
        s[:,-1,:2]=100
        self.assertEqual(int(events(s,valid,torch.tensor([60.]),self.p)),2)

    def test_15_timeout_success(self):
        h,_,_,v=self.batch;s=h[:,-1]
        reward,done,code=transition_reward(s,s,v,torch.tensor([60.]),self.p)
        self.assertEqual(int(code),4);self.assertTrue(bool(done))
        torch.testing.assert_close(reward+potential(s,v,self.p),torch.ones(1))

    def test_16_complete_return_contract(self):
        with self.assertRaises(ValueError):discounted_returns(torch.ones(2),torch.tensor([False,False]))
        torch.testing.assert_close(discounted_returns(torch.tensor([.2,-1.]),torch.tensor([False,True])),torch.tensor([-.8,-1.]))

    def test_17_value_target_gradient_boundary(self):
        h,a,r,v=self.batch;u=self.sources(h[:,-1])[1]
        torch.nn.init.normal_(self.value.readout[-1].weight,std=.1)
        target=copy.deepcopy(self.value).eval().requires_grad_(False)
        pred=self.model(h,a,r,v,u);hp,ap=update_history(h,a,pred,u)
        target(hp,ap,r-.2,v).sum().backward()
        self.assertTrue(any(p.grad is not None and float(p.grad.abs().sum())>0 for p in self.model.parameters()))
        self.assertTrue(all(p.grad is None for p in target.parameters()))
        self.assertTrue(all(p.grad is None for p in self.sources.parameters()))

    def test_18_policy_id_required_for_value(self):
        with self.assertRaises(ValueError):train_value(self.value,[], 'missing',2)

    def test_19_plan_budget_and_bounds(self):
        planner=FusionPlanner(self.model,self.value,self.sources,self.p,PlannerConfig(4,8,2,2,2))
        g,info=planner.plan(*self.batch,generator=torch.Generator().manual_seed(3))
        self.assertEqual(g.shape,(1,6,2));self.assertEqual(info['evaluated_plans_per_state'],16)
        self.assertTrue(bool(((g>=0)&(g<=1)).all()))
        self.assertEqual(info['plan'].shape,(1,4,6,2))

    def test_20_plan_future_cannot_change_first_transition(self):
        h,a,r,v=self.batch;u1,u2=self.sources(h[:,-1])
        plan=torch.rand(1,4,6,2);other=plan.clone();other[:,1:]=1-other[:,1:]
        p=self.model(h,a,r,v,blend(u1,u2,plan[:,0]))
        q=self.model(h,a,r,v,blend(u1,u2,other[:,0]))
        torch.testing.assert_close(p,q)

    def test_21_motion_loss_heading_wrap(self):
        s=self.batch[0][:,-1].clone();t=s.clone();t[...,2]+=2*torch.pi
        self.assertLess(float(state_loss(s,t,self.batch[-1])),1e-10)

    def test_22_env_snapshot_replay(self):
        env=ArchiveEnv(ROOT/'archived_project',self.p);env.reset(101)
        other=env.clone();u=np.full((6,2),400.)
        a=env.step(u);b=other.step(u)
        np.testing.assert_allclose(env.state(),other.state());self.assertEqual(a,b)

    def test_23_checkpoint_roundtrip(self):
        self.randomize_head();new=InteractionModel();new.load_state_dict(self.model.state_dict())
        h,a,r,v=self.batch;u=self.sources(h[:,-1])[1]
        torch.testing.assert_close(self.model(h,a,r,v,u),new(h,a,r,v,u))

    def test_24_reward_telescopes_on_real_archive(self):
        env=ArchiveEnv(ROOT/'archived_project',self.p);batch=env.reset(997)
        phi=float(potential(batch[0][:,-1],batch[-1],self.p));ret=0.;done=False
        while not done:
            h,_,_,_=env.batch()
            with torch.no_grad():l,b=self.sources(h[:,-1]);g=self.sources.reference_gates(h[:,-1]);u=blend(l,b,g)
            r,done,info=env.step(u[0].numpy());ret+=r
        self.assertAlmostEqual(ret+phi,1 if info['success'] else -1,places=5)


    def test_25_multistep_real_branch_training(self):
        env=ArchiveEnv(ROOT/'archived_project',self.p);env.reset(891)
        records,sequences,_=collect_branches(env,self.sources,[env.clone()],2,3,seed=912)
        before=copy.deepcopy(self.model.state_dict())
        logs=train_multistep(self.model,self.value,self.sources,sequences,updates=2,batch_size=2,max_steps=3)
        self.assertEqual(len(logs),2)
        self.assertTrue(all(torch.isfinite(p).all() for p in self.model.parameters()))
        self.assertTrue(any(not torch.equal(before[k],v) for k,v in self.model.state_dict().items()))

    def test_26_feedback_input_gradient_finite(self):
        state=self.batch[0][:,-1].clone().requires_grad_(True)
        learned,rules=self.sources(state)
        (learned.sum()+rules.sum()).backward()
        self.assertTrue(torch.isfinite(state.grad).all())


    def test_27_solver_memory_contract(self):
        with self.assertRaises(ValueError):
            FusionPlanner(self.model,self.value,self.sources,self.p,PlannerConfig(warm_start=True,terminal_value=True))

    def test_28_no_value_after_termination(self):
        class TerminalModel(torch.nn.Module):
            def forward(self,h,a,r,v,u):
                z=h[:,-1].clone();z[:,-1,:2]=0;return z
        class HugeValue(torch.nn.Module):
            def forward(self,h,a,r,v):return h.new_full((len(h),),1000.)
        planner=FusionPlanner(TerminalModel(),HugeValue(),self.sources,self.p,PlannerConfig(4,8,2,2,2))
        h,a,r,v=self.batch;plans=torch.full((1,2,4,6,2),.5)
        score=planner.score(h,a,r,v,plans)
        expected=(-1-potential(h[:,-1],v,self.p))[:,None].expand(-1,2)
        torch.testing.assert_close(score,expected)

if __name__=='__main__':unittest.main(verbosity=2)
